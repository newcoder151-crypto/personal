#!/usr/bin/env bash
# ============================================================
# Railway NVR — Single-command startup (FINAL FIXED)
# Usage: bash start.sh [--with-ai] [--setup-db]
# ============================================================

set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
WITH_AI=false
SETUP_DB=false

for arg in "$@"; do
  case $arg in
    --with-ai)  WITH_AI=true ;;
    --setup-db) SETUP_DB=true ;;
  esac
done

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[NVR]${NC} $*"; }
warn() { echo -e "${YELLOW}[NVR]${NC} $*"; }

SERVER_PID=""
AI_PID=""
FRONTEND_PID=""

cleanup() {
  log "Shutting down..."
  [ -n "$SERVER_PID" ] && kill "$SERVER_PID" 2>/dev/null || true
  [ -n "$AI_PID" ] && kill "$AI_PID" 2>/dev/null || true
  [ -n "$FRONTEND_PID" ] && kill "$FRONTEND_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# ─────────────────────────────────────────────
# OPTIONAL: Kill old processes (prevents EADDRINUSE)
# ─────────────────────────────────────────────
pkill -f "node src/index.js" 2>/dev/null || true
pkill -f "uvicorn" 2>/dev/null || true

# ─────────────────────────────────────────────
# Database setup
# ─────────────────────────────────────────────
if [ "$SETUP_DB" = true ]; then
  log "Setting up PostgreSQL database..."

  source "$ROOT/server/.env" 2>/dev/null || true

  DB_HOST="${DB_HOST:-localhost}"
  DB_PORT="${DB_PORT:-5432}"
  DB_NAME="${DB_NAME:-mnvr}"
  DB_USER="${DB_USER:-mnvr}"
  DB_PASSWORD="${DB_PASSWORD:-mnvrpass}"

  sudo -u postgres psql -c "
    DO \$\$
    BEGIN
      IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='${DB_USER}') THEN
        CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';
      END IF;
    END \$\$;
  " 2>/dev/null || warn "User exists"

  sudo -u postgres psql -c "
    SELECT 'CREATE DATABASE ${DB_NAME} OWNER ${DB_USER}'
    WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname='${DB_NAME}')\gexec
  " 2>/dev/null || warn "DB exists"

  PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -f "$ROOT/server/schema.sql"

  log "Database ready ✓"
fi

# ─────────────────────────────────────────────
# Storage
# ─────────────────────────────────────────────
mkdir -p "$ROOT/storage/recordings" "$ROOT/storage/hls"
log "Storage directories ready ✓"

# ─────────────────────────────────────────────
# Backend
# ─────────────────────────────────────────────
log "Starting Node.js API server (port 3001)..."

if [ ! -d "$ROOT/server/node_modules" ]; then
  warn "Installing backend dependencies..."
  cd "$ROOT/server" && npm install --silent
fi

cd "$ROOT/server"
node src/index.js &
SERVER_PID=$!

log "API server PID: $SERVER_PID"

# ─────────────────────────────────────────────
# AI Sidecar (FINAL FIX — NO SYSTEM PIP EVER)
# ─────────────────────────────────────────────
if [ "$WITH_AI" = true ]; then
  log "Starting YOLO AI sidecar (port 8000)..."

  AI_DIR="$ROOT/server/ai"
  VENV_DIR="$AI_DIR/venv"

  # Create venv if missing
  if [ ! -d "$VENV_DIR" ]; then
    log "Creating Python virtual environment..."
    python3 -m venv "$VENV_DIR"
  fi

  # Define absolute binaries (CRITICAL)
  PIP="$VENV_DIR/bin/pip"
  PY="$VENV_DIR/bin/python"

  # Install dependencies ONLY inside venv
  log "Installing AI dependencies (isolated)..."
  "$PIP" install --upgrade pip -q
  "$PIP" install -r "$AI_DIR/requirements.txt" -q

  # Start AI service using venv Python
  log "Launching YOLO sidecar..."
  cd "$AI_DIR"
  "$PY" -m uvicorn sidecar:app --host 0.0.0.0 --port 8000 &
  AI_PID=$!

  log "YOLO sidecar PID: $AI_PID"
fi

# ─────────────────────────────────────────────
# Frontend
# ─────────────────────────────────────────────
log "Starting frontend dev server (port 8080)..."

if [ ! -d "$ROOT/node_modules" ]; then
  warn "Installing frontend dependencies..."
  cd "$ROOT" && npm install --silent
fi

cd "$ROOT"
npm run dev &
FRONTEND_PID=$!

log "Frontend PID: $FRONTEND_PID"

# ─────────────────────────────────────────────
# Output
# ─────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║       Railway NVR System Started             ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║${NC} Frontend → http://localhost:8080           ${GREEN}║${NC}"
echo -e "${GREEN}║${NC} API      → http://localhost:3001/api       ${GREEN}║${NC}"
echo -e "${GREEN}║${NC} Docs     → http://localhost:3001/api/docs  ${GREEN}║${NC}"

if [ "$WITH_AI" = true ]; then
echo -e "${GREEN}║${NC} AI YOLO  → http://localhost:8000           ${GREEN}║${NC}"
fi

echo -e "${GREEN}╠══════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║${NC} Login: admin / Admin@123                   ${GREEN}║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
echo ""

wait