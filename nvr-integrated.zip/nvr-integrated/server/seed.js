/**
 * Seed script — populates sample cameras, recordings, and events for testing.
 * Run: node server/seed.js
 */
require("dotenv").config({ path: __dirname + "/.env" });
const { pool, query, testConnection } = require("./src/db");
const bcrypt = require("bcryptjs");
const path = require("path");
const fs = require("fs");

async function seed() {
  const ok = await testConnection();
  if (!ok) {
    console.error("Cannot connect to DB");
    process.exit(1);
  }

  console.log("Seeding database...");

  // Cameras
  const cameras = [
    {
      name: "CAM-01-INTERIOR",
      type: "INTERIOR",
      ip: "172.210.140.91",
      rtsp: "rtsp://192.168.1.101:554/stream1",
      loc: "Coach S1 — front",
      fps: 25,
    },
    {
      name: "CAM-02-INTERIOR",
      type: "INTERIOR",
      ip: "172.210.140.91",
      rtsp: "rtsp://172.210.140.91:554/stream1",
      loc: "Coach S1 — rear",
      fps: 25,
    },
    {
      name: "CAM-03-DOOR",
      type: "DOOR",
      ip: "172.210.140.91",
      rtsp: "rtsp://172.210.140.91:554/stream1",
      loc: "Door 1 — left",
      fps: 25,
    },
    {
      name: "CAM-04-EXTERIOR",
      type: "EXTERIOR",
      ip: "172.210.140.91",
      rtsp: "rtsp://172.210.140.91:554/stream1",
      loc: "Exterior — front",
      fps: 45,
    },
    {
      name: "CAM-05-DRIVER",
      type: "DRIVER_CAB",
      ip: "172.210.140.91",
      rtsp: "rtsp://172.210.140.91:554/stream1",
      loc: "Driver cab",
      fps: 25,
    },
  ];

  const camIds = [];
  for (const c of cameras) {
    const r = await query(
      `INSERT INTO cameras(camera_name, camera_type, ip_address, rtsp_url, location_description, target_fps, status)
       VALUES($1,$2,$3,$4,$5,$6,'ACTIVE') ON CONFLICT DO NOTHING RETURNING camera_id`,
      [c.name, c.type, c.ip, c.rtsp, c.loc, c.fps],
    );
    if (r.rows[0]) {
      camIds.push(r.rows[0].camera_id);
      // Health record
      await query(
        `INSERT INTO camera_health(camera_id, is_online, is_recording, frame_rate_actual, bitrate_kbps, error_count)
         VALUES($1,1,1,$2,2048,0)`,
        [r.rows[0].camera_id, c.fps],
      );
      // HLS dirs
      await query(
        `UPDATE cameras SET hls_output_dir=$1, rec_output_dir=$2, hls_playlist_url=$3 WHERE camera_id=$4`,
        [
          `./storage/hls/cam_${r.rows[0].camera_id}`,
          `./storage/recordings/cam_${r.rows[0].camera_id}`,
          `/api/streaming/hls/${r.rows[0].camera_id}/stream.m3u8`,
          r.rows[0].camera_id,
        ],
      );
    }
  }

  console.log(`Seeded ${camIds.length} cameras`);

  // Sample recordings (point to real files if they exist, otherwise use placeholder paths)
  const storagePath = process.env.RECORDINGS_PATH || "./storage/recordings";
  for (const cid of camIds) {
    for (let i = 0; i < 3; i++) {
      const start = new Date(Date.now() - (i + 1) * 60 * 60 * 1000);
      const end = new Date(start.getTime() + 10 * 60 * 1000);
      const fname = `cam${cid}_${start.getTime()}.mp4`;
      const fpath = path.join(storagePath, `cam_${cid}`, fname);
      await query(
        `INSERT INTO recordings(camera_id, file_path, file_name, start_timestamp, end_timestamp,
           duration_seconds, video_codec, resolution_width, resolution_height, status, recording_mode)
         VALUES($1,$2,$3,$4,$5,600,'H.265',1920,1080,'COMPLETED','CONTINUOUS') ON CONFLICT DO NOTHING`,
        [cid, fpath, fname, start.toISOString(), end.toISOString()],
      );
    }
  }
  console.log("Seeded sample recordings");

  // Events
  const eventTypes = [
    {
      type: "ALARM",
      title: "Motion detected in restricted area",
      sev: "WARNING",
    },
    {
      type: "CROWD_DENSITY",
      title: "High crowd density detected",
      sev: "WARNING",
    },
    { type: "TAMPERING", title: "Camera tamper detected", sev: "CRITICAL" },
    {
      type: "INTRUSION",
      title: "Intrusion in restricted zone",
      sev: "CRITICAL",
    },
    { type: "SYSTEM_ERROR", title: "Storage almost full", sev: "ERROR" },
    { type: "INFO", title: "Recording started", sev: "INFO" },
  ];

  for (const e of eventTypes) {
    const cid = camIds[Math.floor(Math.random() * camIds.length)];
    await query(
      `INSERT INTO events(event_type, title, severity, camera_id, description, occurred_at)
       VALUES($1,$2,$3,$4,$5,NOW() - INTERVAL '${Math.floor(Math.random() * 24)} hours') ON CONFLICT DO NOTHING`,
      [e.type, e.title, e.sev, cid, `Auto-generated test event: ${e.title}`],
    );
  }
  console.log("Seeded sample events");

  // Make sure admin password is correct (Admin@123)
  const hash = await bcrypt.hash("Admin@123", 12);
  await query(
    `UPDATE users SET password_hash=$1, must_change_password=0 WHERE username='admin'`,
    [hash],
  );
  console.log("Admin password set to: Admin@123");

  console.log(
    "\n✅ Seed complete! Start the server and login with admin / Admin@123",
  );
  await pool.end();
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
