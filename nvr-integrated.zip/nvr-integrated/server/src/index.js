require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const http = require('http');
const path = require('path');
const fs = require('fs');
const { setupWebSocket } = require('./websocket');
const { testConnection } = require('./db');
const swaggerUi = require('swagger-ui-express');

const app    = express();
const server = http.createServer(app);
const PORT   = parseInt(process.env.PORT || '3001');
const STORAGE_PATH = process.env.STORAGE_PATH || path.join(__dirname, '../../storage');

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  credentials: true,
  methods: ['GET','POST','PUT','DELETE','OPTIONS','PATCH'],
  allowedHeaders: ['Content-Type','Authorization'],
}));
app.use(morgan('dev'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Static storage serving ────────────────────────────────────────────────────
// Serve recordings and HLS segments directly (also handled by streaming routes with auth)
const recPath = path.join(STORAGE_PATH, 'recordings');
const hlsPath = path.join(STORAGE_PATH, 'hls');
[recPath, hlsPath].forEach(p => { if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true }); });

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/cameras',    require('./routes/cameras'));
app.use('/api/recordings', require('./routes/recordings'));
app.use('/api/events',     require('./routes/events'));
app.use('/api/users',      require('./routes/users'));
app.use('/api/config',     require('./routes/config'));
app.use('/api/streaming',  require('./routes/streaming'));
app.use('/api/ai',         require('./routes/ai'));
app.use('/api/nvr',         require('./routes/nvr'));

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({
  status: 'ok', version: '2.0.0', service: 'railway-nvr-api',
  uptime: process.uptime(), timestamp: new Date().toISOString(),
}));

// ── Swagger UI ────────────────────────────────────────────────────────────────
const swaggerDoc = require('./swagger');
app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerDoc, {
  customSiteTitle: 'Railway NVR API',
  swaggerOptions: { persistAuthorization: true },
}));
app.get('/api/docs.json', (req, res) => res.json(swaggerDoc));

// ── 404 / Error handlers ──────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: 'Not found', path: req.path }));
app.use((err, req, res, _next) => {
  console.error('[ERROR]', err.message);
  res.status(err.status || 500).json({ error: err.message });
});

// ── WebSocket ─────────────────────────────────────────────────────────────────
setupWebSocket(server);

// ── Start ─────────────────────────────────────────────────────────────────────
async function start() {
  const ok = await testConnection();
  if (!ok) {
    console.error('\n❌  Database connection failed.');
    console.error('    Set DB_HOST, DB_NAME, DB_USER, DB_PASSWORD in server/.env');
    console.error('    Then run:  psql -U mnvr -d mnvr -f server/schema.sql\n');
    process.exit(1);
  }
  server.listen(PORT, () => {
    console.log(`\n🚂  Railway NVR API  →  http://localhost:${PORT}`);
    console.log(`📖  API Docs         →  http://localhost:${PORT}/api/docs`);
    console.log(`🔌  WebSocket        →  ws://localhost:${PORT}/ws`);
    console.log(`💾  Storage path     →  ${STORAGE_PATH}\n`);
  });
}

start();
module.exports = { app, server };
