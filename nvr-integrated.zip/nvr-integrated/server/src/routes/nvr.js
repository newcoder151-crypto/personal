/**
 * NVR Core proxy routes
 * Bridges the Node.js API server with the mNVR C daemon (api_module.c)
 * The C daemon exposes its own HTTP API on api_port (default 8080)
 */
const express = require('express');
const axios = require('axios');
const { authenticate } = require('../middleware/auth');
const router = express.Router();

const NVR_CORE_URL = process.env.NVR_CORE_URL || 'http://localhost:8080';
const NVR_API_PREFIX = '/api/v1';

async function proxyGet(path, res) {
  try {
    const r = await axios.get(`${NVR_CORE_URL}${NVR_API_PREFIX}${path}`, { timeout: 5000 });
    res.json(r.data);
  } catch (err) {
    const status = err.response?.status || 502;
    res.status(status).json({ error: 'NVR core unreachable', detail: err.message, nvr_url: NVR_CORE_URL });
  }
}

// GET /api/nvr/status — NVR daemon system status
router.get('/status', authenticate, (req, res) => proxyGet('/system/status', res));

// GET /api/nvr/cameras — cameras from NVR daemon (runtime state)
router.get('/cameras', authenticate, (req, res) => proxyGet('/cameras', res));

// GET /api/nvr/recordings — recordings from NVR daemon
router.get('/recordings', authenticate, (req, res) => proxyGet('/recordings', res));

// GET /api/nvr/events — events from NVR daemon
router.get('/events', authenticate, (req, res) => proxyGet('/events', res));

// GET /api/nvr/health — NVR daemon ping
router.get('/health', authenticate, async (req, res) => {
  try {
    const r = await axios.get(`${NVR_CORE_URL}${NVR_API_PREFIX}/system/status`, { timeout: 3000 });
    res.json({ status: 'up', nvr_url: NVR_CORE_URL, data: r.data });
  } catch (err) {
    res.status(503).json({ status: 'down', nvr_url: NVR_CORE_URL, error: err.message });
  }
});

module.exports = router;
