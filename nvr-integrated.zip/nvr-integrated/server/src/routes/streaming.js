const express = require('express');
const path = require('path');
const fs = require('fs');
const { queryOne } = require('../db');
const { authenticate } = require('../middleware/auth');
const router = express.Router();

const RECORDINGS_PATH = process.env.RECORDINGS_PATH || path.join(__dirname, '../../../storage/recordings');
const HLS_PATH = process.env.HLS_PATH || path.join(__dirname, '../../../storage/hls');

// GET /api/streaming/recordings/:id/stream  — byte-range MP4 streaming
router.get('/recordings/:id/stream', authenticate, async (req, res) => {
  try {
    const rec = await queryOne(
      `SELECT r.*, c.camera_name FROM recordings r LEFT JOIN cameras c ON r.camera_id=c.camera_id WHERE r.recording_id=$1`,
      [req.params.id]);
    if (!rec) return res.status(404).json({ error: 'Recording not found' });

    // Resolve file path: use absolute path from DB, or build from recordings dir
    let filePath = rec.file_path;
    if (!path.isAbsolute(filePath)) filePath = path.join(RECORDINGS_PATH, filePath);
    if (!fs.existsSync(filePath)) {
      // Try just by file_name in recordings dir
      const byName = path.join(RECORDINGS_PATH, rec.file_name);
      if (fs.existsSync(byName)) filePath = byName;
      else return res.status(404).json({ error: 'Video file not found on disk', tried: filePath });
    }

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const range = req.headers.range;

    if (range) {
      const [startStr, endStr] = range.replace(/bytes=/, '').split('-');
      const start = parseInt(startStr, 10);
      const end = endStr ? parseInt(endStr, 10) : Math.min(start + 10 * 1024 * 1024 - 1, fileSize - 1);
      const chunkSize = end - start + 1;
      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunkSize,
        'Content-Type': 'video/mp4',
        'Cache-Control': 'no-cache',
      });
      fs.createReadStream(filePath, { start, end }).pipe(res);
    } else {
      res.writeHead(200, {
        'Content-Length': fileSize,
        'Content-Type': 'video/mp4',
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'no-cache',
      });
      fs.createReadStream(filePath).pipe(res);
    }
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/streaming/recordings/:id/thumbnail
router.get('/recordings/:id/thumbnail', authenticate, async (req, res) => {
  try {
    const rec = await queryOne('SELECT file_name, camera_id FROM recordings WHERE recording_id=$1', [req.params.id]);
    if (!rec) return res.status(404).json({ error: 'Recording not found' });
    // Look for a thumbnail JPG alongside the recording
    const base = path.join(RECORDINGS_PATH, `cam_${rec.camera_id}`);
    const thumbName = rec.file_name.replace(/\.(mp4|ts|mkv)$/i, '.jpg');
    const thumbPath = path.join(base, thumbName);
    if (fs.existsSync(thumbPath)) return res.sendFile(path.resolve(thumbPath));
    // Fallback: send generic placeholder
    res.status(204).send();
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/streaming/recordings/:id/download
router.get('/recordings/:id/download', authenticate, async (req, res) => {
  try {
    const rec = await queryOne('SELECT * FROM recordings WHERE recording_id=$1', [req.params.id]);
    if (!rec) return res.status(404).json({ error: 'Recording not found' });
    let filePath = rec.file_path;
    if (!path.isAbsolute(filePath)) filePath = path.join(RECORDINGS_PATH, filePath);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File not on disk' });
    res.download(filePath, rec.file_name);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/streaming/hls/:cameraId/stream.m3u8  — HLS live playlist
router.get('/hls/:cameraId/stream.m3u8', authenticate, async (req, res) => {
  try {
    const cam = await queryOne('SELECT hls_output_dir, hls_playlist_url, camera_id FROM cameras WHERE camera_id=$1', [req.params.cameraId]);
    if (!cam) return res.status(404).json({ error: 'Camera not found' });

    // Check DB-specified dir first, then default storage path
    let playlistPath = null;
    const dirs = [
      cam.hls_output_dir,
      path.join(HLS_PATH, `cam_${req.params.cameraId}`),
      path.join(HLS_PATH, String(req.params.cameraId)),
    ].filter(Boolean);

    for (const dir of dirs) {
      const p = path.join(dir, 'stream.m3u8');
      if (fs.existsSync(p)) { playlistPath = p; break; }
    }

    if (!playlistPath) return res.status(404).json({ error: 'HLS stream not available yet — camera may not be recording' });
    res.setHeader('Content-Type', 'application/vnd.apple.mpegurl');
    res.setHeader('Cache-Control', 'no-cache');
    res.sendFile(path.resolve(playlistPath));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/streaming/hls/:cameraId/:segment  — serve HLS .ts segments
router.get('/hls/:cameraId/:segment', authenticate, (req, res) => {
  try {
    const { cameraId, segment } = req.params;
    if (!segment.endsWith('.ts') && !segment.endsWith('.m3u8'))
      return res.status(400).json({ error: 'Only .ts and .m3u8 segments allowed' });

    const dirs = [
      path.join(HLS_PATH, `cam_${cameraId}`),
      path.join(HLS_PATH, cameraId),
    ];
    for (const dir of dirs) {
      const p = path.join(dir, segment);
      if (fs.existsSync(p)) {
        const contentType = segment.endsWith('.m3u8') ? 'application/vnd.apple.mpegurl' : 'video/MP2T';
        res.setHeader('Content-Type', contentType);
        res.setHeader('Cache-Control', 'no-cache');
        return res.sendFile(path.resolve(p));
      }
    }
    res.status(404).json({ error: 'Segment not found' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Serve recordings directory listing (for debugging)
router.get('/list', authenticate, async (req, res) => {
  try {
    const dir = RECORDINGS_PATH;
    if (!fs.existsSync(dir)) return res.json({ files: [], path: dir, error: 'Directory not found' });
    const walk = (d, depth = 0) => {
      if (depth > 2) return [];
      return fs.readdirSync(d).flatMap(f => {
        const full = path.join(d, f);
        return fs.statSync(full).isDirectory() ? walk(full, depth + 1) : [full.replace(dir, '')];
      });
    };
    res.json({ files: walk(dir), path: dir });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
