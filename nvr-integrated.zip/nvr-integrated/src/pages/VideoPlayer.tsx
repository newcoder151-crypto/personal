import { useState, useRef, useEffect, useCallback } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Play, Pause, Download, SkipBack, SkipForward, Volume2, VolumeX, Bot, Camera, RefreshCw, Maximize, Minimize } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useRecordings } from "@/hooks/use-recordings";
import { useCameras } from "@/hooks/use-cameras";
import { getStreamUrl, getDownloadUrl, getHlsUrl, detectObjects, type Detection, API_BASE, tokenStore } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Progress } from "@/components/ui/progress";

function formatDuration(sec: number) {
  const h = Math.floor(sec/3600); const m = Math.floor((sec%3600)/60); const s = Math.floor(sec%60);
  return h > 0 ? `${h}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}` : `${m}:${String(s).padStart(2,"0")}`;
}

const VideoPlayer = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hlsRef = useRef<any>(null);
  const aiIntervalRef = useRef<ReturnType<typeof setInterval>|null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const initRecId = searchParams.get("recording") ? parseInt(searchParams.get("recording")!) : null;
  const initCamId = searchParams.get("camera") ? parseInt(searchParams.get("camera")!) : null;
  const initLive = searchParams.get("live") === "true";

  const [selectedRecId, setSelectedRecId] = useState<number|null>(initRecId);
  const [selectedCamId, setSelectedCamId] = useState<number|null>(initCamId);
  const [liveMode, setLiveMode] = useState(initLive);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(true);
  const [aiEnabled, setAiEnabled] = useState(false);
  const [aiMode, setAiMode] = useState<"detect"|"people"|"intrusion">("detect");
  const [detections, setDetections] = useState<Detection[]>([]);
  const [inferenceMs, setInferenceMs] = useState<number|null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [peopleCount, setPeopleCount] = useState<number|null>(null);

  const { data: cameras } = useCameras();
  const { data: recordings } = useRecordings(selectedCamId ? { camera_id: selectedCamId, limit: 100 } : { limit: 50 });
  const currentRec = recordings?.find(r => r.recording_id === selectedRecId);

  // Build stream URL
  const videoSrc = liveMode && selectedCamId
    ? getHlsUrl(selectedCamId)
    : selectedRecId ? getStreamUrl(selectedRecId) : null;

  // Load stream with HLS.js support
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !videoSrc) return;
    hlsRef.current?.destroy();
    hlsRef.current = null;

    if (liveMode && !video.canPlayType("application/vnd.apple.mpegurl")) {
      import("hls.js").then(({ default: Hls }) => {
        if (!Hls.isSupported() || !videoRef.current) return;
        const hls = new Hls({ enableWorker: false, lowLatencyMode: true });
        hlsRef.current = hls;
        hls.loadSource(videoSrc);
        hls.attachMedia(videoRef.current);
        hls.on(Hls.Events.MANIFEST_PARSED, () => { videoRef.current?.play().catch(()=>{}); setPlaying(true); });
      }).catch(()=>{});
    } else {
      video.src = videoSrc;
      video.load();
      if (liveMode) { video.play().catch(()=>{}); setPlaying(true); }
    }
    return () => { hlsRef.current?.destroy(); hlsRef.current = null; };
  }, [videoSrc, liveMode]);

  // AI detection loop
  const runAi = useCallback(async () => {
    const v = videoRef.current; const canvas = canvasRef.current;
    if (!v || !canvas || v.paused || v.ended || v.videoWidth===0) return;
    const tmp = document.createElement("canvas");
    tmp.width = v.videoWidth; tmp.height = v.videoHeight;
    tmp.getContext("2d")?.drawImage(v, 0, 0);
    const endpointMap = { detect:"/api/ai/detect", people:"/api/ai/people-count", intrusion:"/api/ai/intrusion" };
    tmp.toBlob(async (blob) => {
      if (!blob) return;
      try {
        const res = await detectObjects(blob, { conf:0.35, endpoint:endpointMap[aiMode] });
        setDetections(res.detections);
        setInferenceMs(res.inference_ms);
        if (res.people_count !== undefined) setPeopleCount(res.people_count);
        canvas.width = tmp.width; canvas.height = tmp.height;
        const ctx = canvas.getContext("2d")!;
        ctx.clearRect(0,0,canvas.width,canvas.height);
        res.detections.forEach((d: Detection) => {
          const [x1,y1,x2,y2] = d.bbox; const ip = d.label==="person";
          ctx.strokeStyle = ip ? "#00ff88":"#ff6600"; ctx.lineWidth=2;
          ctx.strokeRect(x1,y1,x2-x1,y2-y1);
          const lbl=`${d.label} ${(d.confidence*100).toFixed(0)}%`;
          ctx.font="bold 12px system-ui"; const tw=ctx.measureText(lbl).width+6;
          ctx.fillStyle=ip?"#00ff88cc":"#ff6600cc"; ctx.fillRect(x1,y1-16,tw,16);
          ctx.fillStyle="#000"; ctx.fillText(lbl,x1+3,y1-3);
        });
      } catch {}
    }, "image/jpeg", 0.7);
  }, [aiMode]);

  useEffect(() => {
    if (aiEnabled) { aiIntervalRef.current = setInterval(runAi, 2000); }
    else {
      if (aiIntervalRef.current) clearInterval(aiIntervalRef.current);
      canvasRef.current?.getContext("2d")?.clearRect(0,0, canvasRef.current.width, canvasRef.current.height);
      setDetections([]); setInferenceMs(null); setPeopleCount(null);
    }
    return () => { if (aiIntervalRef.current) clearInterval(aiIntervalRef.current); };
  }, [aiEnabled, runAi]);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) { v.play().then(()=>setPlaying(true)); }
    else { v.pause(); setPlaying(false); }
  };

  const handleCameraSelect = (val: string) => {
    const id = parseInt(val);
    setSelectedCamId(id);
    setSelectedRecId(null);
    setLiveMode(true);
  };

  const handleRecSelect = (val: string) => {
    setSelectedRecId(parseInt(val));
    setLiveMode(false);
  };

  const personDetections = detections.filter(d=>d.label==="person");

  return (
    <AppLayout>
      <div className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Video Player</h1>
            <p className="text-sm text-muted-foreground">
              {liveMode ? "Live HLS Stream" : currentRec ? `Recording: ${currentRec.file_name}` : "Select a camera or recording"}
            </p>
          </div>
          <div className="flex gap-2">
            {selectedCamId && (
              <Button size="sm" variant="outline" onClick={() => { setLiveMode(!liveMode); if (!liveMode) setSelectedRecId(null); }}>
                {liveMode ? "Switch to Recording" : "Switch to Live"}
              </Button>
            )}
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-4">
          {/* Video panel */}
          <div className="lg:col-span-3 space-y-3">
            <div ref={containerRef} className={`relative bg-black rounded-lg overflow-hidden ${fullscreen?"fixed inset-0 z-50 rounded-none":""}`}
              style={fullscreen?{}:{aspectRatio:"16/9"}}>
              {videoSrc ? (
                <>
                  <video ref={videoRef} className="w-full h-full object-contain" muted={muted} playsInline
                    onTimeUpdate={() => { const v=videoRef.current; if(v){setCurrentTime(v.currentTime);setDuration(v.duration||0);} }}
                    onPlay={()=>setPlaying(true)} onPause={()=>setPlaying(false)}/>
                  <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none"/>
                  {/* AI badge */}
                  {aiEnabled && (
                    <div className="absolute top-2 right-2 flex items-center gap-1.5 bg-black/70 rounded-full px-2 py-0.5">
                      <Bot className="h-3 w-3 text-ai-glow animate-pulse"/>
                      <span className="text-[10px] text-ai-glow">{inferenceMs ? `${inferenceMs}ms` : "AI"}</span>
                      {peopleCount !== null && <span className="text-[10px] text-green-400">👤{peopleCount}</span>}
                    </div>
                  )}
                  {liveMode && (
                    <div className="absolute top-2 left-2 bg-red-500/80 text-white text-[10px] px-2 py-0.5 rounded-full font-bold animate-pulse">● LIVE</div>
                  )}
                </>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <div className="text-center">
                    <Camera className="h-12 w-12 mx-auto mb-2 opacity-20"/>
                    <p className="text-sm">Select a camera or recording</p>
                  </div>
                </div>
              )}
            </div>

            {/* Controls */}
            {videoSrc && (
              <div className="bg-card border border-border rounded-lg p-3 space-y-2">
                {!liveMode && duration > 0 && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground font-mono w-10">{formatDuration(currentTime)}</span>
                    <input type="range" min="0" max={duration} value={currentTime} step="0.5"
                      onChange={e => { if(videoRef.current) videoRef.current.currentTime=Number(e.target.value); }}
                      className="flex-1 h-1 accent-primary"/>
                    <span className="text-xs text-muted-foreground font-mono w-10 text-right">{formatDuration(duration)}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 flex-wrap">
                  {!liveMode && <Button size="sm" variant="ghost" onClick={()=>skip(-10)}><SkipBack className="h-4 w-4"/></Button>}
                  <Button size="sm" variant="default" onClick={togglePlay}>
                    {playing ? <Pause className="h-4 w-4"/> : <Play className="h-4 w-4"/>}
                  </Button>
                  {!liveMode && <Button size="sm" variant="ghost" onClick={()=>skip(10)}><SkipForward className="h-4 w-4"/></Button>}
                  <Button size="sm" variant="ghost" onClick={()=>{setMuted(m=>!m);if(videoRef.current)videoRef.current.muted=!muted;}}>
                    {muted ? <VolumeX className="h-4 w-4"/> : <Volume2 className="h-4 w-4"/>}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setFullscreen(f=>!f)}>
                    {fullscreen ? <Minimize className="h-4 w-4"/> : <Maximize className="h-4 w-4"/>}
                  </Button>
                  <div className="flex-1"/>
                  {selectedRecId && (
                    <Button size="sm" variant="outline" asChild>
                      <a href={getDownloadUrl(selectedRecId)} download><Download className="h-4 w-4 mr-1"/>Download</a>
                    </Button>
                  )}
                </div>
              </div>
            )}

            {/* AI controls */}
            <div className="bg-card border border-border rounded-lg p-3">
              <div className="flex items-center gap-3 flex-wrap">
                <Button size="sm" variant={aiEnabled?"default":"outline"} onClick={()=>setAiEnabled(v=>!v)} className="gap-1">
                  <Bot className="h-3.5 w-3.5"/>AI Detection {aiEnabled?"On":"Off"}
                </Button>
                {aiEnabled && (
                  <Select value={aiMode} onValueChange={(v:any)=>setAiMode(v)}>
                    <SelectTrigger className="w-44 h-8 text-xs"><SelectValue/></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="detect">Object Detection</SelectItem>
                      <SelectItem value="people">People Count + Density</SelectItem>
                      <SelectItem value="intrusion">Intrusion Detection</SelectItem>
                    </SelectContent>
                  </Select>
                )}
                {detections.length > 0 && (
                  <div className="flex gap-1 flex-wrap">
                    <Badge variant="outline" className="text-xs">{detections.length} objects</Badge>
                    {personDetections.length > 0 && <Badge className="text-xs bg-green-500/20 text-green-400">{personDetections.length} people</Badge>}
                    {inferenceMs && <Badge variant="secondary" className="text-xs">{inferenceMs}ms</Badge>}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right panel */}
          <div className="space-y-4">
            {/* Camera select */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-2"><CardTitle className="text-sm">Camera</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                <Select value={selectedCamId?.toString()||""} onValueChange={handleCameraSelect}>
                  <SelectTrigger className="text-xs"><SelectValue placeholder="Select camera…"/></SelectTrigger>
                  <SelectContent>
                    {cameras?.map(c=>(
                      <SelectItem key={c.camera_id} value={c.camera_id.toString()}>
                        {c.camera_name} {c.status==="ACTIVE"?"✓":"✗"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedCamId && (
                  <Button size="sm" className="w-full" onClick={() => setLiveMode(true)}>Watch Live</Button>
                )}
              </CardContent>
            </Card>

            {/* Recordings list */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-2"><CardTitle className="text-sm">Recordings</CardTitle></CardHeader>
              <CardContent>
                {!selectedCamId ? (
                  <p className="text-xs text-muted-foreground">Select a camera to see recordings</p>
                ) : !recordings?.length ? (
                  <p className="text-xs text-muted-foreground">No recordings found</p>
                ) : (
                  <div className="space-y-1.5 max-h-64 overflow-y-auto">
                    {recordings.map(rec => (
                      <div key={rec.recording_id}
                        className={`p-2 rounded border cursor-pointer hover:bg-muted/50 transition-colors text-xs ${selectedRecId===rec.recording_id&&!liveMode?"border-primary bg-muted/60":"border-border"}`}
                        onClick={() => handleRecSelect(rec.recording_id.toString())}>
                        <p className="font-medium truncate text-foreground">{rec.file_name}</p>
                        <p className="text-muted-foreground">{format(new Date(rec.start_timestamp),"MM/dd HH:mm")}{rec.duration_seconds ? ` · ${formatDuration(rec.duration_seconds)}` : ""}</p>
                        <div className="flex gap-1 mt-1">
                          <Badge variant="outline" className="text-[10px] py-0">{rec.status}</Badge>
                          {rec.has_audio===1 && <Badge variant="secondary" className="text-[10px] py-0">Audio</Badge>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Current recording info */}
            {currentRec && !liveMode && (
              <Card className="bg-card border-border">
                <CardHeader className="pb-2"><CardTitle className="text-sm">Recording Info</CardTitle></CardHeader>
                <CardContent className="text-xs space-y-1.5 text-muted-foreground">
                  <div className="flex justify-between"><span>Camera</span><span className="text-foreground">{currentRec.camera_name}</span></div>
                  <div className="flex justify-between"><span>Start</span><span className="text-foreground">{format(new Date(currentRec.start_timestamp),"MM/dd HH:mm:ss")}</span></div>
                  {currentRec.duration_seconds && <div className="flex justify-between"><span>Duration</span><span className="text-foreground">{formatDuration(currentRec.duration_seconds)}</span></div>}
                  <div className="flex justify-between"><span>Codec</span><span className="text-foreground">{currentRec.video_codec}</span></div>
                  <div className="flex justify-between"><span>Resolution</span><span className="text-foreground">{currentRec.resolution_width}×{currentRec.resolution_height}</span></div>
                  {currentRec.file_size_bytes && <div className="flex justify-between"><span>Size</span><span className="text-foreground">{(currentRec.file_size_bytes/1024/1024).toFixed(1)} MB</span></div>}
                  {currentRec.gps_speed_kmh && <div className="flex justify-between"><span>Speed</span><span className="text-foreground">{currentRec.gps_speed_kmh} km/h</span></div>}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );

  function skip(sec: number) { if (videoRef.current) videoRef.current.currentTime += sec; }
};
export default VideoPlayer;
