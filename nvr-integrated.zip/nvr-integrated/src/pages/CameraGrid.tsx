import { useState, useEffect, useRef, useCallback } from "react";
import { Plus, RefreshCw, Video, VideoOff, Wifi, WifiOff, Grid, Maximize2, Bot } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCameras, useCreateCamera, useDeleteCamera, useUpdateCamera, type Camera } from "@/hooks/use-cameras";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { API_BASE, tokenStore, detectObjects, type Detection } from "@/lib/api";

function useCameraStream(cameraId: number, active: boolean) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<any>(null);
  const buildUrl = useCallback(() => {
    const token = tokenStore.get() ?? "";
    return `${API_BASE}/api/streaming/hls/${cameraId}/stream.m3u8?token=${encodeURIComponent(token)}`;
  }, [cameraId]);
  useEffect(() => {
    if (!active || !videoRef.current) return;
    const video = videoRef.current;
    const url = buildUrl();
    if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = url; video.load(); video.play().catch(() => {});
      return () => { video.src = ""; };
    }
    let cancelled = false;
    import("hls.js").then(({ default: Hls }) => {
      if (cancelled || !videoRef.current) return;
      if (!Hls.isSupported()) return;
      const hls = new Hls({ enableWorker: false, lowLatencyMode: true, backBufferLength: 30 });
      hlsRef.current = hls;
      hls.loadSource(url);
      hls.attachMedia(videoRef.current);
      hls.on(Hls.Events.MANIFEST_PARSED, () => { videoRef.current?.play().catch(() => {}); });
    }).catch(() => {});
    return () => { cancelled = true; hlsRef.current?.destroy(); hlsRef.current = null; };
  }, [active, buildUrl]);
  return videoRef;
}

function AiOverlay({ videoRef, cameraId, enabled }: { videoRef: React.RefObject<HTMLVideoElement>; cameraId: number; enabled: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!enabled) { canvasRef.current?.getContext("2d")?.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height); return; }
    const runDetect = async () => {
      const video = videoRef.current; const canvas = canvasRef.current;
      if (!video || !canvas || video.paused || video.videoWidth === 0) return;
      const tmp = document.createElement("canvas");
      tmp.width = video.videoWidth; tmp.height = video.videoHeight;
      tmp.getContext("2d")?.drawImage(video, 0, 0);
      tmp.toBlob(async (blob) => {
        if (!blob) return;
        try {
          const result = await detectObjects(blob, { conf: 0.35 });
          canvas.width = tmp.width; canvas.height = tmp.height;
          const ctx = canvas.getContext("2d")!;
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          result.detections.forEach((d: Detection) => {
            const [x1,y1,x2,y2] = d.bbox; const isPerson = d.label === "person";
            ctx.strokeStyle = isPerson ? "#00ff88" : "#ff6600"; ctx.lineWidth = 2;
            ctx.strokeRect(x1,y1,x2-x1,y2-y1);
            const lbl = `${d.label} ${(d.confidence*100).toFixed(0)}%`;
            ctx.font = "bold 12px system-ui"; const tw = ctx.measureText(lbl).width+6;
            ctx.fillStyle = isPerson ? "#00ff88cc" : "#ff6600cc"; ctx.fillRect(x1,y1-16,tw,16);
            ctx.fillStyle="#000"; ctx.fillText(lbl,x1+3,y1-3);
          });
        } catch {}
      }, "image/jpeg", 0.7);
    };
    const id = setInterval(runDetect, 3000);
    return () => clearInterval(id);
  }, [enabled, videoRef, cameraId]);
  return <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />;
}

const statusColor: Record<string,string> = {
  ACTIVE:"bg-green-500/10 text-green-400 border-green-500/20",
  INACTIVE:"bg-muted text-muted-foreground",
  FAULTY:"bg-destructive/10 text-destructive border-destructive/20",
  MAINTENANCE:"bg-warning/10 text-warning border-warning/20",
};

function CameraTile({ cam, aiEnabled, onExpand, isAdmin, onDelete }: {
  cam: Camera; aiEnabled: boolean; onExpand: () => void; isAdmin: boolean; onDelete: (id: number) => void;
}) {
  const isActive = cam.status === "ACTIVE";
  const videoRef = useCameraStream(cam.camera_id, isActive);
  return (
    <div className="relative bg-black rounded-lg overflow-hidden group" style={{aspectRatio:"16/9"}}>
      {isActive ? (
        <>
          <video ref={videoRef} className="w-full h-full object-cover" muted playsInline autoPlay />
          <AiOverlay videoRef={videoRef} cameraId={cam.camera_id} enabled={aiEnabled} />
        </>
      ) : (
        <div className="flex items-center justify-center h-full bg-muted/20">
          <VideoOff className="h-8 w-8 text-muted-foreground/30" />
        </div>
      )}
      <div className="absolute top-0 left-0 right-0 p-1.5 flex items-center justify-between bg-gradient-to-b from-black/70 to-transparent">
        <div className="flex items-center gap-1">
          <Badge className={`text-[9px] py-0 px-1 ${statusColor[cam.status]||""}`}>{cam.status}</Badge>
          {cam.is_recording===1 && <Badge className="text-[9px] py-0 px-1 bg-red-500/80 text-white animate-pulse">REC</Badge>}
        </div>
        <div className="flex items-center gap-1.5">
          {cam.is_online ? <Wifi className="h-3 w-3 text-green-400"/> : <WifiOff className="h-3 w-3 text-gray-400"/>}
          {aiEnabled && isActive && <Bot className="h-3 w-3 text-ai-glow animate-pulse"/>}
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-1.5 bg-gradient-to-t from-black/80 to-transparent">
        <div className="flex items-center justify-between">
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-medium text-white truncate">{cam.camera_name}</p>
            <p className="text-[9px] text-white/60 truncate">{cam.location_description||cam.camera_type}</p>
          </div>
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity ml-1">
            <button onClick={onExpand} className="p-0.5 rounded hover:bg-white/20"><Maximize2 className="h-3 w-3 text-white/80"/></button>
            {isAdmin && <button onClick={() => onDelete(cam.camera_id)} className="p-0.5 rounded hover:bg-red-500/40 text-white/60 hover:text-white text-xs">×</button>}
          </div>
        </div>
      </div>
      {!isActive && (
        <div className="absolute inset-0 flex items-center justify-center">
          <Badge className="bg-destructive/80 text-destructive-foreground">{cam.status}</Badge>
        </div>
      )}
    </div>
  );
}

type GridLayout = "1x1"|"2x2"|"3x3"|"4x4";
const gridCols: Record<GridLayout,string> = {"1x1":"grid-cols-1","2x2":"grid-cols-2","3x3":"grid-cols-3","4x4":"grid-cols-4"};
const gridCount: Record<GridLayout,number> = {"1x1":1,"2x2":4,"3x3":9,"4x4":16};

function ExpandedPlayer({ cam, aiEnabled }: { cam: Camera; aiEnabled: boolean }) {
  const videoRef = useCameraStream(cam.camera_id, cam.status==="ACTIVE");
  return (
    <>
      <video ref={videoRef} className="w-full h-full object-contain" muted playsInline autoPlay/>
      <AiOverlay videoRef={videoRef} cameraId={cam.camera_id} enabled={aiEnabled&&cam.status==="ACTIVE"}/>
    </>
  );
}

const CameraGrid = () => {
  const { isAdmin } = useAuth(); const { toast } = useToast(); const navigate = useNavigate();
  const { data: cameras, isLoading, refetch } = useCameras();
  const createCamera = useCreateCamera(); const deleteCamera = useDeleteCamera();
  const [layout, setLayout] = useState<GridLayout>("2x2");
  const [page, setPage] = useState(0);
  const [aiEnabled, setAiEnabled] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [expandedCam, setExpandedCam] = useState<Camera|null>(null);
  const [newCam, setNewCam] = useState({ camera_name:"", camera_type:"INTERIOR", ip_address:"", rtsp_url:"", location_description:"" });
  const perPage = gridCount[layout];
  const allCameras = cameras??[];
  const totalPages = Math.max(1, Math.ceil(allCameras.length/perPage));
  const visible = allCameras.slice(page*perPage, page*perPage+perPage);
  useEffect(() => setPage(0), [layout]);
  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    try { await createCamera.mutateAsync(newCam); toast({title:"Camera added"}); setAddOpen(false); setNewCam({camera_name:"",camera_type:"INTERIOR",ip_address:"",rtsp_url:"",location_description:""}); }
    catch (err: any) { toast({title:"Error",description:err.message,variant:"destructive"}); }
  };
  const handleDelete = async (id: number) => {
    if (!confirm("Delete this camera?")) return;
    await deleteCamera.mutateAsync(id); toast({title:"Camera deleted"});
  };
  return (
    <AppLayout>
      <div className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Camera Grid</h1>
            <p className="text-sm text-muted-foreground">{allCameras.length} cameras · {allCameras.filter(c=>c.status==="ACTIVE").length} active</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
              {(["1x1","2x2","3x3","4x4"] as GridLayout[]).map(l => (
                <button key={l} onClick={() => setLayout(l)} className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${layout===l?"bg-primary text-primary-foreground shadow":"text-muted-foreground hover:text-foreground hover:bg-muted"}`}>
                  <Grid className="h-3 w-3 inline mr-1"/>{l}
                </button>
              ))}
            </div>
            <Button size="sm" variant={aiEnabled?"default":"outline"} onClick={() => setAiEnabled(v=>!v)} className="gap-1">
              <Bot className="h-3.5 w-3.5"/>AI {aiEnabled?"On":"Off"}
            </Button>
            <Button size="sm" variant="outline" onClick={() => refetch()}><RefreshCw className="h-3 w-3 mr-1"/>Refresh</Button>
            {isAdmin && (
              <Dialog open={addOpen} onOpenChange={setAddOpen}>
                <DialogTrigger asChild><Button size="sm" className="gap-1"><Plus className="h-4 w-4"/>Add Camera</Button></DialogTrigger>
                <DialogContent className="bg-card border-border">
                  <DialogHeader><DialogTitle>Add Camera</DialogTitle></DialogHeader>
                  <form onSubmit={handleAdd} className="space-y-3">
                    <div><Label className="text-xs">Name</Label><Input placeholder="CAM-01" value={newCam.camera_name} onChange={e=>setNewCam({...newCam,camera_name:e.target.value})} required/></div>
                    <div><Label className="text-xs">Type</Label>
                      <Select value={newCam.camera_type} onValueChange={v=>setNewCam({...newCam,camera_type:v})}>
                        <SelectTrigger><SelectValue/></SelectTrigger>
                        <SelectContent>{["INTERIOR","EXTERIOR","DOOR","DRIVER_CAB"].map(t=><SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                      </Select></div>
                    <div><Label className="text-xs">IP Address</Label><Input placeholder="192.168.1.100" value={newCam.ip_address} onChange={e=>setNewCam({...newCam,ip_address:e.target.value})}/></div>
                    <div><Label className="text-xs">RTSP URL</Label><Input placeholder="rtsp://..." value={newCam.rtsp_url} onChange={e=>setNewCam({...newCam,rtsp_url:e.target.value})}/></div>
                    <div><Label className="text-xs">Location</Label><Input placeholder="Coach S1" value={newCam.location_description} onChange={e=>setNewCam({...newCam,location_description:e.target.value})}/></div>
                    <Button type="submit" className="w-full" disabled={createCamera.isPending}>Add Camera</Button>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>
        {isLoading && (
          <div className={`grid ${gridCols[layout]} gap-2`}>
            {Array.from({length:perPage}).map((_,i)=><div key={i} className="aspect-video bg-muted/30 rounded-lg animate-pulse"/>)}
          </div>
        )}
        {!isLoading && (
          <>
            <div className={`grid ${gridCols[layout]} gap-2`}>
              {visible.map(cam=>(
                <CameraTile key={cam.camera_id} cam={cam} aiEnabled={aiEnabled} onExpand={()=>setExpandedCam(cam)} isAdmin={isAdmin} onDelete={handleDelete}/>
              ))}
              {Array.from({length:Math.max(0,perPage-visible.length)}).map((_,i)=>(
                <div key={`ph-${i}`} className="aspect-video bg-muted/10 rounded-lg border border-dashed border-border/30 flex items-center justify-center">
                  <Video className="h-6 w-6 text-muted-foreground/20"/>
                </div>
              ))}
            </div>
            {allCameras.length===0 && (
              <div className="text-center py-16 text-muted-foreground">
                <Video className="h-12 w-12 mx-auto mb-2 opacity-20"/>
                <p className="text-sm">No cameras configured yet</p>
                {isAdmin && <p className="text-xs mt-1">Click "Add Camera" to get started</p>}
              </div>
            )}
            {totalPages>1 && (
              <div className="flex items-center justify-center gap-2 pt-2">
                <Button size="sm" variant="outline" disabled={page===0} onClick={()=>setPage(p=>p-1)}>← Prev</Button>
                <span className="text-xs text-muted-foreground">Page {page+1} / {totalPages}</span>
                <Button size="sm" variant="outline" disabled={page>=totalPages-1} onClick={()=>setPage(p=>p+1)}>Next →</Button>
              </div>
            )}
          </>
        )}
        {expandedCam && (
          <Dialog open={!!expandedCam} onOpenChange={()=>setExpandedCam(null)}>
            <DialogContent className="bg-card border-border max-w-4xl w-full p-0 overflow-hidden">
              <DialogHeader className="p-3 pb-0">
                <DialogTitle className="flex items-center justify-between">
                  <span>{expandedCam.camera_name}</span>
                  <div className="flex items-center gap-2">
                    <Badge className={statusColor[expandedCam.status]}>{expandedCam.status}</Badge>
                    <Button size="sm" variant="outline" onClick={()=>navigate(`/player?camera=${expandedCam.camera_id}&live=true`)}>Open in Player</Button>
                  </div>
                </DialogTitle>
              </DialogHeader>
              <div className="relative bg-black" style={{aspectRatio:"16/9"}}>
                <ExpandedPlayer cam={expandedCam} aiEnabled={aiEnabled}/>
              </div>
              <div className="p-3 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-muted-foreground">
                <div><p className="font-medium text-foreground">Location</p><p>{expandedCam.location_description||"—"}</p></div>
                <div><p className="font-medium text-foreground">Type</p><p>{expandedCam.camera_type}</p></div>
                <div><p className="font-medium text-foreground">Resolution</p><p>{expandedCam.resolution_width}×{expandedCam.resolution_height}</p></div>
                <div><p className="font-medium text-foreground">Target FPS</p><p>{expandedCam.frame_rate_actual??expandedCam.target_fps}</p></div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </AppLayout>
  );
};
export default CameraGrid;
