import { useState } from "react";
import { Search, Download, Play } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useRecordings } from "@/hooks/use-recordings";
import { useCameras } from "@/hooks/use-cameras";
import { getDownloadUrl } from "@/lib/api";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";

const SearchPage = () => {
  const navigate = useNavigate();

  const [cameraId, setCameraId] = useState<string>("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [status, setStatus] = useState<string>("all");

  const { data: cameras } = useCameras();

  const { data: recordings, isLoading } = useRecordings({
    camera_id: cameraId !== "all" ? parseInt(cameraId) : undefined,
    start_date: startDate || undefined,
    end_date: endDate || undefined,
    status: status !== "all" ? status : undefined,
    limit: 100,
  });

  const formatSize = (bytes: number | null) => {
    if (!bytes) return "—";
    if (bytes > 1e9) return `${(bytes / 1e9).toFixed(1)} GB`;
    return `${(bytes / 1e6).toFixed(0)} MB`;
  };

  return (
    <AppLayout>
      <div className="space-y-4">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Search Recordings
          </h1>
          <p className="text-sm text-muted-foreground">
            Filter and play back stored video recordings
          </p>
        </div>

        {/* Filters */}
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {/* Camera */}
              <div>
                <Label className="text-xs">Camera</Label>
                <Select value={cameraId} onValueChange={setCameraId}>
                  <SelectTrigger className="h-8 mt-1">
                    <SelectValue placeholder="All cameras" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All cameras</SelectItem>
                    {cameras?.map((c) => (
                      <SelectItem key={c.camera_id} value={String(c.camera_id)}>
                        {c.camera_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* From */}
              <div>
                <Label className="text-xs">From</Label>
                <Input
                  type="datetime-local"
                  className="h-8 mt-1 text-xs"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>

              {/* To */}
              <div>
                <Label className="text-xs">To</Label>
                <Input
                  type="datetime-local"
                  className="h-8 mt-1 text-xs"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>

              {/* Status */}
              <div>
                <Label className="text-xs">Status</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger className="h-8 mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="COMPLETED">Completed</SelectItem>
                    <SelectItem value="RECORDING">Recording</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground">
            {isLoading
              ? "Searching..."
              : `${recordings?.length || 0} recordings found`}
          </p>

          {recordings?.map((rec) => (
            <Card
              key={rec.recording_id}
              className="bg-card border-border hover:border-primary/30 transition-colors"
            >
              <CardContent className="p-3 flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-sm text-foreground truncate">
                      {rec.camera_name || `Camera ${rec.camera_id}`}
                    </span>
                    <Badge variant="outline" className="text-[10px] shrink-0">
                      {rec.status}
                    </Badge>
                  </div>

                  <div className="flex gap-3 text-xs text-muted-foreground flex-wrap">
                    <span>
                      {format(
                        new Date(rec.start_timestamp),
                        "dd MMM yyyy HH:mm:ss",
                      )}
                    </span>

                    {rec.duration_seconds && (
                      <span>
                        {Math.floor(rec.duration_seconds / 60)}m{" "}
                        {rec.duration_seconds % 60}s
                      </span>
                    )}

                    <span>{formatSize(rec.file_size_bytes)}</span>
                    <span>{rec.video_codec}</span>
                    <span>
                      {rec.resolution_width}×{rec.resolution_height}
                    </span>

                    {rec.gps_speed_kmh && (
                      <span>🚂 {rec.gps_speed_kmh}km/h</span>
                    )}
                  </div>

                  {rec.location_description && (
                    <p className="text-[10px] text-muted-foreground mt-0.5 truncate">
                      {rec.location_description}
                    </p>
                  )}
                </div>

                {/* Actions */}
                <div className="flex gap-1 shrink-0 ml-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 w-7 p-0"
                    onClick={() =>
                      navigate(`/player?recording=${rec.recording_id}`)
                    }
                  >
                    <Play className="h-3 w-3" />
                  </Button>

                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 w-7 p-0"
                    asChild
                  >
                    <a href={getDownloadUrl(rec.recording_id)} download>
                      <Download className="h-3 w-3" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}

          {!isLoading && !recordings?.length && (
            <div className="text-center py-12 text-muted-foreground">
              <Search className="h-10 w-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No recordings match your filters</p>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
};

export default SearchPage;
