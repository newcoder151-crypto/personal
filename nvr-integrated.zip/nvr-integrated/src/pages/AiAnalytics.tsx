import { useState, useRef } from "react";
import { Cpu, Activity, Users, ShieldAlert, Bot, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AppLayout } from "@/components/layout/AppLayout";
import { useQuery } from "@tanstack/react-query";
import { apiGet, detectObjects, type DetectResult, API_BASE, tokenStore } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { useEvents } from "@/hooks/use-events";
import { useCameras } from "@/hooks/use-cameras";

type AiResult = DetectResult & {
  people_count?: number; density_percent?: number; density_level?: string;
  intrusion_detected?: boolean; intruder_count?: number; summary?: Record<string,number>;
};

const AiAnalytics = () => {
  const { toast } = useToast();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mode, setMode] = useState<"detect"|"people"|"intrusion">("detect");
  const [result, setResult] = useState<AiResult|null>(null);
  const [busy, setBusy] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string|null>(null);
  const [selectedCamera, setSelectedCamera] = useState<string>("");

  const { data: events } = useEvents({ limit: 500 });
  const { data: cameras } = useCameras();
  const { data: analytics } = useQuery({
    queryKey:["ai-analytics"], queryFn:()=>apiGet<any>("/api/ai/analytics"), refetchInterval:30000,
  });

  const endpointMap = { detect:"/api/ai/detect", people:"/api/ai/people-count", intrusion:"/api/ai/intrusion" };

  // Capture a frame from the live camera stream and run detection
  const captureAndDetect = async () => {
    if (!selectedCamera) { toast({title:"Select a camera first",variant:"destructive"}); return; }
    setBusy(true); setResult(null);
    try {
      // Fetch the HLS playlist to know stream is alive, then grab frame via canvas
      const token = tokenStore.get()??"";
      const hlsUrl = `${API_BASE}/api/streaming/hls/${selectedCamera}/stream.m3u8?token=${encodeURIComponent(token)}`;
      // Create temporary video element
      const video = document.createElement("video");
      video.crossOrigin = "anonymous"; video.muted = true;
      video.src = hlsUrl;
      // Try native or give up (for capture we just need a frame)
      await new Promise<void>((res, rej) => {
        video.onloadeddata = () => res();
        video.onerror = () => rej(new Error("Stream not available"));
        video.load(); video.play().catch(()=>{});
        setTimeout(()=>res(), 3000); // proceed anyway after 3s
      });
      const tmp = document.createElement("canvas");
      tmp.width = video.videoWidth||640; tmp.height = video.videoHeight||360;
      tmp.getContext("2d")?.drawImage(video, 0, 0);
      video.pause(); video.src = "";
      const url = tmp.toDataURL("image/jpeg", 0.9);
      setPreviewUrl(url);
      tmp.toBlob(async (blob) => {
        if (!blob) { setBusy(false); return; }
        try {
          const res = await detectObjects(blob, { conf:0.35, endpoint:endpointMap[mode] });
          setResult(res);
          drawBoxes(url, res.detections);
          toast({title:"AI Analysis complete", description:`${res.detections.length} objects · ${res.inference_ms}ms`});
        } catch (err: any) {
          toast({title:"AI Error", description:err.message, variant:"destructive"});
        } finally { setBusy(false); }
      }, "image/jpeg", 0.8);
    } catch (err: any) {
      toast({title:"Stream Error", description:err.message, variant:"destructive"});
      setBusy(false);
    }
  };

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const url = URL.createObjectURL(file);
    setPreviewUrl(url); setBusy(true); setResult(null);
    try {
      const res = await detectObjects(file, { conf:0.35, endpoint:endpointMap[mode] });
      setResult(res); drawBoxes(url, res.detections);
      toast({title:"AI Analysis complete", description:`${res.detections.length} objects in ${res.inference_ms}ms`});
    } catch (err: any) { toast({title:"AI Error",description:err.message,variant:"destructive"}); }
    finally { setBusy(false); }
  };

  const drawBoxes = (imgUrl: string, dets: DetectResult["detections"]) => {
    const canvas = canvasRef.current; if (!canvas) return;
    const img = new Image();
    img.onload = () => {
      canvas.width=img.width; canvas.height=img.height;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img,0,0);
      dets.forEach(d => {
        const [x1,y1,x2,y2] = d.bbox; const ip = d.label==="person";
        ctx.strokeStyle=ip?"#00ff88":"#ff6600"; ctx.lineWidth=2;
        ctx.strokeRect(x1,y1,x2-x1,y2-y1);
        const lbl=`${d.label} ${(d.confidence*100).toFixed(0)}%`;
        ctx.font="13px system-ui"; const tw=ctx.measureText(lbl).width+8;
        ctx.fillStyle=ip?"#00ff88cc":"#ff6600cc"; ctx.fillRect(x1,y1-18,tw,18);
        ctx.fillStyle="#000"; ctx.fillText(lbl,x1+4,y1-4);
      });
    };
    img.src=imgUrl;
  };

  const totalEvents = events?.length??0;
  const crowdEvents = events?.filter(e=>e.event_type==="CROWD_DENSITY").length??0;
  const intrusionEvents = events?.filter(e=>e.event_type==="INTRUSION").length??0;

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">AI Analytics</h1>
          <p className="text-sm text-muted-foreground">YOLO-powered real-time detection on live camera feeds and uploaded frames</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {label:"Events Today",val:totalEvents,icon:Activity,color:"text-blue-400"},
            {label:"Crowd Events",val:crowdEvents,icon:Users,color:"text-warning"},
            {label:"Intrusion Alerts",val:intrusionEvents,icon:ShieldAlert,color:"text-destructive"},
            {label:"AI Inferences",val:analytics?.by_type?.reduce((s:number,r:any)=>s+parseInt(r.count),0)??"—",icon:Cpu,color:"text-ai-glow"},
          ].map(({label,val,icon:Icon,color})=>(
            <Card key={label} className="bg-card border-border"><CardContent className="p-4">
              <Icon className={`h-5 w-5 ${color} mb-2`}/><p className="text-2xl font-bold text-foreground">{val}</p>
              <p className="text-xs text-muted-foreground">{label}</p>
            </CardContent></Card>
          ))}
        </div>

        <Tabs defaultValue="live">
          <TabsList>
            <TabsTrigger value="live">Live Camera Analysis</TabsTrigger>
            <TabsTrigger value="upload">Upload Frame</TabsTrigger>
            <TabsTrigger value="history">Event History</TabsTrigger>
          </TabsList>

          <TabsContent value="live" className="space-y-4">
            <Card className="bg-card border-border"><CardContent className="p-4 space-y-4">
              <div className="flex flex-wrap gap-2 items-end">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Camera</p>
                  <Select value={selectedCamera} onValueChange={setSelectedCamera}>
                    <SelectTrigger className="w-52"><SelectValue placeholder="Select camera…"/></SelectTrigger>
                    <SelectContent>
                      {cameras?.filter(c=>c.status==="ACTIVE").map(c=>(
                        <SelectItem key={c.camera_id} value={c.camera_id.toString()}>{c.camera_name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Mode</p>
                  <div className="flex gap-1">
                    {([["detect","Object Detection"],["people","People Count"],["intrusion","Intrusion"]] as const).map(([k,l])=>(
                      <Button key={k} size="sm" variant={mode===k?"default":"outline"} onClick={()=>setMode(k)}>{l}</Button>
                    ))}
                  </div>
                </div>
                <Button onClick={captureAndDetect} disabled={busy||!selectedCamera} className="gap-2">
                  <Bot className="h-4 w-4"/>{busy?"Analysing…":"Capture & Detect"}
                </Button>
              </div>
              {previewUrl && (
                <div>
                  <canvas ref={canvasRef} className="w-full rounded border border-border max-h-96 object-contain"/>
                  {result && (
                    <div className="mt-3 space-y-2">
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="outline">{result.detections.length} objects</Badge>
                        <Badge variant="outline">{result.inference_ms}ms</Badge>
                        {result.people_count!==undefined && <Badge className="bg-green-500/20 text-green-400">{result.people_count} people</Badge>}
                        {result.density_level && <Badge className={result.density_level==="HIGH"?"bg-destructive/20 text-destructive":result.density_level==="MEDIUM"?"bg-warning/20 text-warning":"bg-muted"}>{result.density_level} density {result.density_percent}%</Badge>}
                        {result.intrusion_detected!==undefined && <Badge className={result.intrusion_detected?"bg-destructive/20 text-destructive":"bg-green-500/20 text-green-400"}>{result.intrusion_detected?`INTRUSION: ${result.intruder_count}`:"Clear"}</Badge>}
                      </div>
                      {result.density_percent!==undefined && <Progress value={result.density_percent} className="h-2"/>}
                      {result.summary && <div className="flex flex-wrap gap-1">{Object.entries(result.summary).map(([k,v])=><Badge key={k} variant="secondary" className="text-xs">{k}: {v as number}</Badge>)}</div>}
                    </div>
                  )}
                </div>
              )}
            </CardContent></Card>
          </TabsContent>

          <TabsContent value="upload" className="space-y-4">
            <Card className="bg-card border-border"><CardContent className="p-4 space-y-4">
              <div className="flex flex-wrap gap-2">
                {([["detect","Object Detection"],["people","People Count"],["intrusion","Intrusion"]] as const).map(([k,l])=>(
                  <Button key={k} size="sm" variant={mode===k?"default":"outline"} onClick={()=>setMode(k)}>{l}</Button>
                ))}
              </div>
              <label className="block border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors">
                <Bot className="h-10 w-10 mx-auto mb-2 text-muted-foreground"/>
                <p className="text-sm text-muted-foreground">{busy?"Analysing…":"Click to upload image (JPEG/PNG)"}</p>
                <input type="file" accept="image/*" className="hidden" onChange={handleFile}/>
              </label>
              {previewUrl && (
                <div>
                  <canvas ref={canvasRef} className="w-full rounded border border-border"/>
                  {result && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      <Badge variant="outline">{result.detections.length} objects</Badge>
                      <Badge variant="outline">{result.inference_ms}ms</Badge>
                      {result.people_count!==undefined && <Badge className="bg-green-500/20 text-green-400">{result.people_count} people</Badge>}
                    </div>
                  )}
                </div>
              )}
            </CardContent></Card>
          </TabsContent>

          <TabsContent value="history">
            <div className="grid lg:grid-cols-2 gap-4">
              <Card className="bg-card border-border"><CardHeader className="pb-2"><CardTitle className="text-sm">Events by Type</CardTitle></CardHeader>
                <CardContent className="divide-y divide-border max-h-80 overflow-y-auto">
                  {(analytics?.by_type||[]).map((row: any)=>(
                    <div key={row.event_type} className="flex items-center justify-between py-2.5">
                      <span className="text-sm text-foreground">{row.event_type}</span>
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 bg-primary/30 rounded-full" style={{width:`${Math.min(100,row.count*5)}px`}}/>
                        <Badge variant="outline">{row.count}</Badge>
                      </div>
                    </div>
                  ))}
                  {!analytics?.by_type?.length && <p className="text-center py-8 text-sm text-muted-foreground">No analytics data yet</p>}
                </CardContent>
              </Card>
              <Card className="bg-card border-border"><CardHeader className="pb-2"><CardTitle className="text-sm">Events by Severity</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  {(analytics?.by_severity||[]).map((row: any)=>(
                    <div key={row.severity} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-foreground">{row.severity}</span>
                        <span className="text-muted-foreground">{row.count}</span>
                      </div>
                      <Progress value={Math.min(100,(row.count/Math.max(1,totalEvents))*100)} className="h-1.5"/>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};
export default AiAnalytics;
