import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiGet, apiPut } from "@/lib/api";

export interface EventRow {
  event_id: number; event_type: string; event_subtype: string | null;
  severity: string; title: string; description: string | null;
  camera_id: number | null; status: string;
  is_acknowledged: number; acknowledged_by: string | null; acknowledged_at: string | null;
  occurred_at: string; created_at: string;
  snapshot_path: string | null; video_clip_path: string | null;
  gps_latitude: number | null; gps_longitude: number | null;
  camera_name: string | null; location_description: string | null;
}

interface EventsResponse { events: EventRow[]; total: number; }

export function useEvents(filters?: {
  severity?: string; event_type?: string; is_acknowledged?: number;
  camera_id?: number; limit?: number; offset?: number;
}) {
  const params = new URLSearchParams();
  if (filters?.severity) params.set("severity", filters.severity);
  if (filters?.event_type) params.set("event_type", filters.event_type);
  if (filters?.is_acknowledged !== undefined) params.set("acknowledged", filters.is_acknowledged === 1 ? "true" : "false");
  if (filters?.camera_id) params.set("camera_id", String(filters.camera_id));
  if (filters?.limit) params.set("limit", String(filters.limit));
  if (filters?.offset) params.set("offset", String(filters.offset));
  const qs = params.toString();
  return useQuery<EventRow[]>({
    queryKey: ["events", filters],
    queryFn: async () => {
      const data = await apiGet<EventsResponse>(`/api/events${qs ? '?' + qs : ''}`);
      return data.events;
    },
    refetchInterval: 10000,
  });
}

export function useAcknowledgeEvent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (event_id: number) => apiPut(`/api/events/${event_id}/acknowledge`, {}),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["events"] }); qc.invalidateQueries({ queryKey: ["dashboard-stats"] }); },
  });
}
