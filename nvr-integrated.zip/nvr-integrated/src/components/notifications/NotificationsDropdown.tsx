import { useState, useEffect, useRef } from "react";
import { Bell, CheckCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useEvents, useAcknowledgeEvent } from "@/hooks/use-events";
import { API_BASE, tokenStore } from "@/lib/api";
import { formatDistanceToNow } from "date-fns";

const NotificationsDropdown = () => {
  const { data: events, refetch } = useEvents({ is_acknowledged: 0, limit: 20 });
  const acknowledge = useAcknowledgeEvent();
  const wsRef = useRef<WebSocket | null>(null);

  // WebSocket for real-time notifications
  useEffect(() => {
    const token = tokenStore.get();
    if (!token) return;
    const wsUrl = API_BASE.replace(/^http/, "ws") + `/ws?token=${encodeURIComponent(token)}`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;
    ws.onmessage = (msg) => {
      try {
        const data = JSON.parse(msg.data);
        if (data.type === "event.new" || data.type === "events.batch_acknowledged") {
          refetch();
        }
      } catch {}
    };
    ws.onerror = () => {};
    return () => { ws.close(); };
  }, [refetch]);

  const unread = events?.length || 0;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-4 w-4" />
          {unread > 0 && (
            <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-destructive text-[9px] font-bold text-white flex items-center justify-center">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 bg-card border-border p-0">
        <div className="flex items-center justify-between px-3 py-2 border-b border-border">
          <span className="text-sm font-medium">Notifications</span>
          {unread > 0 && <Badge variant="secondary" className="text-[10px]">{unread} unread</Badge>}
        </div>
        <div className="max-h-72 overflow-y-auto">
          {!events?.length && (
            <p className="text-sm text-muted-foreground text-center py-8">No unread notifications</p>
          )}
          {events?.map(ev => (
            <div key={ev.event_id} className="flex gap-2 p-3 border-b border-border/50 hover:bg-muted/30 last:border-0">
              <div className={`mt-1 w-2 h-2 rounded-full shrink-0 ${
                ev.severity === "CRITICAL" || ev.severity === "EMERGENCY" ? "bg-destructive" :
                ev.severity === "WARNING" ? "bg-yellow-400" : "bg-blue-400"}`} />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-foreground truncate">{ev.title}</p>
                <p className="text-[10px] text-muted-foreground">{formatDistanceToNow(new Date(ev.occurred_at), { addSuffix: true })}</p>
              </div>
              <Button size="sm" variant="ghost" className="h-5 w-5 p-0 shrink-0 text-muted-foreground"
                onClick={() => acknowledge.mutate({ event_id: ev.event_id })}>
                <CheckCheck className="h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default NotificationsDropdown;
