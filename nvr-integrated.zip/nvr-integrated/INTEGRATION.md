# NVR Integrated System — Setup Guide

## Architecture

```
mNVR C daemon (nvr_core) ──► NVR API proxy (/api/nvr/*)
      │                             │
      ▼                             ▼
storage/hls/cam_N/         Node.js API (port 3001)
storage/recordings/              │
      │                     ┌─────┴──────┐
      └──────────────────►  │  Frontend  │ (port 8080)
                            └─────┬──────┘
                            YOLO sidecar (port 8000)
```

## Quick Start

### 1. Database
```bash
cd server
psql -h localhost -U mnvr -d mnvr -f ../nvr_core-main/mnvr_schema.sql
```

### 2. Node.js API server
```bash
cd server
cp .env.example .env   # fill in DB credentials
npm install
npm start
```

### 3. YOLO AI sidecar (for on-video AI detection)
```bash
cd server/ai
pip install -r requirements.txt
uvicorn sidecar:app --host 0.0.0.0 --port 8000
```

### 4. mNVR C daemon (NVR core)
```bash
cd nvr_core-main
make
# Edit config/mnvr.conf — set db_path, storage_base, hls_base, camera IPs
sudo ./mnvrd -c config/mnvr.conf
```
The daemon will:
- Connect to cameras via ONVIF
- Record to `storage/recordings/cam_N/`
- Write HLS segments to `storage/hls/cam_N/stream.m3u8`
- Push health metrics to the DB via API

### 5. Frontend
```bash
npm install          # installs hls.js and all deps
npm run dev
```

## Camera Grid Live Streaming

The Camera Grid shows **real HLS streams** from the NVR daemon:
- Select **1×1 / 2×2 / 3×3 / 4×4** layout
- Toggle **AI On/Off** to enable per-tile YOLO detection overlay (requires YOLO sidecar)
- Click any tile to expand with full controls
- "Open in Player" launches the full Video Player with recording browser

## AI Detection

AI runs **on-stream** — no image upload required:
- CameraGrid: background YOLO inference every 3s per visible tile
- VideoPlayer: toggle AI button → bounding boxes overlaid on live/recorded video
- AiAnalytics: capture frame from any live camera → detect → results with canvas overlay

## Storage paths (from mnvr.conf)
```
storage_base  = /storage/recordings    # MP4 segments
hls_base      = /storage/hls          # HLS playlists + .ts segments
```
The API server reads from the same paths via:
- `STORAGE_PATH` env var (defaults to `./storage` beside server/)
- `/api/streaming/hls/:cameraId/stream.m3u8`
- `/api/streaming/recordings/:id/stream`

## Environment variables (server/.env)
```
PORT=3001
DB_HOST=localhost
DB_NAME=mnvr
DB_USER=mnvr
DB_PASSWORD=mnvr
JWT_SECRET=change-me
NVR_CORE_URL=http://localhost:8080    # mNVR C daemon API port
YOLO_SIDECAR_URL=http://localhost:8000
STORAGE_PATH=/storage
```
