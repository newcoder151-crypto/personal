#!/usr/bin/env bash
# One-shot installer for mNVR API + Web on a fresh Debian/Ubuntu VM.
# Run as root.
set -euo pipefail

INSTALL_DIR=/opt/mnvr-api
DB_NAME=mnvr
DB_USER=mnvr
DB_PASS="${DB_PASS:-mnvr}"   # override with env var

echo "==> Installing system packages..."
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    curl ca-certificates gnupg postgresql postgresql-client nginx git \
    python3 python3-venv build-essential

if ! command -v node >/dev/null 2>&1; then
  echo "==> Installing Node.js 20 LTS..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

echo "==> Creating mnvr user + storage dirs..."
id mnvr >/dev/null 2>&1 || useradd --system --create-home --shell /usr/sbin/nologin mnvr
mkdir -p /storage/recordings /storage/hls /storage/thumbnails /var/log/mnvr "$INSTALL_DIR"
chown -R mnvr:mnvr /storage /var/log/mnvr "$INSTALL_DIR"

echo "==> Setting up PostgreSQL..."
sudo -u postgres psql -tc "SELECT 1 FROM pg_user WHERE usename='$DB_USER'" | grep -q 1 \
  || sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';"
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" | grep -q 1 \
  || sudo -u postgres createdb -O "$DB_USER" "$DB_NAME"

echo "==> Importing nvr_core schema..."
PGPASSWORD="$DB_PASS" psql -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" -f "$INSTALL_DIR/server/sql/mnvr_schema.sql"

echo "==> Installing Node deps..."
cd "$INSTALL_DIR/server"
sudo -u mnvr npm ci --omit=dev || sudo -u mnvr npm install --omit=dev

if [ ! -f .env ]; then
  cp .env.example .env
  sed -i "s/^PGPASSWORD=.*/PGPASSWORD=$DB_PASS/" .env
  # generate strong jwt secret
  SECRET=$(head -c 48 /dev/urandom | base64 | tr -d '\n=' | tr '/+' '_-')
  sed -i "s|^JWT_SECRET=.*|JWT_SECRET=$SECRET|" .env
  chown mnvr:mnvr .env
  chmod 600 .env
fi

echo "==> Building web frontend..."
if [ -d "$INSTALL_DIR/web" ] && [ -f "$INSTALL_DIR/web/package.json" ]; then
  cd "$INSTALL_DIR/web"
  if [ ! -f .env ]; then
    echo "VITE_API_URL=" > .env   # same-origin, served by nginx
  fi
  sudo -u mnvr npm install
  sudo -u mnvr npm run build
fi

echo "==> Installing optional Python AI sidecar..."
if [ -d "$INSTALL_DIR/server/ai" ]; then
  cd "$INSTALL_DIR/server/ai"
  sudo -u mnvr python3 -m venv .venv
  sudo -u mnvr .venv/bin/pip install --upgrade pip
  sudo -u mnvr .venv/bin/pip install -r requirements.txt || \
    echo "WARN: AI sidecar install failed (probably no GPU). API will return 502 on /api/ai/detect until fixed."
fi

echo "==> Installing systemd units..."
cp "$INSTALL_DIR/deploy/mnvr-api.service" /etc/systemd/system/
cp "$INSTALL_DIR/deploy/mnvr-ai.service"  /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now mnvr-api.service
systemctl enable --now mnvr-ai.service || true   # AI is optional

echo "==> Configuring nginx..."
cp "$INSTALL_DIR/deploy/mnvr-web.nginx.conf" /etc/nginx/sites-available/mnvr-web
ln -sf /etc/nginx/sites-available/mnvr-web /etc/nginx/sites-enabled/mnvr-web
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo "==> Creating initial admin user (admin / Admin@123)..."
cd "$INSTALL_DIR/server"
sudo -u mnvr node scripts/create-admin.js admin 'Admin@123' 'System Admin' 'admin@local'

echo
echo "===================================================================="
echo " mNVR stack ready."
echo "   API     :  http://<host>/api/health"
echo "   Web     :  http://<host>/"
echo "   Swagger :  http://<host>/api/docs"
echo "   Login   :  admin / Admin@123  (CHANGE IT NOW)"
echo "===================================================================="
