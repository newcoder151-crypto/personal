# 🚂 Railway Mobile NVR System

A comprehensive Network Video Recorder (NVR) system for Indian Railways, featuring real-time camera monitoring, AI-powered analytics, event management, and video playback — built with React + Node.js + Supabase.

---

## 📋 Table of Contents

- [Architecture Overview](#architecture-overview)
- [Tech Stack](#tech-stack)
- [Getting Started](#getting-started)
- [API Reference](#api-reference)
  - [Auth APIs](#-auth-apis)
  - [Camera APIs](#-camera-apis)
  - [Event APIs](#-event-apis)
  - [Recording APIs](#-recording-apis)
  - [Streaming APIs](#-streaming-apis)
  - [User Management APIs](#-user-management-apis)
  - [System Config APIs](#-system-config-apis)
- [Supabase Edge Functions](#supabase-edge-functions)
- [Frontend Hooks](#frontend-react-query-hooks)
- [WebSocket Real-Time Events](#-websocket-real-time-events)
- [Database Schema](#database-schema)
- [Testing & Verification](#-testing--verification)
- [Deployment](#-deployment)

---

## Architecture Overview

```
┌──────────────────────────────────────────────────────┐
│                   FRONTEND (React)                   │
│  Dashboard │ Camera Grid │ Events │ Settings │ Admin │
│         React Query hooks ←→ Supabase Client         │
└──────────────────┬───────────────────────────────────┘
                   │
        ┌──────────┴──────────┐
        ▼                     ▼
┌───────────────┐   ┌──────────────────┐
│  Express API  │   │ Supabase Edge    │
│  (server/)    │   │ Functions        │
│  Port 8080    │   │ (serverless)     │
└───────┬───────┘   └────────┬─────────┘
        │                    │
        └────────┬───────────┘
                 ▼
        ┌────────────────┐
        │   Supabase DB  │
        │  (PostgreSQL)  │
        │  17 tables     │
        │  20+ enums     │
        └────────────────┘
```

**Two backend options:**
- **Node.js Express API** (`server/`) — self-hosted, WebSocket support, video streaming
- **Supabase Edge Functions** (`supabase/functions/`) — serverless, auto-scaling, managed

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, TypeScript, Vite 5, Tailwind CSS, shadcn/ui |
| State Management | TanStack React Query |
| Backend (Option 1) | Node.js, Express, JWT, WebSocket |
| Backend (Option 2) | Supabase Edge Functions (Deno) |
| Database | PostgreSQL via Supabase |
| Auth | Supabase Auth + JWT |
| Real-time | WebSocket (Express) / Supabase Realtime |
| Docs | OpenAPI 3.0 / Swagger UI |

---

## Getting Started

### Prerequisites

- Node.js 18+
- npm or yarn
- A Supabase project (or use Lovable Cloud)

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/railway-nvr.git
cd railway-nvr
```

### 2. Install frontend dependencies

```bash
npm install
```

### 3. Start the frontend

```bash
npm run dev
# Opens at http://localhost:5173
```

### 4. Set up the Express API server

```bash
cd server
npm install
cp .env.example .env
```

Edit `server/.env` with your credentials:

```env
PORT=8080
JWT_SECRET=your-super-secret-jwt-key-change-in-production
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
CORS_ORIGIN=http://localhost:5173
NODE_ENV=development
```

### 5. Start the Express API

```bash
npm run dev
# API at http://localhost:8080
# Swagger docs at http://localhost:8080/api/docs
# WebSocket at ws://localhost:8080/ws
```

### 6. Set up the database

Import the schema into your Supabase project:

```bash
# Option A: Use Supabase CLI
supabase db push

# Option B: Run the SQL manually in Supabase SQL Editor
# Copy contents of server/schema.sql
```

---

## API Reference

**Base URL:** `http://localhost:8080/api`

All authenticated endpoints require:
```
Authorization: Bearer <JWT_TOKEN>
```

---

### 🔐 Auth APIs

**Base path:** `/api/auth`

#### POST `/api/auth/register` — Register a new user

```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "operator@railway.com",
    "password": "secure123",
    "display_name": "Operator 1"
  }'
```

**Response (201):**
```json
{
  "message": "User registered successfully",
  "user": { "id": "uuid-here", "email": "operator@railway.com" },
  "token": "eyJhbGciOiJI..."
}
```

#### POST `/api/auth/login` — Login

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "operator@railway.com", "password": "secure123"}'
```

**Response (200):**
```json
{
  "token": "eyJhbGciOiJI...",
  "user": {
    "id": "uuid-here",
    "email": "operator@railway.com",
    "profile": { "display_name": "Operator 1", "avatar_url": null },
    "roles": ["viewer"]
  }
}
```

#### GET `/api/auth/me` — Get current user profile

```bash
curl http://localhost:8080/api/auth/me \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Response (200):**
```json
{
  "id": "uuid-here",
  "email": "operator@railway.com",
  "profile": { "display_name": "Operator 1" },
  "roles": ["viewer"]
}
```

#### POST `/api/auth/refresh` — Refresh JWT token

```bash
curl -X POST http://localhost:8080/api/auth/refresh \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Response (200):**
```json
{ "token": "new-eyJhbGciOiJI..." }
```

---

### 📹 Camera APIs

**Base path:** `/api/cameras`  
**Auth:** JWT required. Create/Update/Delete require `admin` role.

#### GET `/api/cameras` — List all cameras

```bash
curl "http://localhost:8080/api/cameras?status=ACTIVE&location=Coach&limit=16&offset=0" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `status` | string | Filter: `ACTIVE`, `INACTIVE`, `FAULTY`, `MAINTENANCE` |
| `location` | string | Search by location (partial match) |
| `limit` | number | Results per page (default: 100) |
| `offset` | number | Pagination offset (default: 0) |

**Response (200):**
```json
{
  "cameras": [
    {
      "camera_id": 1,
      "camera_name": "INT-CAM-01",
      "camera_type": "INTERIOR",
      "ip_address": "192.168.1.101",
      "status": "ACTIVE",
      "resolution_width": 1920,
      "resolution_height": 1080,
      "location_description": "Coach A1 - Entrance",
      "ptz_supported": 0,
      "audio_supported": 1
    }
  ],
  "total": 16,
  "limit": 100,
  "offset": 0
}
```

#### GET `/api/cameras/:id` — Get single camera

```bash
curl http://localhost:8080/api/cameras/1 \
  -H "Authorization: Bearer YOUR_TOKEN"
```

#### POST `/api/cameras` — Create camera (Admin only)

```bash
curl -X POST http://localhost:8080/api/cameras \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "EXT-CAM-17",
    "location": "Platform 3",
    "ip_address": "192.168.1.117",
    "rtsp_url": "rtsp://192.168.1.117:554/stream1",
    "has_audio": true,
    "resolution": "1080p",
    "fps": 30,
    "codec": "H.264"
  }'
```

#### PUT `/api/cameras/:id` — Update camera (Admin only)

```bash
curl -X PUT http://localhost:8080/api/cameras/1 \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"status": "MAINTENANCE"}'
```

#### DELETE `/api/cameras/:id` — Delete camera (Admin only)

```bash
curl -X DELETE http://localhost:8080/api/cameras/1 \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

**Response (200):**
```json
{ "message": "Camera deleted" }
```

---

### 🚨 Event APIs

**Base path:** `/api/events`  
**Auth:** JWT required. Create requires `operator` or `admin` role.

#### GET `/api/events` — Search events

```bash
curl "http://localhost:8080/api/events?severity=CRITICAL&acknowledged=false&camera_id=1&limit=50" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `camera_id` | number | Filter by camera ID |
| `severity` | string | `INFO`, `WARNING`, `ERROR`, `CRITICAL`, `EMERGENCY` |
| `event_type` | string | Filter by event type |
| `acknowledged` | boolean | Filter by acknowledgement status |
| `start_date` | ISO string | Events after this date |
| `end_date` | ISO string | Events before this date |
| `limit` | number | Results per page (default: 50) |
| `offset` | number | Pagination offset |

**Response (200):**
```json
{
  "events": [
    {
      "event_id": 1,
      "event_type": "MOTION_DETECTED",
      "title": "Suspicious Activity Detected",
      "severity": "CRITICAL",
      "status": "ACTIVE",
      "is_acknowledged": 0,
      "camera_id": 5,
      "occurred_at": "2026-04-16T10:30:00Z",
      "cameras": { "camera_name": "INT-CAM-05", "location_description": "Coach B2" }
    }
  ],
  "total": 6,
  "limit": 50,
  "offset": 0
}
```

#### GET `/api/events/:id` — Get single event

```bash
curl http://localhost:8080/api/events/1 \
  -H "Authorization: Bearer YOUR_TOKEN"
```

#### POST `/api/events` — Create event (Operator+)

```bash
curl -X POST http://localhost:8080/api/events \
  -H "Authorization: Bearer OPERATOR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "event_type": "MANUAL_ALERT",
    "title": "Suspicious package found",
    "severity": "CRITICAL",
    "camera_id": 5,
    "description": "Unattended bag detected near exit door"
  }'
```

#### PUT `/api/events/:id/acknowledge` — Acknowledge event

```bash
curl -X PUT http://localhost:8080/api/events/1/acknowledge \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Response (200):**
```json
{
  "event_id": 1,
  "is_acknowledged": 1,
  "acknowledged_by": "user-uuid",
  "acknowledged_at": "2026-04-16T11:00:00Z"
}
```

#### PUT `/api/events/batch/acknowledge` — Bulk acknowledge

```bash
curl -X PUT http://localhost:8080/api/events/batch/acknowledge \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"event_ids": [1, 2, 3]}'
```

**Response (200):**
```json
{ "acknowledged": 3, "events": [...] }
```

---

### 🎬 Recording APIs

**Base path:** `/api/recordings`  
**Auth:** JWT required.

#### GET `/api/recordings` — Search recordings

```bash
curl "http://localhost:8080/api/recordings?camera_id=1&start_date=2026-04-01&limit=20" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Query Parameters:**
| Param | Type | Description |
|-------|------|-------------|
| `camera_id` | number | Filter by camera |
| `status` | string | `RECORDING`, `COMPLETED`, `EXPORTED`, `ARCHIVED`, `DELETED` |
| `start_date` | ISO string | Recordings after this date |
| `end_date` | ISO string | Recordings before this date |
| `limit` | number | Results per page (default: 50) |
| `offset` | number | Pagination offset |

#### GET `/api/recordings/:id` — Get recording details

```bash
curl http://localhost:8080/api/recordings/1 \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

### 🎥 Streaming APIs

**Base path:** `/api/streaming`  
**Auth:** JWT required.

#### GET `/api/streaming/recordings/:id/stream` — Stream video

Supports HTTP Range requests for seeking.

```bash
# Full stream
curl http://localhost:8080/api/streaming/recordings/1/stream \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -o video.mp4

# Range request (for video player seeking)
curl http://localhost:8080/api/streaming/recordings/1/stream \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Range: bytes=0-1048576"
```

#### GET `/api/streaming/recordings/:id/thumbnail` — Get thumbnail

```bash
curl http://localhost:8080/api/streaming/recordings/1/thumbnail \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -o thumbnail.jpg
```

#### GET `/api/streaming/recordings/:id/download` — Download recording

```bash
curl http://localhost:8080/api/streaming/recordings/1/download \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -o recording.mp4
```

---

### 👤 User Management APIs

**Base path:** `/api/users`  
**Auth:** Admin role required for all endpoints.

#### GET `/api/users` — List all users

```bash
curl http://localhost:8080/api/users \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

**Response (200):**
```json
{
  "users": [
    {
      "user_id": "uuid",
      "display_name": "Admin User",
      "roles": ["admin"]
    }
  ],
  "total": 5
}
```

#### GET `/api/users/:id` — Get single user

```bash
curl http://localhost:8080/api/users/USER_UUID \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

#### POST `/api/users` — Create user

```bash
curl -X POST http://localhost:8080/api/users \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@railway.com",
    "password": "secure123",
    "display_name": "New Operator",
    "role": "operator"
  }'
```

#### PUT `/api/users/:id` — Update user & roles

```bash
curl -X PUT http://localhost:8080/api/users/USER_UUID \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "profile": { "display_name": "Senior Operator" },
    "roles": ["operator", "viewer"]
  }'
```

#### DELETE `/api/users/:id` — Delete user

```bash
curl -X DELETE http://localhost:8080/api/users/USER_UUID \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

---

### ⚙️ System Config APIs

**Base path:** `/api/config`  
**Auth:** JWT required. Update requires `admin` role.

#### GET `/api/config/status` — System status dashboard

```bash
curl http://localhost:8080/api/config/status \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Response (200):**
```json
{
  "system": {
    "uptime_seconds": 86400,
    "version": "2.1.0",
    "hostname": "nvr-unit-001",
    "node_version": "v18.17.0",
    "memory": { "rss": 52428800, "heapUsed": 25165824 }
  },
  "cameras": { "total": 16, "ACTIVE": 14, "FAULTY": 1, "MAINTENANCE": 1 },
  "events": { "unacknowledged": 3, "by_severity": { "CRITICAL": 1, "WARNING": 2 } },
  "recordings": { "total": 1250 },
  "health": { "cpu_usage_percent": 45.2, "memory_usage_percent": 62.0, "health_status": "HEALTHY" }
}
```

#### GET `/api/config` — List all config keys

```bash
curl http://localhost:8080/api/config \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Response (200):**
```json
{
  "config": [
    { "config_key": "device_id", "config_value": "NVR-001", "config_type": "STRING", "is_readonly": 1 },
    { "config_key": "retention_days", "config_value": "30", "config_type": "INTEGER", "is_readonly": 0 },
    { "config_key": "max_cameras", "config_value": "16", "config_type": "INTEGER", "is_readonly": 1 },
    { "config_key": "motion_detection", "config_value": "false", "config_type": "BOOLEAN", "is_readonly": 0 },
    { "config_key": "cloud_upload_enabled", "config_value": "false", "config_type": "BOOLEAN", "is_readonly": 0 },
    { "config_key": "ntp_server", "config_value": "0.pool.ntp.org", "config_type": "STRING", "is_readonly": 0 },
    { "config_key": "storage_threshold_gb", "config_value": "50", "config_type": "INTEGER", "is_readonly": 0 }
  ]
}
```

#### GET `/api/config/:key` — Get single config value

```bash
curl http://localhost:8080/api/config/retention_days \
  -H "Authorization: Bearer YOUR_TOKEN"
```

#### PUT `/api/config/:key` — Update config (Admin only)

```bash
curl -X PUT http://localhost:8080/api/config/retention_days \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"config_value": "60"}'
```

---

## Supabase Edge Functions

These are serverless alternatives to the Express API, deployed automatically.

| Function | Methods | Path | Description |
|----------|---------|------|-------------|
| `cameras` | GET, POST, PUT, DELETE | `/functions/v1/cameras` | Camera CRUD operations |
| `events` | GET, POST, PUT | `/functions/v1/events` | Event management & acknowledge |
| `recordings` | GET | `/functions/v1/recordings` | Recording search & metadata |
| `users` | GET, POST, PUT, DELETE | `/functions/v1/users` | User management (admin) |
| `system-config` | GET, PUT | `/functions/v1/system-config` | System configuration |
| `api-docs` | GET | `/functions/v1/api-docs` | OpenAPI 3.0 spec |

**Usage:**
```typescript
import { supabase } from "@/integrations/supabase/client";

// Call via Supabase client
const { data } = await supabase.functions.invoke('cameras', { method: 'GET' });

// Or via direct URL
const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
const res = await fetch(
  `https://${projectId}.supabase.co/functions/v1/cameras`,
  { headers: { Authorization: `Bearer ${token}` } }
);
```

---

## Frontend React Query Hooks

The frontend uses React Query hooks that connect directly to Supabase:

| Hook | File | Purpose |
|------|------|---------|
| `useCameras()` | `src/hooks/use-cameras.ts` | Fetch cameras, add/update/delete |
| `useEvents()` | `src/hooks/use-events.ts` | Fetch events, acknowledge alerts |
| `useRecordings()` | `src/hooks/use-recordings.ts` | Search recordings by camera/date |
| `useSystemConfig()` | `src/hooks/use-system-config.ts` | Read/write system configuration |
| `useUsers()` | `src/hooks/use-users.ts` | User management (admin) |
| `useDashboardStats()` | `src/hooks/use-dashboard-stats.ts` | Dashboard KPI aggregation |

**Example usage:**
```tsx
import { useCameras } from "@/hooks/use-cameras";

function CameraGrid() {
  const { data: cameras, isLoading } = useCameras();

  if (isLoading) return <Spinner />;
  return cameras.map(cam => <CameraTile key={cam.camera_id} camera={cam} />);
}
```

---

## 🔌 WebSocket Real-Time Events

**URL:** `ws://localhost:8080/ws?token=YOUR_JWT_TOKEN`

### Events Pushed by Server

| Event Type | Trigger | Payload |
|------------|---------|---------|
| `camera.created` | New camera added | Full camera object |
| `camera.status` | Camera status change | Updated camera object |
| `camera.deleted` | Camera removed | `{ id: camera_id }` |
| `event.new` | New alert/incident | Full event object |
| `event.acknowledged` | Event acknowledged | Updated event object |
| `system.alert` | System health warning | Alert details |

### Client Example

```javascript
const ws = new WebSocket('ws://localhost:8080/ws?token=YOUR_JWT');

ws.onopen = () => console.log('Connected to NVR WebSocket');

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  switch (data.type) {
    case 'event.new':
      showNotification(data.data.title, data.data.severity);
      break;
    case 'camera.status':
      updateCameraStatus(data.data);
      break;
  }
};

ws.onclose = () => console.log('Disconnected — will auto-reconnect');
```

---

## Database Schema

The full schema is in `server/schema.sql`. Key tables:

| Table | Description | Rows |
|-------|-------------|------|
| `cameras` | Camera devices (16 supported) | IP, RTSP, resolution, codec, PTZ |
| `camera_health` | Real-time camera metrics | FPS, bitrate, latency, temperature |
| `microphones` | Audio input devices | Codec, sample rate, channels |
| `camera_mic_mapping` | Camera-microphone pairing | Sync offset, calibration |
| `events` | Alerts and incidents | Severity, GPS, snapshots, clips |
| `recordings` | Video file metadata | Duration, codec, GPS, watermark |
| `recording_failure_alarms` | Recording failure alerts | Auto-recovery, manual action |
| `nvr_users` | NVR local users | Roles, login tracking, lockout |
| `user_sessions` | Active sessions | Token, device info, expiry |
| `user_permissions` | Fine-grained permissions | Resource-level access control |
| `profiles` | Supabase Auth user profiles | Display name, avatar |
| `user_roles` | Supabase Auth role assignments | admin, operator, viewer |
| `audit_log` | All user actions | Action type, old/new values |
| `system_config` | Key-value configuration | Retention, NTP, thresholds |
| `system_health` | Hardware metrics | CPU, memory, disk, network, GPS |
| `system_logs` | Application logs | Level, component, stack trace |
| `recording_presets` | Recording quality presets | Codec, resolution, FPS, bitrate |
| `storage_cleanup_log` | Storage cleanup history | Files deleted, space freed |
| `discovered_devices` | ONVIF device discovery | MAC, hostname, RTSP port |

### Enums (20+)

`camera_type_enum`, `device_status_enum`, `video_codec_enum`, `audio_codec_enum`, `event_severity_enum`, `event_status_enum`, `recording_mode_enum`, `recording_status_enum`, `user_role_enum`, `permission_level_enum`, `action_type_enum`, `log_level_enum`, `health_status_enum`, `gps_fix_enum`, `time_source_enum`, `failure_type_enum`, `cleanup_trigger_enum`, `discovery_method_enum`, and more.

---

## 🧪 Testing & Verification

### Quick Health Check

```bash
curl http://localhost:8080/api/health
```

**Expected:**
```json
{
  "status": "ok",
  "version": "2.1.0",
  "service": "railway-nvr-api",
  "uptime": 120.5,
  "timestamp": "2026-04-16T12:00:00Z"
}
```

### Full Test Sequence

```bash
# 1. Health check
curl http://localhost:8080/api/health

# 2. Register a user
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@railway.com","password":"test123","display_name":"Test User"}'

# 3. Login and save the token
TOKEN=$(curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@railway.com","password":"test123"}' | jq -r '.token')

# 4. Get current user profile
curl http://localhost:8080/api/auth/me -H "Authorization: Bearer $TOKEN"

# 5. List cameras
curl http://localhost:8080/api/cameras -H "Authorization: Bearer $TOKEN"

# 6. List events
curl "http://localhost:8080/api/events?limit=10" -H "Authorization: Bearer $TOKEN"

# 7. Get system status
curl http://localhost:8080/api/config/status -H "Authorization: Bearer $TOKEN"

# 8. List config
curl http://localhost:8080/api/config -H "Authorization: Bearer $TOKEN"

# 9. Test Swagger UI
open http://localhost:8080/api/docs
```

### Verification Checklist

| # | Test | Command / Action | Expected Result |
|---|------|-----------------|-----------------|
| 1 | Server running | `curl localhost:8080/api/health` | `{"status":"ok"}` |
| 2 | Swagger docs | Open `localhost:8080/api/docs` | Interactive API explorer |
| 3 | Registration | POST `/api/auth/register` | 201 + token |
| 4 | Login | POST `/api/auth/login` | 200 + token + user |
| 5 | Camera list | GET `/api/cameras` | 16 cameras returned |
| 6 | Camera filter | GET `/api/cameras?status=ACTIVE` | Filtered results |
| 7 | Events list | GET `/api/events` | Events array + total |
| 8 | Severity filter | GET `/api/events?severity=CRITICAL` | Only critical events |
| 9 | Acknowledge | PUT `/api/events/1/acknowledge` | `is_acknowledged: 1` |
| 10 | Bulk ack | PUT `/api/events/batch/acknowledge` | Multiple updated |
| 11 | System status | GET `/api/config/status` | CPU, memory, camera counts |
| 12 | Config read | GET `/api/config` | All config key-values |
| 13 | Config update | PUT `/api/config/retention_days` | Updated value |
| 14 | User list | GET `/api/users` (admin) | User array + roles |
| 15 | WebSocket | Connect to `ws://localhost:8080/ws` | Connection established |
| 16 | Role check | Non-admin → POST `/api/cameras` | 403 Forbidden |
| 17 | Frontend loads | Open `http://localhost:5173` | Dashboard with live data |
| 18 | Camera grid | Navigate to Cameras page | 16 camera tiles |

---

## 🚀 Deployment

### Frontend (Lovable)

The frontend is automatically deployed via Lovable. Click **Share → Publish** to get a live URL.

### Express API Server

#### Option A: Railway.app

```bash
cd server
railway login
railway init
railway up
```

#### Option B: Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --production
COPY . .
EXPOSE 8080
CMD ["node", "src/index.js"]
```

```bash
docker build -t railway-nvr-api ./server
docker run -p 8080:8080 --env-file server/.env railway-nvr-api
```

#### Option C: Any Node.js host

```bash
cd server
npm ci --production
NODE_ENV=production node src/index.js
```

---

## 📄 License

Proprietary — Indian Railways NVR System

---

## 🤝 Support

For issues or feature requests, open a GitHub issue or contact the development team.

---

## 🔔 Real-Time Notifications (Supabase Realtime)

The bell icon in the header is **fully real-time**. New events broadcast instantly via Supabase Realtime — no refresh needed.

### Tables enabled for Realtime
- `events` — alerts/incidents push live to the bell icon
- `cameras` — status changes (online/offline) update the grid live
- `camera_health` — per-camera FPS/bitrate/errors
- `system_health` — CPU, RAM, disk metrics
- `recording_failure_alarms` — recording failures

### Test it end-to-end
```bash
# Insert a test event from psql or the Supabase SQL editor:
INSERT INTO events (event_type, severity, title, description, camera_id)
VALUES ('intrusion_detected', 'CRITICAL', 'Test Alert', 'Triggered manually', 1);
```
The bell badge increments instantly and a toast appears. Click the bell to view → "Ack all" to clear.

---

## 🔐 Authorize Swagger UI with Bearer Token

Swagger UI is at **`http://localhost:8080/api/docs`** (when running the Express server).

### Step 1 — Get your JWT
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"YourPassword123"}'
```
Response:
```json
{ "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6Ik...", "user": { ... } }
```
Copy the `token` value.

### Step 2 — Authorize in Swagger
1. Open `http://localhost:8080/api/docs`
2. Click the green **Authorize** button (top right)
3. In the `bearerAuth` field, paste: `eyJhbGc...` (just the token, **no `Bearer ` prefix**)
4. Click **Authorize** → **Close**
5. Every "Try it out" request now includes `Authorization: Bearer <token>` automatically

### Step 3 — Test an endpoint
- Expand `GET /api/cameras` → Try it out → Execute → 200 OK with camera list
- Expand `POST /api/events` → fill body → Execute → 201 Created
- Open the bell icon in your browser app → new event appears live ✅

---

## 🧪 Testing the Entire Program

| Layer | How to test |
|-------|-------------|
| **Database** | Open Lovable Cloud → Backend → Tables → verify 17 tables seeded |
| **Frontend** | Visit preview URL → Login → Dashboard, Camera Grid, Events all load |
| **Express API** | `cd server && npm run dev` → `curl http://localhost:8080/api/health` |
| **Swagger UI** | `http://localhost:8080/api/docs` → Authorize with JWT → Try endpoints |
| **WebSocket** | Browser DevTools → Network → WS tab → connect to `ws://localhost:8080/ws?token=JWT` |
| **Realtime bell** | SQL `INSERT INTO events...` → bell badge bumps + toast fires within 1s |
| **Edge functions** | `curl https://obdnuowluomombxdqyih.supabase.co/functions/v1/cameras -H "Authorization: Bearer $ANON_KEY"` |

### Quick smoke test (one-liner)
```bash
TOKEN=$(curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}' | jq -r .token)

curl -H "Authorization: Bearer $TOKEN" http://localhost:8080/api/cameras | jq .
curl -H "Authorization: Bearer $TOKEN" http://localhost:8080/api/events  | jq .
curl -H "Authorization: Bearer $TOKEN" http://localhost:8080/api/config/status | jq .
```

If all three return JSON with data → backend, auth, and DB are all healthy. ✅

---

## 🎥 Video playback (Video Player page)

The `/video-player` page now plays real videos served by the Node streaming
route (`server/src/routes/streaming.js`).

**How the connection works**

1. The page lists rows from the `recordings` table via Supabase.
2. When you pick one, the frontend builds a URL:
   `http://localhost:8080/api/streaming/recordings/<id>/stream?token=<JWT>`
3. The Node server validates the JWT (header **or** `?token=`), reads
   `recordings.file_path` from the DB, and streams the MP4 with HTTP range
   support — so seeking just works.

**To test it end-to-end**

```bash
# 1. Make sure a video file exists on disk and a row points at it
mkdir -p /tmp/nvr && cp ~/sample.mp4 /tmp/nvr/cam1_001.mp4
# Then in Lovable Cloud SQL editor:
INSERT INTO recordings (camera_id, file_name, file_path, start_timestamp, status, recording_mode)
VALUES (1, 'cam1_001.mp4', '/tmp/nvr/cam1_001.mp4', now(), 'COMPLETED', 'CONTINUOUS');

# 2. Start the Node server
cd server && npm install && npm run dev

# 3. Open the app → /video-player → recording appears in the dropdown → press play
```

**Override the API base URL** (e.g. when the server isn't on localhost):
```bash
echo 'VITE_API_SERVER_URL=https://nvr.example.com' >> .env.local
```

---

## 🧠 YOLO object detection (real model, not mocked)

A Python sidecar runs Ultralytics YOLOv8 and the Node server proxies to it
at `POST /api/ai/detect`.

**Setup (one-time)**
```bash
cd server/ai
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn sidecar:app --host 0.0.0.0 --port 8000
```

**Verify**
```bash
curl http://localhost:8000/health
# → {"status":"ok","default_model":"yolov8n.pt", ...}

# via Node proxy (needs JWT)
curl -H "Authorization: Bearer $TOKEN" \
     -F image=@/tmp/frame.jpg \
     http://localhost:8080/api/ai/detect | jq .
```

**Where it's wired in the UI**

- Video Player page → toggle **AI On/Off** → live boxes are drawn on the
  `<video>` every ~1.2 s. If the sidecar is offline, a red badge shows.
- Use the same `detectObjects()` helper from `src/lib/api-server.ts` to add
  detection to the Camera Grid, Search, or any other page.

Full details, GPU notes, and configuration: **[server/ai/README.md](server/ai/README.md)**

---

## 👤 User sign-in data & roles in the database

A database trigger (`handle_new_user`) now fires on every new auth signup:

- creates a row in **`profiles`** (`display_name` from signup metadata or email),
- inserts a default `viewer` row in **`user_roles`**.

So every signed-in user immediately has both a profile and a role — visible
in the **User Admin** page. Promote anyone to `operator` / `admin` from there.

Verify after signing up a new user:
```sql
SELECT p.display_name, p.user_id, ur.role
FROM profiles p
LEFT JOIN user_roles ur ON ur.user_id = p.user_id
ORDER BY p.created_at DESC LIMIT 5;
```
