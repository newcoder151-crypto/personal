import { createContext, useCallback, useContext, useEffect, useState, ReactNode } from "react";
import { api, tokenStore, MnvrUser } from "@/lib/api";

interface AuthContextType {
  user: MnvrUser | null;
  loading: boolean;
  signIn: (username: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (username: string, password: string, fullName: string, email?: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);
export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<MnvrUser | null>(tokenStore.getUser());
  const [loading, setLoading] = useState<boolean>(!!tokenStore.getAccess() && !tokenStore.getUser());

  const refresh = useCallback(async () => {
    if (!tokenStore.getAccess()) { setUser(null); setLoading(false); return; }
    try {
      const me = await api<MnvrUser>("/api/auth/me");
      tokenStore.set(tokenStore.getAccess()!, undefined, me);
      setUser(me);
    } catch {
      tokenStore.clear(); setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      setUser(detail?.user ?? tokenStore.getUser());
    };
    window.addEventListener("mnvr:auth-changed", handler);
    return () => window.removeEventListener("mnvr:auth-changed", handler);
  }, []);

  const signIn: AuthContextType["signIn"] = async (username, password) => {
    try {
      const r = await api<{ access_token: string; refresh_token: string; user: MnvrUser }>(
        "/api/auth/login", { method: "POST", body: { username, password } });
      tokenStore.set(r.access_token, r.refresh_token, r.user);
      setUser(r.user);
      return { error: null };
    } catch (e) { return { error: e as Error }; }
  };

  const signUp: AuthContextType["signUp"] = async (username, password, fullName, email) => {
    try {
      await api("/api/auth/register", {
        method: "POST",
        body: { username, password, full_name: fullName, email },
      });
      return { error: null };
    } catch (e) { return { error: e as Error }; }
  };

  const signOut = async () => {
    try { await api("/api/auth/logout", { method: "POST" }); } catch {}
    tokenStore.clear(); setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut, refresh }}>
      {children}
    </AuthContext.Provider>
  );
};
