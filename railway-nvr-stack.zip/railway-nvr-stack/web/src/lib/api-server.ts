// Backwards-compat shim. The whole API surface now lives in src/lib/api.ts.
export * from "./api";
