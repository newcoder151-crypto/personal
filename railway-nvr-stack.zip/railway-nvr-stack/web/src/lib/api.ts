/**
 * Central API client for the mNVR Node backend.
 * Replaces the old @supabase/supabase-js + custom Edge Functions.
 *
 * Token storage: localStorage["mnvr_access_token"] / ["mnvr_refresh_token"]
 * Auth events: dispatched on `window` as "mnvr:auth-changed" with { user|null }.
 */

export const API_URL =
  (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, "") ||
  (typeof window !== "undefined" ? window.location.origin : "");

const ACCESS_KEY = "mnvr_access_token";
const REFRESH_KEY = "mnvr_refresh_token";
const USER_KEY = "mnvr_user";

export type Role = "ADMIN" | "OPERATOR" | "MAINTENANCE" | "VIEWER" | "API_CLIENT";

export interface MnvrUser {
  user_id: number;
  username: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  role: Role;
  is_active: boolean;
  must_change_password: boolean;
  last_login_at: string | null;
  created_at: string;
}

export const tokenStore = {
  getAccess()  { return localStorage.getItem(ACCESS_KEY); },
  getRefresh() { return localStorage.getItem(REFRESH_KEY); },
  getUser(): MnvrUser | null {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  },
  set(access: string, refresh: string | undefined, user: MnvrUser | undefined) {
    if (access)  localStorage.setItem(ACCESS_KEY, access);
    if (refresh) localStorage.setItem(REFRESH_KEY, refresh);
    if (user)    localStorage.setItem(USER_KEY, JSON.stringify(user));
    window.dispatchEvent(new CustomEvent("mnvr:auth-changed", { detail: { user: user ?? this.getUser() } }));
  },
  clear() {
    localStorage.removeItem(ACCESS_KEY);
    localStorage.removeItem(REFRESH_KEY);
    localStorage.removeItem(USER_KEY);
    window.dispatchEvent(new CustomEvent("mnvr:auth-changed", { detail: { user: null } }));
  },
};

let refreshing: Promise<string | null> | null = null;

async function doRefresh(): Promise<string | null> {
  const rt = tokenStore.getRefresh();
  if (!rt) return null;
  try {
    const r = await fetch(`${API_URL}/api/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: rt }),
    });
    if (!r.ok) { tokenStore.clear(); return null; }
    const j = await r.json();
    tokenStore.set(j.access_token, undefined, undefined);
    return j.access_token as string;
  } catch {
    tokenStore.clear();
    return null;
  }
}

export interface ApiOpts extends Omit<RequestInit, "body"> {
  body?: unknown;
  query?: Record<string, string | number | boolean | undefined | null>;
  raw?: boolean;
}

export async function api<T = any>(path: string, opts: ApiOpts = {}): Promise<T> {
  const url = new URL(path.startsWith("http") ? path : `${API_URL}${path}`);
  if (opts.query) {
    for (const [k, v] of Object.entries(opts.query)) {
      if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, String(v));
    }
  }

  const headers: Record<string, string> = {
    Accept: "application/json",
    ...((opts.headers as Record<string, string>) || {}),
  };
  const isFormData = opts.body instanceof FormData;
  if (opts.body !== undefined && !isFormData && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }
  let token = tokenStore.getAccess();
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const init: RequestInit = {
    method: opts.method || "GET",
    headers,
    body: opts.body === undefined ? undefined : isFormData ? (opts.body as FormData) : JSON.stringify(opts.body),
    credentials: "include",
    signal: opts.signal,
  };

  let resp = await fetch(url.toString(), init);

  if (resp.status === 401 && token) {
    refreshing = refreshing || doRefresh();
    const newTok = await refreshing;
    refreshing = null;
    if (newTok) {
      headers["Authorization"] = `Bearer ${newTok}`;
      resp = await fetch(url.toString(), { ...init, headers });
    }
  }

  if (!resp.ok) {
    let msg = `HTTP ${resp.status}`;
    try { const j = await resp.json(); msg = j.error || j.message || msg; } catch {}
    throw new Error(msg);
  }
  if (opts.raw) return resp as unknown as T;
  if (resp.status === 204) return undefined as unknown as T;
  const ct = resp.headers.get("content-type") || "";
  return (ct.includes("application/json") ? await resp.json() : (await resp.text() as unknown)) as T;
}

/* ------------------------------------------------------------------ */
/* Streaming helpers                                                   */
/* ------------------------------------------------------------------ */

export function getRecordingStreamUrl(recordingId: number | string): string {
  const t = tokenStore.getAccess() ?? "";
  const u = new URL(`${API_URL}/api/streaming/recordings/${recordingId}/stream`);
  if (t) u.searchParams.set("token", t);
  return u.toString();
}

export function getRecordingDownloadUrl(recordingId: number | string): string {
  const t = tokenStore.getAccess() ?? "";
  const u = new URL(`${API_URL}/api/streaming/recordings/${recordingId}/download`);
  if (t) u.searchParams.set("token", t);
  return u.toString();
}

export function getRecordingThumbnailUrl(recordingId: number | string): string {
  const t = tokenStore.getAccess() ?? "";
  const u = new URL(`${API_URL}/api/streaming/recordings/${recordingId}/thumbnail`);
  if (t) u.searchParams.set("token", t);
  return u.toString();
}

/** HLS master playlist for live camera (multi-rendition adaptive). */
export function getCameraHlsUrl(cameraId: number | string): string {
  const t = tokenStore.getAccess() ?? "";
  const u = new URL(`${API_URL}/api/hls/${cameraId}/master.m3u8`);
  if (t) u.searchParams.set("token", t);
  return u.toString();
}

/* ------------------------------------------------------------------ */
/* AI                                                                  */
/* ------------------------------------------------------------------ */

export async function detectObjects(blob: Blob, opts?: { conf?: number; model?: string }) {
  const fd = new FormData();
  fd.append("image", blob, "frame.jpg");
  if (opts?.conf)  fd.append("conf",  String(opts.conf));
  if (opts?.model) fd.append("model", opts.model);
  return api<{
    detections: { label: string; confidence: number; bbox: [number, number, number, number] }[];
    inference_ms: number;
  }>("/api/ai/detect", { method: "POST", body: fd });
}

/* ------------------------------------------------------------------ */
/* Realtime — WebSocket client                                          */
/* ------------------------------------------------------------------ */

export type WsMessage = { type: string; data?: any; ts?: number };

export function openEventStream(onMessage: (m: WsMessage) => void): () => void {
  const t = tokenStore.getAccess();
  if (!t) return () => {};
  const wsUrl = (API_URL || window.location.origin)
    .replace(/^http/, "ws") + `/ws?token=${encodeURIComponent(t)}`;

  let ws: WebSocket | null = null;
  let stopped = false;
  let backoff = 1000;

  const connect = () => {
    if (stopped) return;
    ws = new WebSocket(wsUrl);
    ws.onopen = () => { backoff = 1000; };
    ws.onmessage = (ev) => {
      try { onMessage(JSON.parse(ev.data)); } catch {}
    };
    ws.onclose = () => {
      if (stopped) return;
      setTimeout(connect, backoff);
      backoff = Math.min(backoff * 2, 30_000);
    };
    ws.onerror = () => { try { ws?.close(); } catch {} };
  };
  connect();

  return () => { stopped = true; try { ws?.close(); } catch {} };
}

/* Backwards-compat exports kept for old code that imported from api-server.ts */
export const API_SERVER_URL = API_URL;
