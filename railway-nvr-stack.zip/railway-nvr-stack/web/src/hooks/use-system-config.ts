import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";

export interface SystemConfig {
  id: number;
  config_key: string;
  config_value: string;
  config_type: "STRING" | "INTEGER" | "BOOLEAN" | "JSON";
  description: string | null;
  is_readonly: number;
  last_modified_at: string;
  last_modified_by: string | null;
}

export function useSystemConfig() {
  return useQuery({
    queryKey: ["system_config"],
    queryFn: () => api<SystemConfig[]>("/api/config"),
  });
}

export function useConfigValue(configKey: string) {
  return useQuery({
    queryKey: ["system_config", configKey],
    queryFn: () => api<SystemConfig>(`/api/config/${encodeURIComponent(configKey)}`),
  });
}

export function useUpdateConfig() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ configKey, configValue, description, configType }:
      { configKey: string; configValue: string; description?: string; configType?: SystemConfig["config_type"] }) =>
      api(`/api/config/${encodeURIComponent(configKey)}`, {
        method: "PUT",
        body: { config_value: configValue, description, config_type: configType },
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["system_config"] }),
  });
}
