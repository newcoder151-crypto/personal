import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";

export interface EventRow {
  event_id: number;
  event_type: string;
  event_subtype: string | null;
  severity: "INFO" | "WARNING" | "ERROR" | "CRITICAL" | "EMERGENCY";
  source_device_type: string | null;
  source_device_id: number | null;
  title: string;
  description: string | null;
  event_data: string | null;
  camera_id: number | null;
  status: "ACTIVE" | "ACKNOWLEDGED" | "RESOLVED" | "DISMISSED";
  is_acknowledged: number;
  acknowledged_by: string | null;
  acknowledged_at: string | null;
  occurred_at: string;
  cameras?: { camera_name: string; location_description: string | null };
}

export function useEvents(filters?: { severity?: string; is_acknowledged?: number; camera_id?: number; status?: string; limit?: number }) {
  return useQuery({
    queryKey: ["events", filters],
    queryFn: async () => {
      const r = await api<{ events: EventRow[]; total: number }>("/api/events", { query: filters });
      return r.events;
    },
  });
}

export function useAcknowledgeEvent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ event_id }: { event_id: number; userId?: string }) =>
      api(`/api/events/${event_id}/acknowledge`, { method: "POST" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["events"] });
      qc.invalidateQueries({ queryKey: ["notifications"] });
      qc.invalidateQueries({ queryKey: ["dashboard-stats"] });
    },
  });
}

export function useAcknowledgeAll() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => api(`/api/events/acknowledge-all`, { method: "POST" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["events"] });
      qc.invalidateQueries({ queryKey: ["notifications"] });
      qc.invalidateQueries({ queryKey: ["dashboard-stats"] });
    },
  });
}
