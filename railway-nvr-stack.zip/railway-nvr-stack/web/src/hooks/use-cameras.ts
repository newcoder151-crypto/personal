import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";

export interface Camera {
  camera_id: number;
  camera_name: string;
  camera_type: "INTERIOR" | "EXTERIOR" | "DOOR" | "DRIVER_CAB";
  ip_address: string;
  rtsp_url: string;
  rtsp_port?: number;
  status: "ACTIVE" | "INACTIVE" | "FAULTY" | "MAINTENANCE";
  location_description?: string | null;
  resolution_width?: number;
  resolution_height?: number;
  target_fps?: number;
  video_codec?: string;
  manufacturer?: string | null;
  model?: string | null;
  audio_supported?: number;
  ptz_supported?: number;
  hls_playlist_url?: string | null;
  rec_output_dir?: string | null;
  hls_output_dir?: string | null;
  last_seen_at?: string | null;
  added_at?: string;
  updated_at?: string;
}

export function useCameras() {
  return useQuery({
    queryKey: ["cameras"],
    queryFn: async () => {
      const r = await api<{ cameras: Camera[]; total: number }>("/api/cameras");
      return r.cameras;
    },
  });
}

export function useCamera(id: number | undefined) {
  return useQuery({
    queryKey: ["cameras", id],
    enabled: !!id,
    queryFn: () => api<Camera>(`/api/cameras/${id}`),
  });
}

export function useCreateCamera() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (camera: Partial<Camera>) =>
      api<Camera>("/api/cameras", { method: "POST", body: camera }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cameras"] }),
  });
}

export function useUpdateCamera() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ camera_id, ...updates }: Partial<Camera> & { camera_id: number }) =>
      api<Camera>(`/api/cameras/${camera_id}`, { method: "PUT", body: updates }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cameras"] }),
  });
}

export function useDeleteCamera() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (camera_id: number) =>
      api(`/api/cameras/${camera_id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cameras"] }),
  });
}
