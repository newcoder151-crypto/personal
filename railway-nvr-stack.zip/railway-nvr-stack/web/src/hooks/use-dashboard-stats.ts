import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { EventRow } from "./use-events";

interface DashboardStats {
  activeCameras: number;
  totalCameras: number;
  totalEvents: number;
  unacknowledgedAlerts: number;
  recentAlerts: EventRow[];
  cameras: Array<{ camera_id: number; camera_name: string; status: string; location_description: string | null; camera_type: string }>;
  storage?: { used_bytes: number; total_recordings: number };
}

export function useDashboardStats() {
  return useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: () => api<DashboardStats>("/api/stats/dashboard"),
    refetchInterval: 30_000,
  });
}
