import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, MnvrUser, Role } from "@/lib/api";

export interface UserWithRole extends MnvrUser {
  // alias kept for legacy callers — returns roles as string[] of length 1
  roles: Role[];
  display_name: string | null;
  avatar_url: string | null;
}

export function useUsers() {
  return useQuery({
    queryKey: ["users"],
    queryFn: async () => {
      const list = await api<MnvrUser[]>("/api/users");
      return list.map((u) => ({
        ...u,
        display_name: u.full_name,
        avatar_url: null,
        roles: [u.role],
      })) as UserWithRole[];
    },
  });
}

export function useUserRoles(userId: number | undefined) {
  return useQuery({
    queryKey: ["user_roles", userId],
    enabled: !!userId,
    queryFn: async () => {
      const u = await api<MnvrUser>(`/api/users/${userId}`);
      return [u.role];
    },
  });
}

export function useCreateUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { username: string; password: string; full_name: string; email?: string; phone?: string; role?: Role }) =>
      api("/api/users", { method: "POST", body }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["users"] }),
  });
}

export function useUpdateUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ user_id, ...rest }: { user_id: number } & Partial<{
      full_name: string; email: string; phone: string; role: Role; is_active: boolean; is_locked: boolean;
    }>) => api(`/api/users/${user_id}`, { method: "PUT", body: rest }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["users"] }),
  });
}

export function useDeleteUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (user_id: number) => api(`/api/users/${user_id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["users"] }),
  });
}

export function useResetUserPassword() {
  return useMutation({
    mutationFn: ({ user_id, new_password }: { user_id: number; new_password: string }) =>
      api(`/api/users/${user_id}/reset-password`, { method: "POST", body: { new_password } }),
  });
}
