import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export interface Recording {
  recording_id: number;
  camera_id: number;
  file_path: string;
  file_name: string;
  file_size_bytes: number | null;
  duration_seconds: number | null;
  start_timestamp: string;
  end_timestamp: string | null;
  video_codec: string | null;
  resolution_width: number | null;
  resolution_height: number | null;
  has_audio: number;
  status: string;
  hls_conversion_status: string;
  hls_ts_file_path: string | null;
  cameras?: { camera_name: string; location_description: string | null; camera_type?: string };
}

export function useRecordings(filters?: { camera_id?: number; start_date?: string; end_date?: string; status?: string; limit?: number }) {
  return useQuery({
    queryKey: ["recordings", filters],
    queryFn: async () => {
      const r = await api<{ recordings: Recording[]; total: number }>("/api/recordings", { query: filters });
      return r.recordings;
    },
  });
}

export function useRecording(id: number | string | undefined) {
  return useQuery({
    queryKey: ["recordings", id],
    enabled: !!id,
    queryFn: () => api<Recording>(`/api/recordings/${id}`),
  });
}
