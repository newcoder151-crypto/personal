import { useEffect, useRef, useState } from "react";
import { Play, Pause, Volume2, VolumeX, Maximize2, SkipBack, SkipForward, Bot, ZoomIn, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useRecordings } from "@/hooks/use-recordings";
import { detectObjects, getRecordingStreamUrl, API_SERVER_URL } from "@/lib/api-server";
import { toast } from "@/hooks/use-toast";

type Detection = { label: string; confidence: number; bbox: [number, number, number, number] };

const VideoPlayer = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const { data: recordings, isLoading } = useRecordings();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [streamUrl, setStreamUrl] = useState<string | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState([75]);
  const [progress, setProgress] = useState([0]);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);

  const [aiOn, setAiOn] = useState(true);
  const [detections, setDetections] = useState<Detection[]>([]);
  const [aiBusy, setAiBusy] = useState(false);
  const [serverDown, setServerDown] = useState(false);

  // Pick first recording when loaded
  useEffect(() => {
    if (!selectedId && recordings && recordings.length > 0) {
      setSelectedId(String(recordings[0].recording_id));
    }
  }, [recordings, selectedId]);

  // Build signed stream URL
  useEffect(() => {
    if (!selectedId) return;
    let cancelled = false;
    getRecordingStreamUrl(selectedId).then((u) => !cancelled && setStreamUrl(u));
    return () => { cancelled = true; };
  }, [selectedId]);

  // Volume sync
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = volume[0] / 100;
      videoRef.current.muted = muted;
    }
  }, [volume, muted]);

  // YOLO loop — every 1.2s grab current frame, POST to /api/ai/detect
  useEffect(() => {
    if (!aiOn || !isPlaying) return;
    const id = setInterval(async () => {
      const v = videoRef.current;
      if (!v || v.paused || v.readyState < 2) return;
      try {
        setAiBusy(true);
        const off = document.createElement("canvas");
        off.width = v.videoWidth;
        off.height = v.videoHeight;
        off.getContext("2d")!.drawImage(v, 0, 0);
        const blob: Blob = await new Promise((r) => off.toBlob((b) => r(b!), "image/jpeg", 0.75)!);
        const result = await detectObjects(blob, { conf: 0.4 });
        setDetections(result.detections);
        setServerDown(false);
      } catch {
        setServerDown(true);
      } finally {
        setAiBusy(false);
      }
    }, 1200);
    return () => clearInterval(id);
  }, [aiOn, isPlaying]);

  // Draw boxes onto overlay canvas
  useEffect(() => {
    const v = videoRef.current;
    const c = canvasRef.current;
    if (!v || !c || !v.videoWidth) return;
    c.width = v.clientWidth;
    c.height = v.clientHeight;
    const ctx = c.getContext("2d")!;
    ctx.clearRect(0, 0, c.width, c.height);
    const sx = c.width / v.videoWidth;
    const sy = c.height / v.videoHeight;
    ctx.font = "12px ui-sans-serif, system-ui";
    ctx.lineWidth = 2;
    detections.forEach((d) => {
      const [x1, y1, x2, y2] = d.bbox;
      ctx.strokeStyle = "hsl(var(--primary))";
      ctx.fillStyle = "hsl(var(--primary) / 0.85)";
      ctx.strokeRect(x1 * sx, y1 * sy, (x2 - x1) * sx, (y2 - y1) * sy);
      const label = `${d.label} ${(d.confidence * 100).toFixed(0)}%`;
      const w = ctx.measureText(label).width + 8;
      ctx.fillRect(x1 * sx, y1 * sy - 16, w, 16);
      ctx.fillStyle = "white";
      ctx.fillText(label, x1 * sx + 4, y1 * sy - 4);
    });
  }, [detections]);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play(); else v.pause();
  };

  const onSeek = (val: number[]) => {
    const v = videoRef.current;
    if (!v || !duration) return;
    v.currentTime = (val[0] / 100) * duration;
    setProgress(val);
  };

  const fmt = (s: number) => {
    const m = Math.floor(s / 60);
    const r = Math.floor(s % 60);
    return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
  };

  const selected = recordings?.find((r) => String(r.recording_id) === selectedId);

  return (
    <AppLayout>
      <div className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Video Player</h1>
            <p className="text-sm text-muted-foreground">
              Streaming via Node server · {API_SERVER_URL}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={selectedId ?? ""} onValueChange={setSelectedId} disabled={isLoading || !recordings?.length}>
              <SelectTrigger className="w-72 h-8 text-xs">
                <SelectValue placeholder={isLoading ? "Loading…" : "Select a recording"} />
              </SelectTrigger>
              <SelectContent>
                {recordings?.map((r: any) => (
                  <SelectItem key={r.recording_id} value={String(r.recording_id)}>
                    {r.cameras?.camera_name ?? `cam ${r.camera_id}`} — {new Date(r.start_timestamp).toLocaleString()}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button size="sm" variant={aiOn ? "default" : "outline"} className="h-8 text-xs gap-1" onClick={() => setAiOn(!aiOn)}>
              <Bot className="h-3 w-3" /> AI {aiOn ? "On" : "Off"}
            </Button>
          </div>
        </div>

        {/* Video Area */}
        <div className="relative rounded-lg overflow-hidden bg-muted border border-border" style={{ aspectRatio: "16/9" }}>
          {streamUrl ? (
            <video
              ref={videoRef}
              src={streamUrl}
              className="w-full h-full object-contain bg-black"
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onLoadedMetadata={(e) => setDuration((e.target as HTMLVideoElement).duration)}
              onTimeUpdate={(e) => {
                const v = e.target as HTMLVideoElement;
                setCurrentTime(v.currentTime);
                if (v.duration) setProgress([(v.currentTime / v.duration) * 100]);
              }}
              onError={() => toast({ title: "Stream error", description: "Is the Node server running on " + API_SERVER_URL + "?", variant: "destructive" })}
              crossOrigin="anonymous"
              playsInline
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center text-muted-foreground text-sm">
              {isLoading ? <Loader2 className="h-6 w-6 animate-spin" /> : "No recordings available"}
            </div>
          )}

          {/* AI overlay canvas */}
          {aiOn && <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />}

          {/* Top overlay */}
          <div className="absolute top-3 left-3 flex gap-2">
            <Badge className="text-[10px] bg-primary/90 text-primary-foreground gap-1">
              <Bot className="h-3 w-3" /> {aiBusy ? "AI Processing" : aiOn ? "AI Active" : "AI Off"}
            </Badge>
            {selected && (
              <Badge variant="outline" className="text-[10px] bg-card/50 backdrop-blur border-border text-foreground">
                {(selected as any).cameras?.camera_name ?? `cam ${selected.camera_id}`}
              </Badge>
            )}
            {serverDown && (
              <Badge variant="destructive" className="text-[10px]">YOLO sidecar offline</Badge>
            )}
          </div>

          <div className="absolute top-3 right-3">
            <Button size="sm" variant="outline" className="h-7 text-[10px] bg-card/50 backdrop-blur border-border text-foreground gap-1">
              <ZoomIn className="h-3 w-3" /> AI Motion Zoom
            </Button>
          </div>
        </div>

        {/* Controls */}
        <Card className="bg-card border-border">
          <CardContent className="p-4 space-y-3">
            <Slider value={progress} onValueChange={onSeek} max={100} step={0.1} />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => videoRef.current && (videoRef.current.currentTime -= 10)}>
                  <SkipBack className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={togglePlay}>
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => videoRef.current && (videoRef.current.currentTime += 10)}>
                  <SkipForward className="h-4 w-4" />
                </Button>
                <span className="text-xs text-muted-foreground font-mono">{fmt(currentTime)} / {fmt(duration)}</span>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setMuted(!muted)}>
                    {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                  </Button>
                  <Slider value={volume} onValueChange={setVolume} max={100} className="w-20" />
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => videoRef.current?.requestFullscreen()}>
                  <Maximize2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Live detections list */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Bot className="h-4 w-4 text-primary" /> Live YOLO Detections
              <Badge variant="outline" className="ml-auto text-[10px]">{detections.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {detections.length === 0 ? (
              <p className="text-xs text-muted-foreground">
                {aiOn ? "No objects detected in current frame." : "AI is off."}
              </p>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {detections.map((d, i) => (
                  <div key={i} className="flex items-center justify-between p-2 rounded-md bg-muted/30 border border-border">
                    <span className="text-xs font-medium text-foreground capitalize">{d.label}</span>
                    <span className="text-xs text-muted-foreground font-mono">{(d.confidence * 100).toFixed(0)}%</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default VideoPlayer;
