import { Activity, Camera, Bot, CheckCircle, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AppLayout } from "@/components/layout/AppLayout";

const cameras = Array.from({ length: 16 }, (_, i) => {
  const issues = [
    null, null, null, null, null, null, null,
    { type: "Blur", score: 62, suggestion: "Clean lens — possible condensation" },
    null, null, null,
    { type: "Feed Lost", score: 0, suggestion: "Check network cable — no response from IP" },
    null, null,
    { type: "Low Light", score: 45, suggestion: "Night mode not activating — firmware update needed" },
    null,
  ];
  return {
    id: i + 1,
    name: `CAM-${String(i + 1).padStart(2, "0")}`,
    health: issues[i] ? (issues[i]!.score === 0 ? 0 : issues[i]!.score) : 95 + Math.floor(Math.random() * 5),
    issue: issues[i],
    status: issues[i] ? (issues[i]!.score === 0 ? "red" : "yellow") : "green" as string,
    fps: issues[i]?.score === 0 ? 0 : 25,
    bitrate: issues[i]?.score === 0 ? "0 Mbps" : `${(2 + Math.random() * 2).toFixed(1)} Mbps`,
  };
});

const AiHealth = () => {
  const healthy = cameras.filter((c) => c.status === "green").length;
  const warning = cameras.filter((c) => c.status === "yellow").length;
  const critical = cameras.filter((c) => c.status === "red").length;

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">AI Camera Health</h1>
            <p className="text-sm text-muted-foreground">Auto health check — blur, darkness, obstruction detection</p>
          </div>
          <Button size="sm" className="gap-1"><Bot className="h-3 w-3" /> Run Full Scan</Button>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-3 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <CheckCircle className="h-8 w-8 text-success" />
              <div><p className="text-2xl font-bold text-foreground">{healthy}</p><p className="text-xs text-muted-foreground">Healthy</p></div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <AlertTriangle className="h-8 w-8 text-warning" />
              <div><p className="text-2xl font-bold text-foreground">{warning}</p><p className="text-xs text-muted-foreground">Warning</p></div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <AlertTriangle className="h-8 w-8 text-destructive" />
              <div><p className="text-2xl font-bold text-foreground">{critical}</p><p className="text-xs text-muted-foreground">Critical</p></div>
            </CardContent>
          </Card>
        </div>

        {/* Camera Health Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3">
          {cameras.map((cam) => (
            <Card key={cam.id} className={`bg-card border ${cam.status === "red" ? "border-destructive/40" : cam.status === "yellow" ? "border-warning/40" : "border-border"}`}>
              <CardContent className="p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Camera className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium text-foreground">{cam.name}</span>
                  </div>
                  <div className={`status-dot status-dot-${cam.status}`} />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] text-muted-foreground">
                    <span>Health Score</span>
                    <span>{cam.health}%</span>
                  </div>
                  <Progress value={cam.health} className="h-1.5" />
                </div>
                <div className="flex justify-between text-[10px] text-muted-foreground">
                  <span>{cam.fps} FPS</span>
                  <span>{cam.bitrate}</span>
                </div>
                {cam.issue && (
                  <div className="p-2 rounded bg-ai-surface/50 border border-ai-glow/20">
                    <p className="text-[10px] font-medium text-foreground flex items-center gap-1">
                      <Bot className="h-3 w-3 text-ai-glow" /> {cam.issue.type}
                    </p>
                    <p className="text-[9px] text-muted-foreground mt-0.5">{cam.issue.suggestion}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default AiHealth;
