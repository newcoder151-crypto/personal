import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertTriangle, CheckCircle, Clock, Flame, Users, ShieldAlert, Package,
  Volume2, Bot, Eye,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AppLayout } from "@/components/layout/AppLayout";
import { useEvents, useAcknowledgeEvent, useAcknowledgeAll } from "@/hooks/use-events";
import { useAuth } from "@/contexts/AuthContext";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";

const iconMap: Record<string, React.ElementType> = {
  smoke: Flame,
  fire: Flame,
  person: ShieldAlert,
  crowd: Users,
  overcrowd: Users,
  bag: Package,
  audio: Volume2,
  default: AlertTriangle,
};

function getIcon(eventType: string): React.ElementType {
  const lower = eventType.toLowerCase();
  for (const [key, icon] of Object.entries(iconMap)) {
    if (lower.includes(key)) return icon;
  }
  return iconMap.default;
}

const severityStyles: Record<string, string> = {
  CRITICAL: "border-destructive/40 bg-destructive/5",
  EMERGENCY: "border-destructive/40 bg-destructive/5",
  ERROR: "border-warning/40 bg-warning/5",
  WARNING: "border-warning/40 bg-warning/5",
  INFO: "border-border bg-muted/30",
};

const severityBadge: Record<string, string> = {
  CRITICAL: "bg-destructive text-destructive-foreground",
  EMERGENCY: "bg-destructive text-destructive-foreground",
  ERROR: "bg-warning text-warning-foreground",
  WARNING: "bg-warning text-warning-foreground",
  INFO: "bg-muted text-muted-foreground",
};

const EventsPage = () => {
  const { data: events, isLoading } = useEvents();
  const acknowledgeEvent = useAcknowledgeEvent();
  const acknowledgeAll = useAcknowledgeAll();
  const { user } = useAuth();

  const unacknowledgedCount = (events || []).filter((e) => e.is_acknowledged === 0).length;

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Events & Alarms</h1>
            <p className="text-sm text-muted-foreground">
              {unacknowledgedCount} unacknowledged alerts — AI auto-generated
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            disabled={acknowledgeAll.isPending || unacknowledgedCount === 0}
            onClick={() => user && acknowledgeAll.mutate(user.id)}
          >
            <CheckCircle className="mr-1 h-3 w-3" /> Acknowledge All
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {(["CRITICAL", "ERROR", "WARNING", "INFO"] as const).map((sev) => {
            const count = (events || []).filter((e) => e.severity === sev && e.is_acknowledged === 0).length;
            return (
              <Card key={sev} className="bg-card border-border">
                <CardContent className="p-3 text-center">
                  {isLoading ? <Skeleton className="h-8 w-10 mx-auto" /> : <p className="text-2xl font-bold text-foreground">{count}</p>}
                  <Badge className={`text-[10px] mt-1 ${severityBadge[sev]}`}>{sev}</Badge>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="space-y-3">
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)
          ) : !events || events.length === 0 ? (
            <p className="text-center text-muted-foreground py-10">No events found</p>
          ) : (
            <AnimatePresence>
              {events.map((event) => {
                const EventIcon = getIcon(event.event_type);
                const sev = event.severity;
                const cameraName = (event as any).cameras?.camera_name;
                return (
                  <motion.div
                    key={event.event_id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    className={`rounded-lg border p-4 transition-all ${severityStyles[sev] || severityStyles.INFO} ${event.is_acknowledged === 1 ? "opacity-50" : ""}`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-md ${sev === "CRITICAL" || sev === "EMERGENCY" ? "bg-destructive/20" : sev === "ERROR" || sev === "WARNING" ? "bg-warning/20" : "bg-info/20"}`}>
                          <EventIcon className={`h-5 w-5 ${sev === "CRITICAL" || sev === "EMERGENCY" ? "text-destructive" : sev === "ERROR" || sev === "WARNING" ? "text-warning" : "text-info"}`} />
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm font-semibold text-foreground">{event.title}</p>
                          {event.description && <p className="text-xs text-muted-foreground">{event.description}</p>}
                          <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                            {cameraName && <span className="flex items-center gap-1"><Eye className="h-3 w-3" />{cameraName}</span>}
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {formatDistanceToNow(new Date(event.occurred_at), { addSuffix: true })}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Badge className={severityBadge[sev] || severityBadge.INFO}>{event.severity}</Badge>
                        {event.is_acknowledged === 0 && user && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs h-7"
                            disabled={acknowledgeEvent.isPending}
                            onClick={() => acknowledgeEvent.mutate({ event_id: event.event_id, userId: user.id })}
                          >
                            Acknowledge
                          </Button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          )}
        </div>
      </div>
    </AppLayout>
  );
};

export default EventsPage;
