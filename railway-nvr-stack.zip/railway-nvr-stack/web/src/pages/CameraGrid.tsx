import { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { AppLayout } from "@/components/layout/AppLayout";
import CameraTile, { type CameraData } from "@/components/camera/CameraTile";
import CameraZoomDialog from "@/components/camera/CameraZoomDialog";
import { useCameras, useCreateCamera } from "@/hooks/use-cameras";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

function dbToUi(cam: any, index: number): CameraData {
  return {
    id: cam.camera_id,
    name: cam.camera_name,
    location: cam.location_description || cam.physical_position || "",
    status: cam.status === "ACTIVE" ? "online" : cam.status === "MAINTENANCE" ? "warning" : "offline",
    aiStatus: cam.status === "ACTIVE" ? "green" : cam.status === "MAINTENANCE" ? "yellow" : "red",
    aiLabel: cam.status === "ACTIVE" ? "Normal" : cam.status === "MAINTENANCE" ? "Maintenance" : "Offline",
    hasAudio: cam.audio_supported === 1,
    detections: [],
  };
}

const CameraGrid = () => {
  const [gridSize, setGridSize] = useState<string>("4x4");
  const [showOverlay, setShowOverlay] = useState(false);
  const [selectedCamera, setSelectedCamera] = useState<CameraData | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [newCam, setNewCam] = useState({ camera_name: "", location_description: "", rtsp_url: "", audio_supported: true });
  const { data: cameras, isLoading } = useCameras();
  const createCamera = useCreateCamera();
  const { toast } = useToast();

  const gridCols =
    gridSize === "4x4" ? "grid-cols-2 md:grid-cols-4" :
    gridSize === "3x3" ? "grid-cols-2 md:grid-cols-3" :
    gridSize === "2x2" ? "grid-cols-1 md:grid-cols-2" :
    "grid-cols-1";

  const cameraList: CameraData[] = (cameras || []).map(dbToUi);

  const handleAddCamera = async () => {
    if (!newCam.camera_name || !newCam.location_description) {
      toast({ title: "Error", description: "Name and location are required", variant: "destructive" });
      return;
    }
    try {
      await createCamera.mutateAsync({
        camera_name: newCam.camera_name,
        location_description: newCam.location_description,
        rtsp_url: newCam.rtsp_url || null,
        audio_supported: newCam.audio_supported ? 1 : 0,
        camera_type: "INTERIOR",
      });
      toast({ title: "Camera Added", description: `${newCam.camera_name} has been added.` });
      setNewCam({ camera_name: "", location_description: "", rtsp_url: "", audio_supported: true });
      setAddOpen(false);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <AppLayout>
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Camera Grid</h1>
            <p className="text-sm text-muted-foreground">{cameraList.length} IP Cameras — Live Feed</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Label className="text-xs text-muted-foreground">AI Overlay</Label>
              <Switch checked={showOverlay} onCheckedChange={setShowOverlay} />
            </div>
            <Select value={gridSize} onValueChange={setGridSize}>
              <SelectTrigger className="w-24 h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="4x4">4×4</SelectItem>
                <SelectItem value="3x3">3×3</SelectItem>
                <SelectItem value="2x2">2×2</SelectItem>
                <SelectItem value="1x1">1×1</SelectItem>
              </SelectContent>
            </Select>
            <Dialog open={addOpen} onOpenChange={setAddOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="gap-1">
                  <Plus className="h-3 w-3" /> Add Camera
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Camera</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div><Label>Camera Name</Label><Input placeholder="CAM-17" value={newCam.camera_name} onChange={(e) => setNewCam(p => ({ ...p, camera_name: e.target.value }))} /></div>
                  <div><Label>IP Address / RTSP URL</Label><Input placeholder="rtsp://192.168.1.100:554/stream" value={newCam.rtsp_url} onChange={(e) => setNewCam(p => ({ ...p, rtsp_url: e.target.value }))} /></div>
                  <div><Label>Location</Label><Input placeholder="Coach S4" value={newCam.location_description} onChange={(e) => setNewCam(p => ({ ...p, location_description: e.target.value }))} /></div>
                  <div className="flex items-center gap-2">
                    <Switch id="audio" checked={newCam.audio_supported} onCheckedChange={(v) => setNewCam(p => ({ ...p, audio_supported: v }))} />
                    <Label htmlFor="audio">Enable Audio</Label>
                  </div>
                  <Button className="w-full" onClick={handleAddCamera} disabled={createCamera.isPending}>
                    {createCamera.isPending ? "Adding..." : "Add Camera"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {isLoading ? (
          <div className={`grid ${gridCols} gap-2`}>
            {Array.from({ length: 16 }).map((_, i) => <Skeleton key={i} className="aspect-video w-full" />)}
          </div>
        ) : cameraList.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <p className="text-lg">No cameras configured yet</p>
            <p className="text-sm">Click "Add Camera" to get started</p>
          </div>
        ) : (
          <div className={`grid ${gridCols} gap-2`}>
            {cameraList.map((cam, i) => (
              <CameraTile
                key={cam.id}
                cam={cam}
                index={i}
                showOverlay={showOverlay}
                onClick={() => setSelectedCamera(cam)}
              />
            ))}
          </div>
        )}

        <CameraZoomDialog camera={selectedCamera} onClose={() => setSelectedCamera(null)} />
      </div>
    </AppLayout>
  );
};

export default CameraGrid;
