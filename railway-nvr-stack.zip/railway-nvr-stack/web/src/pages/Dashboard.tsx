import { motion } from "framer-motion";
import {
  Camera, Users, AlertTriangle, TrendingUp, Activity,
  Eye, Shield, Cpu, FileText, ArrowUpRight, ArrowDownRight,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AppLayout } from "@/components/layout/AppLayout";
import { useDashboardStats } from "@/hooks/use-dashboard-stats";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";

const severityColor: Record<string, string> = {
  CRITICAL: "bg-destructive/10 text-destructive border-destructive/20",
  EMERGENCY: "bg-destructive/10 text-destructive border-destructive/20",
  ERROR: "bg-destructive/10 text-destructive border-destructive/20",
  WARNING: "bg-warning/10 text-warning border-warning/20",
  INFO: "bg-info/10 text-info border-info/20",
};

const aiInsights = [
  "More loitering detected after 10 PM in sleeper coaches",
  "Camera 7 shows 30% quality degradation — schedule maintenance",
  "Average crowd density reduced by 18% compared to last week",
  "3 incidents auto-resolved in last 24 hours",
];

const Dashboard = () => {
  const { data: stats, isLoading } = useDashboardStats();

  const statCards = [
    { label: "Active Cameras", value: stats ? `${stats.activeCameras}/${stats.totalCameras}` : "—", icon: Camera, trend: "+2", up: true, color: "text-success" },
    { label: "Events Today", value: stats?.totalEvents?.toString() || "0", icon: Eye, trend: "+8%", up: true, color: "text-info" },
    { label: "Active Alerts", value: stats?.unacknowledgedAlerts?.toString() || "0", icon: AlertTriangle, trend: "-40%", up: false, color: "text-warning" },
    { label: "Total Cameras", value: stats?.totalCameras?.toString() || "0", icon: Cpu, trend: "", up: true, color: "text-ai-glow" },
  ];

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
            <p className="text-sm text-muted-foreground">Train #12952 — Mumbai Rajdhani Express</p>
          </div>
          <Button variant="outline" size="sm" className="gap-2">
            <FileText className="h-4 w-4" /> Daily AI Report
          </Button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {statCards.map((stat, i) => (
            <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <stat.icon className={`h-5 w-5 ${stat.color}`} />
                    {stat.trend && (
                      <span className={`text-xs flex items-center gap-0.5 ${stat.up ? "text-success" : "text-destructive"}`}>
                        {stat.up ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                        {stat.trend}
                      </span>
                    )}
                  </div>
                  {isLoading ? <Skeleton className="h-8 w-20" /> : <p className="text-2xl font-bold text-foreground">{stat.value}</p>}
                  <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-warning" /> Recent AI Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {isLoading ? (
                  Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)
                ) : stats?.recentAlerts && stats.recentAlerts.length > 0 ? (
                  stats.recentAlerts.map((alert) => (
                    <motion.div
                      key={alert.event_id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center justify-between p-3 rounded-lg border border-border bg-muted/30"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`status-dot ${alert.severity === "CRITICAL" || alert.severity === "EMERGENCY" ? "status-dot-red" : "status-dot-yellow"}`} />
                        <div>
                          <p className="text-sm font-medium text-foreground">{alert.title}</p>
                          <p className="text-xs text-muted-foreground">{alert.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(alert.occurred_at), { addSuffix: true })}
                        </span>
                        <Badge variant="outline" className={severityColor[alert.severity] || severityColor.INFO}>
                          {alert.severity}
                        </Badge>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">No recent alerts</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Cpu className="h-4 w-4 text-ai-glow" /> AI Insights
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {aiInsights.map((insight, i) => (
                  <div key={i} className="flex gap-2 p-2 rounded-md bg-ai-surface/50">
                    <Activity className="h-3 w-3 mt-0.5 text-ai-glow shrink-0" />
                    <p className="text-xs text-muted-foreground leading-relaxed">{insight}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" /> AI Camera Health Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 sm:grid-cols-8 lg:grid-cols-16 gap-2">
              {isLoading ? (
                Array.from({ length: 16 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)
              ) : stats?.cameras && stats.cameras.length > 0 ? (
                stats.cameras.map((cam) => {
                  const s = cam.status === "ACTIVE" ? "green" : cam.status === "MAINTENANCE" ? "yellow" : "red";
                  return (
                    <div key={cam.camera_id} className="flex flex-col items-center gap-1 p-2 rounded-md border border-border bg-muted/30">
                      <Camera className="h-4 w-4 text-muted-foreground" />
                      <span className="text-[10px] text-muted-foreground truncate w-full text-center">{cam.camera_name}</span>
                      <div className={`status-dot status-dot-${s}`} />
                    </div>
                  );
                })
              ) : (
                <p className="text-sm text-muted-foreground col-span-full text-center py-4">No cameras configured</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default Dashboard;
