import { useState } from "react";
import { Search as SearchIcon, Calendar, Filter, Bot, Image, Clock, MapPin } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AppLayout } from "@/components/layout/AppLayout";

const suggestedFilters = [
  "High crowd density",
  "Animal detected",
  "Smoke in coach",
  "Person near track",
  "Unattended bag",
];

const mockResults = [
  {
    id: 1,
    description: "Person loitering near track edge at 14:32",
    camera: "CAM-16",
    time: "14:32:15",
    date: "2024-01-15",
    confidence: 92,
    thumbnail: null,
    detections: ["Person", "Track Edge"],
  },
  {
    id: 2,
    description: "Red shirt individual near door — Coach S2",
    camera: "CAM-04",
    time: "11:45:22",
    date: "2024-01-15",
    confidence: 88,
    thumbnail: null,
    detections: ["Person", "Door"],
  },
  {
    id: 3,
    description: "Running person detected on platform",
    camera: "CAM-15",
    time: "09:12:08",
    date: "2024-01-15",
    confidence: 85,
    thumbnail: null,
    detections: ["Person", "Running"],
  },
  {
    id: 4,
    description: "Crowd gathering near vestibule area",
    camera: "CAM-09",
    time: "16:55:30",
    date: "2024-01-14",
    confidence: 91,
    thumbnail: null,
    detections: ["Crowd", "Vestibule"],
  },
];

const SearchPage = () => {
  const [query, setQuery] = useState("");
  const [searchResults, setSearchResults] = useState(mockResults);

  const handleSearch = () => {
    // In real app, this calls semantic search API
    setSearchResults(mockResults);
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">AI Video Search</h1>
          <p className="text-sm text-muted-foreground">Semantic search across archived footage</p>
        </div>

        {/* Search Bar */}
        <Card className="bg-card border-border">
          <CardContent className="p-4 space-y-4">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  className="pl-10"
                  placeholder='Try "person in red shirt near door" or "someone running on platform"'
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                />
              </div>
              <Button onClick={handleSearch} className="gap-1">
                <Bot className="h-4 w-4" /> AI Search
              </Button>
            </div>

            {/* Filters */}
            <div className="flex flex-wrap items-center gap-3">
              <Select>
                <SelectTrigger className="w-32 h-8 text-xs">
                  <SelectValue placeholder="Camera" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 16 }, (_, i) => (
                    <SelectItem key={i} value={`cam-${i + 1}`}>CAM-{String(i + 1).padStart(2, "0")}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select>
                <SelectTrigger className="w-32 h-8 text-xs">
                  <SelectValue placeholder="Date Range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="week">Last 7 Days</SelectItem>
                  <SelectItem value="month">Last 30 Days</SelectItem>
                </SelectContent>
              </Select>
              <Select>
                <SelectTrigger className="w-32 h-8 text-xs">
                  <SelectValue placeholder="Train ID" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="12952">12952 Rajdhani</SelectItem>
                  <SelectItem value="12301">12301 Howrah</SelectItem>
                  <SelectItem value="12802">12802 Purushottam</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* AI Suggested Filters */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                <Bot className="h-3 w-3 text-ai-glow" /> Suggested:
              </span>
              {suggestedFilters.map((f) => (
                <Badge
                  key={f}
                  variant="outline"
                  className="text-[10px] cursor-pointer hover:bg-accent transition-colors border-ai-glow/30 text-ai-glow"
                  onClick={() => setQuery(f)}
                >
                  {f}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="grid md:grid-cols-2 gap-4">
          {searchResults.map((result) => (
            <Card key={result.id} className="bg-card border-border hover:border-primary/30 transition-colors cursor-pointer">
              <CardContent className="p-4">
                <div className="flex gap-3">
                  {/* Thumbnail placeholder */}
                  <div className="w-32 h-20 rounded-md bg-muted border border-border flex items-center justify-center shrink-0">
                    <Image className="h-6 w-6 text-muted-foreground/30" />
                  </div>
                  <div className="flex-1 min-w-0 space-y-2">
                    <p className="text-sm font-medium text-foreground leading-tight">{result.description}</p>
                    <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                      <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{result.camera}</span>
                      <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{result.time}</span>
                      <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{result.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-[9px] ai-badge">AI {result.confidence}%</Badge>
                      {result.detections.map((d) => (
                        <Badge key={d} variant="secondary" className="text-[9px]">{d}</Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default SearchPage;
