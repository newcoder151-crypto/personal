import { useState } from "react";
import { Settings, Wifi, HardDrive, Bot, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AppLayout } from "@/components/layout/AppLayout";

const SettingsPage = () => {
  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">System Settings</h1>
          <p className="text-sm text-muted-foreground">Configuration, network & storage management</p>
        </div>

        <Tabs defaultValue="general">
          <TabsList className="mb-4">
            <TabsTrigger value="general"><Settings className="h-3 w-3 mr-1" /> General</TabsTrigger>
            <TabsTrigger value="network"><Wifi className="h-3 w-3 mr-1" /> Network</TabsTrigger>
            <TabsTrigger value="storage"><HardDrive className="h-3 w-3 mr-1" /> Storage</TabsTrigger>
            <TabsTrigger value="ai"><Bot className="h-3 w-3 mr-1" /> AI Config</TabsTrigger>
          </TabsList>

          <TabsContent value="general">
            <Card className="bg-card border-border">
              <CardHeader><CardTitle className="text-base">General Configuration</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div><Label>System Name</Label><Input defaultValue="Railway NVR — Mumbai Rajdhani" /></div>
                  <div><Label>Train ID</Label><Input defaultValue="12952" /></div>
                  <div><Label>Recording Quality</Label>
                    <Select defaultValue="1080p"><SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="720p">720p</SelectItem>
                        <SelectItem value="1080p">1080p</SelectItem>
                        <SelectItem value="4k">4K</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div><Label>Frame Rate</Label>
                    <Select defaultValue="25"><SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15 FPS</SelectItem>
                        <SelectItem value="25">25 FPS</SelectItem>
                        <SelectItem value="30">30 FPS</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Switch id="gps" defaultChecked />
                  <Label htmlFor="gps">Enable Train GPS Sync (auto-label detections with location)</Label>
                </div>
                <div className="flex items-center gap-3">
                  <Switch id="privacy" defaultChecked />
                  <Label htmlFor="privacy">Privacy Blur (auto-blur passenger faces in live view)</Label>
                </div>
                <Button className="gap-1"><Save className="h-3 w-3" /> Save Changes</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="network">
            <Card className="bg-card border-border">
              <CardHeader><CardTitle className="text-base">Network Configuration</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div><Label>NVR IP Address</Label><Input defaultValue="192.168.1.100" /></div>
                  <div><Label>Gateway</Label><Input defaultValue="192.168.1.1" /></div>
                  <div><Label>Subnet Mask</Label><Input defaultValue="255.255.255.0" /></div>
                  <div><Label>DNS Server</Label><Input defaultValue="8.8.8.8" /></div>
                </div>
                <div><Label>RTSP Port</Label><Input defaultValue="554" className="w-32" /></div>
                <Button className="gap-1"><Save className="h-3 w-3" /> Save Network Settings</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="storage">
            <Card className="bg-card border-border">
              <CardHeader><CardTitle className="text-base">Storage Management</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-foreground">Disk Usage</span>
                    <span className="text-muted-foreground">1.2 TB / 4 TB</span>
                  </div>
                  <Progress value={30} />
                </div>
                <div className="grid md:grid-cols-3 gap-4">
                  <Card className="bg-muted/30 border-border">
                    <CardContent className="p-4 text-center">
                      <p className="text-2xl font-bold text-foreground">847 GB</p>
                      <p className="text-xs text-muted-foreground">Event Clips (AI flagged)</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-muted/30 border-border">
                    <CardContent className="p-4 text-center">
                      <p className="text-2xl font-bold text-foreground">353 GB</p>
                      <p className="text-xs text-muted-foreground">Non-Event Footage</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-muted/30 border-border">
                    <CardContent className="p-4 text-center">
                      <p className="text-2xl font-bold text-success">2.6 TB</p>
                      <p className="text-xs text-muted-foreground">Free Space</p>
                    </CardContent>
                  </Card>
                </div>
                <div className="flex items-center gap-3">
                  <Switch id="autoOptimise" defaultChecked />
                  <Label htmlFor="autoOptimise">AI Auto-Optimise (delete non-event footage first, keep flagged clips)</Label>
                </div>
                <div className="p-3 rounded-md bg-ai-surface/50 border border-ai-glow/20">
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Bot className="h-3 w-3 text-ai-glow" /> AI saved 480 GB last month by removing non-event footage
                  </p>
                </div>
                <Button variant="destructive" size="sm" className="gap-1"><Trash2 className="h-3 w-3" /> Purge Non-Event Footage</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai">
            <Card className="bg-card border-border">
              <CardHeader><CardTitle className="text-base">AI Configuration</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>Detection Model</Label>
                    <Select defaultValue="yolo"><SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="yolo">YOLOv8 — Object Detection</SelectItem>
                        <SelectItem value="clip">CLIP — Semantic Search</SelectItem>
                        <SelectItem value="whisper">Whisper — Audio Analysis</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Confidence Threshold</Label>
                    <Input type="number" defaultValue="75" min={0} max={100} className="w-32" />
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Switch id="objDet" defaultChecked />
                    <Label htmlFor="objDet">Real-time Object Detection</Label>
                  </div>
                  <div className="flex items-center gap-3">
                    <Switch id="audioDet" defaultChecked />
                    <Label htmlFor="audioDet">Audio Anomaly Detection</Label>
                  </div>
                  <div className="flex items-center gap-3">
                    <Switch id="predictive" defaultChecked />
                    <Label htmlFor="predictive">Predictive Alert Engine</Label>
                  </div>
                  <div className="flex items-center gap-3">
                    <Switch id="voiceCmd" />
                    <Label htmlFor="voiceCmd">Voice Command Support</Label>
                  </div>
                </div>
                <Button className="gap-1"><Save className="h-3 w-3" /> Save AI Settings</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default SettingsPage;
