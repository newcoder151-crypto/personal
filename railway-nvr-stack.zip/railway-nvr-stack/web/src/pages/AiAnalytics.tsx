import { Cpu, Activity, TrendingUp, BarChart3, Bot, MapPin } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AppLayout } from "@/components/layout/AppLayout";

const anomalyData = [
  { hour: "00:00", count: 2 }, { hour: "02:00", count: 1 }, { hour: "04:00", count: 0 },
  { hour: "06:00", count: 3 }, { hour: "08:00", count: 8 }, { hour: "10:00", count: 12 },
  { hour: "12:00", count: 7 }, { hour: "14:00", count: 15 }, { hour: "16:00", count: 9 },
  { hour: "18:00", count: 11 }, { hour: "20:00", count: 6 }, { hour: "22:00", count: 18 },
];

const highRiskZones = [
  { zone: "Platform Edge — New Delhi", risk: "high", detections: 45 },
  { zone: "Vestibule — Coach S3-S4", risk: "high", detections: 38 },
  { zone: "Pantry Car Kitchen", risk: "medium", detections: 22 },
  { zone: "Entrance B — Coach A1", risk: "medium", detections: 15 },
  { zone: "Guard Van", risk: "low", detections: 5 },
];

const AiAnalytics = () => {
  const maxCount = Math.max(...anomalyData.map((d) => d.count));

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">AI Analytics</h1>
          <p className="text-sm text-muted-foreground">AI-powered insights across all 16 cameras</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <Cpu className="h-5 w-5 text-ai-glow mb-2" />
              <p className="text-2xl font-bold text-foreground">2,847</p>
              <p className="text-xs text-muted-foreground">Persons Detected Today</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <Activity className="h-5 w-5 text-warning mb-2" />
              <p className="text-2xl font-bold text-foreground">67%</p>
              <p className="text-xs text-muted-foreground">Avg Crowd Density</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <TrendingUp className="h-5 w-5 text-success mb-2" />
              <p className="text-2xl font-bold text-foreground">-18%</p>
              <p className="text-xs text-muted-foreground">Incidents This Week</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <BarChart3 className="h-5 w-5 text-info mb-2" />
              <p className="text-2xl font-bold text-foreground">1,204</p>
              <p className="text-xs text-muted-foreground">AI Detections Today</p>
            </CardContent>
          </Card>
        </div>

        {/* Anomaly Trend Graph */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Bot className="h-4 w-4 text-ai-glow" /> AI Anomaly Trend — Last 24 Hours
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-1 h-40">
              {anomalyData.map((d, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    className={`w-full rounded-t transition-all ${d.count > 14 ? "bg-destructive" : d.count > 8 ? "bg-warning" : "bg-primary"}`}
                    style={{ height: `${(d.count / maxCount) * 100}%`, minHeight: d.count > 0 ? 4 : 0 }}
                  />
                  <span className="text-[8px] text-muted-foreground">{d.hour}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* High Risk Zones */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <MapPin className="h-4 w-4 text-destructive" /> High Risk Zones — Route Heat Map
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {highRiskZones.map((zone, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-md border border-border bg-muted/30">
                  <div className="flex items-center gap-3">
                    <MapPin className={`h-4 w-4 ${zone.risk === "high" ? "text-destructive" : zone.risk === "medium" ? "text-warning" : "text-muted-foreground"}`} />
                    <span className="text-sm text-foreground">{zone.zone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{zone.detections} detections</span>
                    <Badge variant="outline" className={`text-[10px] ${zone.risk === "high" ? "border-destructive/30 text-destructive" : zone.risk === "medium" ? "border-warning/30 text-warning" : "border-border text-muted-foreground"}`}>
                      {zone.risk}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default AiAnalytics;
