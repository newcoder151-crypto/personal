import { useEffect, useRef } from "react";
import Hls from "hls.js";

/**
 * <HlsPlayer src="/api/hls/1/master.m3u8?token=..." />
 * - Uses native HLS on Safari/iOS
 * - Uses hls.js elsewhere (with adaptive bitrate selection)
 */
export default function HlsPlayer({
  src, autoPlay = true, muted = true, controls = true, className,
}: {
  src: string; autoPlay?: boolean; muted?: boolean; controls?: boolean; className?: string;
}) {
  const ref = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = ref.current;
    if (!video || !src) return;

    if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = src;
      return;
    }
    if (Hls.isSupported()) {
      const hls = new Hls({
        lowLatencyMode: true,
        enableWorker: true,
        backBufferLength: 30,
      });
      hls.loadSource(src);
      hls.attachMedia(video);
      return () => hls.destroy();
    }
    // Fallback: try direct
    video.src = src;
  }, [src]);

  return (
    <video
      ref={ref}
      autoPlay={autoPlay}
      muted={muted}
      controls={controls}
      playsInline
      className={className}
    />
  );
}
