import { useEffect, useState } from "react";
import { Bell, AlertTriangle, AlertCircle, Info } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { api, openEventStream } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type EventRow = {
  event_id: number;
  title: string;
  description: string | null;
  severity: "INFO" | "WARNING" | "ERROR" | "CRITICAL" | "EMERGENCY";
  event_type: string;
  occurred_at: string;
  is_acknowledged: number;
};

const severityIcon = (s: EventRow["severity"]) => {
  if (s === "CRITICAL" || s === "EMERGENCY") return <AlertTriangle className="h-4 w-4 text-destructive" />;
  if (s === "ERROR" || s === "WARNING") return <AlertCircle className="h-4 w-4 text-yellow-500" />;
  return <Info className="h-4 w-4 text-primary" />;
};

export const NotificationsDropdown = () => {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);

  const { data: notifications = [] } = useQuery({
    queryKey: ["notifications"],
    queryFn: async () => {
      const r = await api<{ events: EventRow[] }>("/api/events", { query: { is_acknowledged: 0, limit: 20 } });
      return r.events;
    },
    refetchInterval: 60_000,
  });

  // WebSocket realtime
  useEffect(() => {
    const close = openEventStream((m) => {
      if (m.type?.startsWith("event")) {
        qc.invalidateQueries({ queryKey: ["notifications"] });
        qc.invalidateQueries({ queryKey: ["events"] });
        qc.invalidateQueries({ queryKey: ["dashboard-stats"] });
        if (m.type === "event.created" && m.data) {
          toast.warning(m.data.title, { description: m.data.description ?? m.data.event_type });
        }
      }
    });
    return close;
  }, [qc]);

  const unreadCount = notifications.length;

  const acknowledgeAll = async () => {
    if (!unreadCount) return;
    try {
      await api(`/api/events/acknowledge-all`, { method: "POST" });
      toast.success(`Acknowledged ${unreadCount} alerts`);
      qc.invalidateQueries({ queryKey: ["notifications"] });
      qc.invalidateQueries({ queryKey: ["events"] });
    } catch {
      toast.error("Failed to acknowledge");
    }
  };

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground">
          <Bell className="h-4 w-4" />
          {unreadCount > 0 && (
            <Badge className={cn(
              "absolute -top-1 -right-1 h-4 min-w-4 px-1 flex items-center justify-center",
              "text-[10px] bg-destructive text-destructive-foreground border-0 animate-pulse"
            )}>
              {unreadCount > 99 ? "99+" : unreadCount}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-96 p-0">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div>
            <h4 className="font-semibold text-sm">Live Alerts</h4>
            <p className="text-[10px] text-muted-foreground">
              {unreadCount === 0 ? "All clear" : `${unreadCount} unacknowledged`}
            </p>
          </div>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={acknowledgeAll} className="text-xs h-7">Ack all</Button>
          )}
        </div>
        <ScrollArea className="h-80">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <Bell className="h-8 w-8 mb-2 opacity-30" />
              <p className="text-xs">No new alerts</p>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {notifications.map((n) => (
                <div key={n.event_id} className="px-4 py-3 hover:bg-muted/40 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5">{severityIcon(n.severity)}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{n.title}</p>
                      {n.description && <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{n.description}</p>}
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {formatDistanceToNow(new Date(n.occurred_at), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
