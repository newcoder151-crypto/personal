# mNVR full stack — Node.js API + React Web + nvr_core integration

This repo replaces the original Supabase backend of `railway-vision-ai` with a self-hosted
**Node.js API** that talks directly to **`nvr_core`'s PostgreSQL schema** (`server/sql/mnvr_schema.sql`).
It runs alongside `mnvrd` on a bare Linux VM and serves recordings + adaptive HLS straight from disk.

```
┌──────────────┐  RTSP   ┌──────────────────┐   writes    ┌────────────────────┐
│ IP cameras   │ ──────► │  mnvrd (C/GST)   │ ──────────► │ /storage/recordings│
└──────────────┘         │  recorder + hls  │             │ /storage/hls       │
                         └──────────────────┘             └─────────┬──────────┘
                                  │                                  │ reads
                                  │ writes DB rows                   ▼
                                  ▼                       ┌────────────────────┐
                         ┌──────────────────┐   psql      │  Node API (this)   │
                         │  PostgreSQL      │ ◄────────── │  /api/* + /api/hls │
                         │  mnvr_schema.sql │             └─────────┬──────────┘
                         └──────────────────┘                       │
                                                                    │ HTTP
                                                                    ▼
                                                          ┌────────────────────┐
                                                          │  React frontend    │
                                                          │  (web/dist served  │
                                                          │   by nginx)        │
                                                          └────────────────────┘
```

## Layout

```
.
├── server/          # Node.js API (replaces Supabase)
│   ├── src/
│   │   ├── index.js
│   │   ├── lib/         (db.js, websocket.js, swagger.js)
│   │   ├── middleware/  (auth.js — JWT + bcrypt)
│   │   └── routes/      (auth, cameras, recordings, events, users,
│   │                      config, streaming, hls, stats, ai)
│   ├── sql/mnvr_schema.sql      # nvr_core's schema (verbatim)
│   ├── ai/sidecar.py            # optional FastAPI YOLO sidecar
│   ├── scripts/create-admin.js
│   └── .env.example
├── web/             # React frontend (Supabase removed)
├── deploy/          # systemd units + nginx config
└── scripts/install.sh   # one-shot installer for Debian/Ubuntu
```

## Quick install (fresh Debian/Ubuntu VM)

```bash
sudo cp -r ./ /opt/mnvr-api/
sudo bash /opt/mnvr-api/scripts/install.sh
```

The script:
1. Installs PostgreSQL, Node 20, nginx, Python.
2. Creates `mnvr` Postgres role/db and imports `server/sql/mnvr_schema.sql`.
3. Creates `/storage/recordings`, `/storage/hls`, `/storage/thumbnails` (writable by `mnvr`).
4. Generates `server/.env` with a strong `JWT_SECRET`.
5. Builds the React app (`web/dist/`).
6. Installs systemd units `mnvr-api.service` (+ optional `mnvr-ai.service`).
7. Configures nginx to serve `/` (web) and proxy `/api`, `/ws` → `127.0.0.1:8080`.
8. Creates initial admin user `admin / Admin@123` — **change immediately**.

After that, point `mnvrd` at the same Postgres (`db_path` in `mnvr.conf`) and the same
`storage_base` / `hls_base`. Open `http://<host>/` and log in.

## Manual dev

```bash
# Backend
cd server
cp .env.example .env   # edit PG* and JWT_SECRET
psql -h localhost -U mnvr -d mnvr -f sql/mnvr_schema.sql
npm install
npm run dev            # listens on :8080
node scripts/create-admin.js admin 'Admin@123'

# Frontend
cd ../web
echo "VITE_API_URL=http://localhost:8080" > .env
npm install
npm run dev            # listens on :8080 (vite) — visit /
```

## Adaptive HLS layout

The Node API serves three kinds of layouts under `STORAGE_HLS`:

| On disk                                                  | URL the client requests                  |
|----------------------------------------------------------|------------------------------------------|
| `cam_<id>/master.m3u8` + `low/`, `mid/`, `high/`         | `/api/hls/<id>/master.m3u8` (real ABR)   |
| `cam_<id>/{low,mid,high}/index.m3u8` (no master)         | server **synthesises** `master.m3u8`     |
| `cam_<id>/stream.m3u8` + `seg_*.ts` (single rendition)   | server wraps it in a synthetic master    |

All segment URLs in the master / media playlists are rewritten to absolute, token-
authenticated URLs so `<video>` and `hls.js` work without manual headers.

## API surface

`GET /api/openapi.json` and `/api/docs` (Swagger UI) document everything.

Key endpoints:

| Method | Path | Purpose |
|--------|------|---------|
| POST   | `/api/auth/login`              | username/email + password → access + refresh JWT |
| POST   | `/api/auth/register`           | self-signup (first user becomes ADMIN) |
| POST   | `/api/auth/refresh`            | rotate access token |
| GET    | `/api/auth/me`                 | current user |
| GET    | `/api/cameras`                 | list (filter by status / type / q) |
| CRUD   | `/api/cameras[/:id]`           | admin only for write |
| GET    | `/api/cameras/:id/live`        | returns `{ hls_url }` |
| GET    | `/api/cameras/:id/health`      | latest `camera_health` row |
| GET    | `/api/recordings`              | filter by camera_id, dates, status |
| GET    | `/api/recordings/:id/segments` | per-segment list |
| GET    | `/api/streaming/recordings/:id/stream`    | MP4 with HTTP range |
| GET    | `/api/streaming/recordings/:id/download`  | MP4 attachment |
| GET    | `/api/streaming/recordings/:id/thumbnail` | JPEG |
| GET    | `/api/hls/:cameraId/master.m3u8`          | HLS adaptive master |
| GET    | `/api/hls/:cameraId/:rendition/index.m3u8`| HLS rendition |
| GET    | `/api/hls/:cameraId/:rendition/:segment`  | .ts / .m4s segment |
| GET    | `/api/events`                  | filter, paginate |
| POST   | `/api/events/:id/acknowledge`  | ack one |
| POST   | `/api/events/acknowledge-all`  | ack all |
| POST   | `/api/events/:id/resolve`      | resolve |
| GET/PUT| `/api/config[/:key]`           | system_config read/write |
| GET    | `/api/stats/dashboard`         | for Dashboard page |
| POST   | `/api/ai/detect`               | proxy frame → YOLO sidecar |
| WS     | `/ws?token=<JWT>`              | realtime events broadcast |

## Auth model

Tokens are stored in `localStorage`:
- `mnvr_access_token`  (24h JWT)
- `mnvr_refresh_token` (30d JWT, recorded in `user_sessions`)
- `mnvr_user`          (cached profile)

`<video>` tags receive `?token=…` because browsers don't send `Authorization` headers
on `<video src>`. Both header and query token are verified by `middleware/auth.js`.

Roles are stored on `users.role` (matches nvr_core schema). Server-side enforcement is
in `requireRole('ADMIN', ...)`.

## Verifying the install

```bash
curl http://localhost:8080/api/health
# {"status":"ok","db":"up", ...}

curl -X POST http://localhost:8080/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"Admin@123"}'

# Get HLS master playlist for camera 1 (token from login above)
curl "http://localhost:8080/api/hls/1/master.m3u8?token=<ACCESS>"
```

## Operations

- Logs: `journalctl -u mnvr-api -f`
- Restart: `systemctl restart mnvr-api`
- Rotate JWT secret: edit `server/.env`, restart — invalidates all tokens.
- Delete a stuck session: `psql -c "UPDATE user_sessions SET is_active=0 WHERE user_id=<id>"`

## Notes

- No Supabase, no external SaaS — everything is local.
- The `recordings.file_path` and `cameras.hls_output_dir` columns are written by
  `mnvrd`. The Node API only reads them; safety checks jail every served path
  inside `STORAGE_RECORDINGS` / `STORAGE_HLS` to prevent traversal.
- Default `BCRYPT_ROUNDS=12` — adjust for your CPU.
- `audit_log` rows are written best-effort on every login / password change /
  user mutation. Failures never break the request.
