#!/usr/bin/env node
/**
 * Create or reset an admin user.
 *   node scripts/create-admin.js <username> <password> [full_name] [email]
 */
'use strict';
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const bcrypt = require('bcryptjs');
const { pool, one } = require('../src/lib/db');

(async () => {
  const [, , username, password, fullName, email] = process.argv;
  if (!username || !password) {
    console.error('Usage: node scripts/create-admin.js <username> <password> [full_name] [email]');
    process.exit(1);
  }
  const hash = await bcrypt.hash(password, parseInt(process.env.BCRYPT_ROUNDS || '12', 10));
  const u = await one(
    `INSERT INTO users (username, password_hash, full_name, email, role, is_active, must_change_password)
     VALUES ($1,$2,$3,$4,'ADMIN',1,0)
     ON CONFLICT (username) DO UPDATE
       SET password_hash = EXCLUDED.password_hash,
           full_name     = COALESCE(EXCLUDED.full_name, users.full_name),
           email         = COALESCE(EXCLUDED.email, users.email),
           role          = 'ADMIN', is_active = 1, is_locked = 0,
           must_change_password = 0, failed_login_attempts = 0,
           updated_at = NOW()
     RETURNING user_id, username, role`,
    [username, hash, fullName || username, email || null]);
  console.log('Admin ready:', u);
  await pool.end();
})().catch((e) => { console.error(e); process.exit(2); });
