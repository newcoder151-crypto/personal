'use strict';
require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const http = require('http');

const { pool } = require('./lib/db');
const { setupWebSocket } = require('./lib/websocket');
const { swaggerDocs } = require('./lib/swagger');

const app = express();
const server = http.createServer(app);

app.set('trust proxy', 1);
// helmet's default crossOriginResourcePolicy blocks <video> from another origin -> relax it
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors({
  origin: (process.env.CORS_ORIGIN && process.env.CORS_ORIGIN !== '*')
    ? process.env.CORS_ORIGIN.split(',').map(s => s.trim())
    : true,
  credentials: true,
}));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health
app.get('/api/health', async (_req, res) => {
  let db = 'down';
  try { await pool.query('SELECT 1'); db = 'up'; } catch (_) {}
  res.json({
    status: 'ok',
    service: 'mnvr-api',
    version: '1.0.0',
    uptime_seconds: Math.round(process.uptime()),
    db,
    timestamp: new Date().toISOString(),
  });
});

// Routes
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/cameras',    require('./routes/cameras'));
app.use('/api/recordings', require('./routes/recordings'));
app.use('/api/events',     require('./routes/events'));
app.use('/api/users',      require('./routes/users'));
app.use('/api/config',     require('./routes/config'));
app.use('/api/streaming',  require('./routes/streaming'));
app.use('/api/hls',        require('./routes/hls'));
app.use('/api/stats',      require('./routes/stats'));
app.use('/api/ai',         require('./routes/ai'));

swaggerDocs(app);

// 404
app.use((req, res) => res.status(404).json({ error: 'Endpoint not found', path: req.path }));

// Error handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, _next) => {
  console.error('[ERR]', err.message, err.stack);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
  });
});

setupWebSocket(server);

const PORT = parseInt(process.env.PORT || '8080', 10);
server.listen(PORT, '0.0.0.0', () => {
  console.log(`mNVR API listening on :${PORT}`);
  console.log(`Recordings: ${process.env.STORAGE_RECORDINGS}`);
  console.log(`HLS:        ${process.env.STORAGE_HLS}`);
});

process.on('SIGTERM', () => { server.close(() => process.exit(0)); });
process.on('SIGINT',  () => { server.close(() => process.exit(0)); });

module.exports = { app, server };
