'use strict';
/**
 * AI proxy. Forwards multipart frames to the optional Python YOLO sidecar
 * (server/ai/sidecar.py running at AI_SIDECAR_URL).
 */
const express = require('express');
const multer = require('multer');
const axios = require('axios');
const FormData = require('form-data');
const { authenticate } = require('../middleware/auth');
const { many, one } = require('../lib/db');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

const SIDECAR = process.env.AI_SIDECAR_URL || 'http://127.0.0.1:9000';

router.post('/detect', authenticate, upload.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'image multipart field required' });
  try {
    const fd = new FormData();
    fd.append('image', req.file.buffer, { filename: req.file.originalname || 'frame.jpg', contentType: req.file.mimetype });
    if (req.body.conf)  fd.append('conf', String(req.body.conf));
    if (req.body.model) fd.append('model', String(req.body.model));
    const r = await axios.post(`${SIDECAR}/detect`, fd, {
      headers: fd.getHeaders(), timeout: 8000, maxBodyLength: 20 * 1024 * 1024,
    });
    res.json(r.data);
  } catch (err) {
    res.status(502).json({ error: 'AI sidecar unreachable', detail: err.message, sidecar: SIDECAR });
  }
});

router.get('/analytics', authenticate, async (_req, res) => {
  const faces = await one(`SELECT COUNT(*)::int AS n FROM face_detections WHERE detection_timestamp >= NOW() - INTERVAL '24 hours'`);
  const motion = await one(`SELECT COUNT(*)::int AS n FROM motion_detection_events WHERE detected_at >= NOW() - INTERVAL '24 hours'`);
  const tampering = await one(`SELECT COUNT(*)::int AS n FROM camera_tampering_events WHERE detected_at >= NOW() - INTERVAL '24 hours'`);
  const recent = await many(
    `SELECT event_id, event_type, severity, title, occurred_at, camera_id
     FROM events WHERE occurred_at >= NOW() - INTERVAL '24 hours' ORDER BY occurred_at DESC LIMIT 50`);
  res.json({
    faces_24h: faces?.n ?? 0,
    motion_24h: motion?.n ?? 0,
    tampering_24h: tampering?.n ?? 0,
    recent_events: recent,
  });
});

module.exports = router;
