'use strict';
const express = require('express');
const { one, many } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.get('/', authenticate, async (req, res) => {
  try {
    const { camera_id, start_date, end_date, status, limit = 50, offset = 0 } = req.query;
    const where = []; const params = [];
    if (camera_id)  { params.push(camera_id);  where.push(`r.camera_id = $${params.length}`); }
    if (status)     { params.push(status);     where.push(`r.status = $${params.length}`); }
    if (start_date) { params.push(start_date); where.push(`r.start_timestamp >= $${params.length}`); }
    if (end_date)   { params.push(end_date);   where.push(`r.start_timestamp <= $${params.length}`); }

    const sql = `
      SELECT r.*,
             json_build_object(
               'camera_name', c.camera_name,
               'location_description', c.location_description,
               'camera_type', c.camera_type
             ) AS cameras
      FROM recordings r
      LEFT JOIN cameras c USING (camera_id)
      ${where.length ? 'WHERE '+where.join(' AND ') : ''}
      ORDER BY r.start_timestamp DESC
      LIMIT ${parseInt(limit,10)} OFFSET ${parseInt(offset,10)}`;
    const rows = await many(sql, params);
    const cnt = await one(
      `SELECT COUNT(*)::int AS n FROM recordings r ${where.length ? 'WHERE '+where.join(' AND ') : ''}`,
      params);
    res.json({ recordings: rows, total: cnt.n });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', authenticate, async (req, res) => {
  const r = await one(
    `SELECT r.*, row_to_json(c) AS cameras
     FROM recordings r LEFT JOIN cameras c USING (camera_id)
     WHERE r.recording_id = $1`, [req.params.id]);
  if (!r) return res.status(404).json({ error: 'Recording not found' });
  res.json(r);
});

router.get('/:id/segments', authenticate, async (req, res) => {
  const rows = await many(
    `SELECT * FROM recording_segments WHERE recording_id = $1 ORDER BY segment_number`,
    [req.params.id]);
  res.json(rows);
});

module.exports = router;
