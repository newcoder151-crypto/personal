'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { one, query } = require('../lib/db');
const { authenticate, authLimiter, signAccessToken, signRefreshToken, verify } = require('../middleware/auth');

const router = express.Router();
const ROUNDS = parseInt(process.env.BCRYPT_ROUNDS || '12', 10);

function audit(req, action, status, description) {
  // Best-effort audit log - never throw
  query(
    `INSERT INTO audit_log (action_type, action_status, action_category, description,
       ip_address, user_agent, user_id, username, user_role, request_endpoint, request_method, timestamp)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11, NOW())`,
    [action, status, 'AUTH', description,
     req.ip, req.headers['user-agent'] || null,
     req.user?.id ?? null, req.user?.username ?? null, req.user?.role ?? null,
     req.originalUrl, req.method]
  ).catch(() => {});
}

function publicUser(u) {
  return {
    user_id: u.user_id, username: u.username, full_name: u.full_name,
    email: u.email, phone: u.phone, role: u.role,
    is_active: !!u.is_active, must_change_password: !!u.must_change_password,
    last_login_at: u.last_login_at, created_at: u.created_at,
  };
}

// POST /api/auth/login  { username, password }
router.post('/login', authLimiter, async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password) return res.status(400).json({ error: 'username and password required' });

    const u = await one('SELECT * FROM users WHERE username = $1 OR email = $1', [username]);
    if (!u || !u.is_active) {
      audit(req, 'LOGIN', 'FAILURE', `Unknown or inactive user: ${username}`);
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    if (u.is_locked) {
      audit(req, 'LOGIN', 'FAILURE', `Locked account: ${username}`);
      return res.status(423).json({ error: 'Account locked' });
    }

    const ok = await bcrypt.compare(password, u.password_hash);
    if (!ok) {
      await query(
        `UPDATE users SET failed_login_attempts = COALESCE(failed_login_attempts,0)+1,
                          last_failed_login = NOW(),
                          is_locked = CASE WHEN COALESCE(failed_login_attempts,0)+1 >= 5 THEN 1 ELSE is_locked END
         WHERE user_id = $1`, [u.user_id]);
      audit(req, 'LOGIN', 'FAILURE', `Bad password: ${username}`);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    await query(
      `UPDATE users SET failed_login_attempts = 0, last_login_at = NOW(), last_login_ip = $2 WHERE user_id = $1`,
      [u.user_id, req.ip]
    );

    const access = signAccessToken(u);
    const refresh = signRefreshToken(u);
    const sessionId = uuidv4();
    await query(
      `INSERT INTO user_sessions (session_id, user_id, token, device_info, ip_address, expires_at, is_active)
       VALUES ($1,$2,$3,$4,$5, NOW() + INTERVAL '30 days', 1)`,
      [sessionId, u.user_id, refresh, req.headers['user-agent'] || null, req.ip]
    );

    audit({ ...req, user: u }, 'LOGIN', 'SUCCESS', `Login OK: ${username}`);
    res.json({ access_token: access, refresh_token: refresh, token_type: 'Bearer', expires_in: 86400, user: publicUser(u) });
  } catch (err) {
    console.error('[login]', err);
    res.status(500).json({ error: 'Login failed' });
  }
});

// POST /api/auth/register  { username, password, full_name, email?, phone? }
router.post('/register', authLimiter, async (req, res) => {
  try {
    const { username, password, full_name, email, phone } = req.body || {};
    if (!username || !password || !full_name) {
      return res.status(400).json({ error: 'username, password, full_name required' });
    }
    if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });

    const exists = await one('SELECT user_id FROM users WHERE username = $1 OR email = $2', [username, email || null]);
    if (exists) return res.status(409).json({ error: 'Username or email already in use' });

    const hash = await bcrypt.hash(password, ROUNDS);

    // First user becomes ADMIN, everyone else VIEWER (operator can be granted later)
    const cnt = await one('SELECT COUNT(*)::int AS n FROM users');
    const role = cnt.n === 0 ? 'ADMIN' : 'VIEWER';

    const u = await one(
      `INSERT INTO users (username, password_hash, full_name, email, phone, role)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [username, hash, full_name, email || null, phone || null, role]
    );
    audit({ ...req, user: u }, 'CREATE', 'SUCCESS', `Registered ${username} as ${role}`);
    res.status(201).json({ user: publicUser(u) });
  } catch (err) {
    console.error('[register]', err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// POST /api/auth/refresh  { refresh_token }
router.post('/refresh', authLimiter, async (req, res) => {
  try {
    const { refresh_token } = req.body || {};
    if (!refresh_token) return res.status(400).json({ error: 'refresh_token required' });
    let decoded;
    try { decoded = verify(refresh_token); } catch { return res.status(401).json({ error: 'Invalid refresh token' }); }
    if (decoded.type !== 'refresh') return res.status(401).json({ error: 'Wrong token type' });

    const sess = await one(
      `SELECT * FROM user_sessions WHERE token = $1 AND is_active = 1 AND expires_at > NOW()`,
      [refresh_token]
    );
    if (!sess) return res.status(401).json({ error: 'Session not active' });

    const u = await one('SELECT * FROM users WHERE user_id = $1', [decoded.sub]);
    if (!u || !u.is_active) return res.status(401).json({ error: 'User disabled' });

    const access = signAccessToken(u);
    res.json({ access_token: access, token_type: 'Bearer', expires_in: 86400 });
  } catch (err) {
    res.status(500).json({ error: 'Refresh failed' });
  }
});

// POST /api/auth/logout
router.post('/logout', authenticate, async (req, res) => {
  try {
    const { refresh_token } = req.body || {};
    if (refresh_token) {
      await query(`UPDATE user_sessions SET is_active = 0, logout_timestamp = NOW() WHERE token = $1`, [refresh_token]);
    } else {
      await query(`UPDATE user_sessions SET is_active = 0, logout_timestamp = NOW() WHERE user_id = $1`, [req.user.id]);
    }
    audit(req, 'LOGOUT', 'SUCCESS', 'Logout');
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: 'Logout failed' });
  }
});

// GET /api/auth/me
router.get('/me', authenticate, async (req, res) => {
  const u = await one('SELECT * FROM users WHERE user_id = $1', [req.user.id]);
  if (!u) return res.status(404).json({ error: 'User not found' });
  res.json(publicUser(u));
});

// POST /api/auth/change-password   { old_password, new_password }
router.post('/change-password', authenticate, async (req, res) => {
  try {
    const { old_password, new_password } = req.body || {};
    if (!old_password || !new_password) return res.status(400).json({ error: 'old_password and new_password required' });
    if (new_password.length < 8) return res.status(400).json({ error: 'Password must be 8+ chars' });

    const u = await one('SELECT * FROM users WHERE user_id = $1', [req.user.id]);
    if (!u) return res.status(404).json({ error: 'User not found' });
    const ok = await bcrypt.compare(old_password, u.password_hash);
    if (!ok) return res.status(401).json({ error: 'Old password incorrect' });

    const hash = await bcrypt.hash(new_password, ROUNDS);
    await query(`UPDATE users SET password_hash=$1, must_change_password=0, updated_at=NOW() WHERE user_id=$2`,
      [hash, u.user_id]);
    audit(req, 'PASSWORD_CHANGE', 'SUCCESS', `Password changed by ${u.username}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: 'Change password failed' });
  }
});

module.exports = router;
