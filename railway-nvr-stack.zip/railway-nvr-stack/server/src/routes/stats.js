'use strict';
const express = require('express');
const { one, many } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.get('/dashboard', authenticate, async (_req, res) => {
  try {
    const cameras = await many(
      `SELECT camera_id, camera_name, status, location_description, camera_type FROM cameras ORDER BY camera_name`);
    const events24h = await many(
      `SELECT event_id, severity, is_acknowledged, event_type, camera_id, title, description, occurred_at
       FROM events WHERE occurred_at >= NOW() - INTERVAL '24 hours' ORDER BY occurred_at DESC LIMIT 200`);

    const activeCameras = cameras.filter(c => c.status === 'ACTIVE').length;
    const unacknowledgedAlerts = events24h.filter(e => e.is_acknowledged === 0).length;
    const recentAlerts = events24h.filter(e => e.is_acknowledged === 0).slice(0, 5);

    const storage = await one(
      `SELECT COALESCE(SUM(file_size_bytes),0)::bigint AS used_bytes,
              COUNT(*)::int AS total_recordings
       FROM recordings WHERE status IN ('COMPLETED','RECORDING')`);

    res.json({
      activeCameras,
      totalCameras: cameras.length,
      totalEvents: events24h.length,
      unacknowledgedAlerts,
      recentAlerts,
      cameras,
      storage,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/system-health', authenticate, async (_req, res) => {
  const latest = await one(`SELECT * FROM system_health ORDER BY timestamp DESC LIMIT 1`);
  res.json(latest || {});
});

router.get('/camera-health/:id', authenticate, async (req, res) => {
  const rows = await many(
    `SELECT * FROM camera_health WHERE camera_id=$1 ORDER BY timestamp DESC LIMIT 100`,
    [req.params.id]);
  res.json(rows);
});

module.exports = router;
