'use strict';
const express = require('express');
const { one, many, query } = require('../lib/db');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

router.get('/', authenticate, async (_req, res) => {
  const rows = await many('SELECT * FROM system_config ORDER BY config_key');
  res.json(rows);
});

router.get('/:key', authenticate, async (req, res) => {
  const r = await one('SELECT * FROM system_config WHERE config_key=$1', [req.params.key]);
  if (!r) return res.status(404).json({ error: 'Not found' });
  res.json(r);
});

router.put('/:key', authenticate, requireRole('ADMIN'), async (req, res) => {
  const { config_value, description, config_type } = req.body || {};
  if (config_value === undefined) return res.status(400).json({ error: 'config_value required' });
  const existing = await one('SELECT * FROM system_config WHERE config_key=$1', [req.params.key]);
  if (existing && existing.is_readonly) return res.status(403).json({ error: 'Read-only config' });

  const r = await one(
    `INSERT INTO system_config (config_key, config_value, config_type, description, last_modified_by, last_modified_at)
     VALUES ($1,$2,COALESCE($3,'STRING'),$4,$5,NOW())
     ON CONFLICT (config_key) DO UPDATE
       SET config_value = EXCLUDED.config_value,
           description  = COALESCE(EXCLUDED.description, system_config.description),
           last_modified_at = NOW(),
           last_modified_by = EXCLUDED.last_modified_by
     RETURNING *`,
    [req.params.key, String(config_value), config_type || null, description || null, req.user.username]);
  res.json(r);
});

router.delete('/:key', authenticate, requireRole('ADMIN'), async (req, res) => {
  const existing = await one('SELECT * FROM system_config WHERE config_key=$1', [req.params.key]);
  if (existing && existing.is_readonly) return res.status(403).json({ error: 'Read-only config' });
  await query('DELETE FROM system_config WHERE config_key=$1', [req.params.key]);
  res.json({ ok: true });
});

module.exports = router;
