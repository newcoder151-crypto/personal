'use strict';
const express = require('express');
const { one, many, query } = require('../lib/db');
const { authenticate, requireRole } = require('../middleware/auth');
const { broadcast } = require('../lib/websocket');

const router = express.Router();

// Whitelisted updatable fields (matches mnvr_schema.cameras)
const FIELDS = [
  'camera_name','camera_type','onvif_device_id','ip_address','rtsp_url','rtsp_port',
  'username','password_hash','manufacturer','model','firmware_version',
  'resolution_width','resolution_height','target_fps','video_codec',
  'location_description','physical_position','ptz_supported','audio_supported',
  'status','rec_output_dir','hls_output_dir','hls_playlist_url',
];

router.get('/', authenticate, async (req, res) => {
  try {
    const { status, type, q, limit = 200, offset = 0 } = req.query;
    const where = [];
    const params = [];
    if (status) { params.push(status); where.push(`status = $${params.length}`); }
    if (type)   { params.push(type);   where.push(`camera_type = $${params.length}`); }
    if (q)      { params.push(`%${q}%`); where.push(`(camera_name ILIKE $${params.length} OR location_description ILIKE $${params.length})`); }
    const sql = `SELECT * FROM cameras ${where.length ? 'WHERE '+where.join(' AND ') : ''}
                 ORDER BY camera_name LIMIT ${parseInt(limit,10)} OFFSET ${parseInt(offset,10)}`;
    const rows = await many(sql, params);
    const cnt = await one(`SELECT COUNT(*)::int AS n FROM cameras ${where.length ? 'WHERE '+where.join(' AND ') : ''}`, params);
    res.json({ cameras: rows, total: cnt.n });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', authenticate, async (req, res) => {
  const cam = await one('SELECT * FROM cameras WHERE camera_id = $1', [req.params.id]);
  if (!cam) return res.status(404).json({ error: 'Camera not found' });
  res.json(cam);
});

router.post('/', authenticate, requireRole('ADMIN'), async (req, res) => {
  try {
    const body = req.body || {};
    if (!body.camera_name || !body.camera_type || !body.ip_address || !body.rtsp_url) {
      return res.status(400).json({ error: 'camera_name, camera_type, ip_address, rtsp_url required' });
    }
    const cols = []; const vals = []; const ph = [];
    for (const f of FIELDS) {
      if (body[f] !== undefined) { cols.push(f); vals.push(body[f]); ph.push(`$${vals.length}`); }
    }
    const cam = await one(
      `INSERT INTO cameras (${cols.join(',')}) VALUES (${ph.join(',')}) RETURNING *`,
      vals
    );
    broadcast({ type: 'camera.created', data: cam });
    res.status(201).json(cam);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.put('/:id', authenticate, requireRole('ADMIN'), async (req, res) => {
  try {
    const body = req.body || {};
    const sets = []; const vals = [];
    for (const f of FIELDS) {
      if (body[f] !== undefined) { vals.push(body[f]); sets.push(`${f} = $${vals.length}`); }
    }
    if (!sets.length) return res.status(400).json({ error: 'No updatable fields' });
    sets.push(`updated_at = NOW()`);
    vals.push(req.params.id);
    const cam = await one(`UPDATE cameras SET ${sets.join(', ')} WHERE camera_id = $${vals.length} RETURNING *`, vals);
    if (!cam) return res.status(404).json({ error: 'Camera not found' });
    broadcast({ type: 'camera.updated', data: cam });
    res.json(cam);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.delete('/:id', authenticate, requireRole('ADMIN'), async (req, res) => {
  const cam = await one('DELETE FROM cameras WHERE camera_id = $1 RETURNING camera_id', [req.params.id]);
  if (!cam) return res.status(404).json({ error: 'Camera not found' });
  broadcast({ type: 'camera.deleted', data: { camera_id: cam.camera_id } });
  res.json({ ok: true });
});

// GET /api/cameras/:id/health  -> latest row from camera_health
router.get('/:id/health', authenticate, async (req, res) => {
  const h = await one(
    `SELECT * FROM camera_health WHERE camera_id = $1 ORDER BY timestamp DESC LIMIT 1`,
    [req.params.id]);
  res.json(h || null);
});

// GET /api/cameras/:id/live -> { hls_url } (handled by /api/hls/:cameraId/master.m3u8)
router.get('/:id/live', authenticate, async (req, res) => {
  const cam = await one('SELECT camera_id, hls_playlist_url FROM cameras WHERE camera_id=$1', [req.params.id]);
  if (!cam) return res.status(404).json({ error: 'Camera not found' });
  res.json({
    camera_id: cam.camera_id,
    hls_url: `/api/hls/${cam.camera_id}/master.m3u8`,
  });
});

module.exports = router;
