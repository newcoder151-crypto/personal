'use strict';
/**
 * Adaptive HLS streaming, per camera.
 *
 * Two layouts are supported on disk under STORAGE_HLS:
 *
 *   A) Multi-rendition (preferred — produced by mnvrd):
 *        /storage/hls/cam_<id>/master.m3u8
 *        /storage/hls/cam_<id>/low/index.m3u8 + low/seg_*.ts
 *        /storage/hls/cam_<id>/mid/index.m3u8 + mid/seg_*.ts
 *        /storage/hls/cam_<id>/high/index.m3u8 + high/seg_*.ts
 *
 *   B) Single rendition (legacy nvr_core hls_module):
 *        /storage/hls/cam_<id>/stream.m3u8 + seg_*.ts
 *      In this case GET .../master.m3u8 returns a synthetic master.m3u8
 *      pointing at stream.m3u8 (no real ABR, but the client-side flow is identical).
 *
 * Authentication: JWT via Authorization header OR ?token= query (for hls.js / <video>).
 * All token query params are forwarded into the master playlist so renditions are also auth'd.
 */
const express = require('express');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

const HLS_ROOT = path.resolve(process.env.STORAGE_HLS || '/storage/hls');
const RENDITIONS  = (process.env.HLS_RENDITIONS  || 'low,mid,high').split(',').map(s => s.trim()).filter(Boolean);
const BANDWIDTHS  = (process.env.HLS_BANDWIDTHS  || '600000,1500000,4500000').split(',').map(n => parseInt(n,10));
const RESOLUTIONS = (process.env.HLS_RESOLUTIONS || '640x360,1280x720,1920x1080').split(',').map(s => s.trim());

function camDir(cameraId) {
  const d = path.resolve(HLS_ROOT, `cam_${parseInt(cameraId, 10)}`);
  return d.startsWith(HLS_ROOT) ? d : null;
}

function existingRenditions(dir) {
  return RENDITIONS.filter((r, i) => {
    const p = path.join(dir, r, 'index.m3u8');
    return fs.existsSync(p);
  });
}

function buildMaster(cameraId, tokenQs) {
  const dir = camDir(cameraId);
  if (!dir || !fs.existsSync(dir)) return null;

  // Layout A: real master on disk -> rewrite URIs to absolute /api/hls/<id>/<rendition>/index.m3u8
  const realMaster = path.join(dir, 'master.m3u8');
  if (fs.existsSync(realMaster)) {
    const txt = fs.readFileSync(realMaster, 'utf8');
    return txt.replace(/^([^#\r\n][^\r\n]+\.m3u8)\s*$/gm, (line) => {
      // turn "low/index.m3u8" or "high/index.m3u8" into a rooted, auth'd URL
      const cleaned = line.trim();
      return `/api/hls/${cameraId}/${cleaned}${tokenQs}`;
    });
  }

  // Layout A': separate per-rendition index.m3u8 but no master -> synthesise master
  const present = existingRenditions(dir);
  if (present.length > 0) {
    const lines = ['#EXTM3U', '#EXT-X-VERSION:6', ''];
    present.forEach((rend) => {
      const idx = RENDITIONS.indexOf(rend);
      const bw  = BANDWIDTHS[idx]  || 1_500_000;
      const res = RESOLUTIONS[idx] || '1280x720';
      lines.push(`#EXT-X-STREAM-INF:BANDWIDTH=${bw},RESOLUTION=${res},CODECS="avc1.640028,mp4a.40.2"`);
      lines.push(`/api/hls/${cameraId}/${rend}/index.m3u8${tokenQs}`);
      lines.push('');
    });
    return lines.join('\n');
  }

  // Layout B: single stream.m3u8 -> wrap in synthetic master
  const single = path.join(dir, 'stream.m3u8');
  if (fs.existsSync(single)) {
    return [
      '#EXTM3U',
      '#EXT-X-VERSION:6',
      `#EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1280x720,CODECS="avc1.640028,mp4a.40.2"`,
      `/api/hls/${cameraId}/stream.m3u8${tokenQs}`,
      '',
    ].join('\n');
  }

  return null;
}

function appendTokenToSegments(playlist, prefix, tokenQs) {
  // Rewrite each .ts / .m4s line to a rooted URL with token attached
  if (!tokenQs) return playlist;
  return playlist.replace(/^([^#\r\n][^\r\n]+\.(ts|m4s|aac|vtt))\s*$/gim, (line) => {
    const cleaned = line.trim();
    if (cleaned.startsWith('http') || cleaned.startsWith('/')) return cleaned;
    return `${prefix}/${cleaned}${tokenQs}`;
  });
}

function setHlsHeaders(res, contentType) {
  res.setHeader('Content-Type', contentType);
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Range');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range');
}

// GET /api/hls/:cameraId/master.m3u8
router.get('/:cameraId/master.m3u8', authenticate, async (req, res) => {
  const tokenQs = req.query.token ? `?token=${encodeURIComponent(String(req.query.token))}` : '';
  const text = buildMaster(req.params.cameraId, tokenQs);
  if (!text) return res.status(404).json({ error: 'No HLS playlist on disk for camera ' + req.params.cameraId });
  setHlsHeaders(res, 'application/vnd.apple.mpegurl');
  res.send(text);
});

// GET /api/hls/:cameraId/:rendition/index.m3u8
router.get('/:cameraId/:rendition/index.m3u8', authenticate, async (req, res) => {
  const dir = camDir(req.params.cameraId);
  if (!dir) return res.status(403).json({ error: 'Bad camera id' });
  const rend = req.params.rendition;
  if (!/^[a-zA-Z0-9_-]+$/.test(rend)) return res.status(400).json({ error: 'Bad rendition' });
  const file = path.join(dir, rend, 'index.m3u8');
  if (!fs.existsSync(file)) return res.status(404).json({ error: 'Playlist missing' });
  let text = await fsp.readFile(file, 'utf8');
  const tokenQs = req.query.token ? `?token=${encodeURIComponent(String(req.query.token))}` : '';
  text = appendTokenToSegments(text, `/api/hls/${req.params.cameraId}/${rend}`, tokenQs);
  setHlsHeaders(res, 'application/vnd.apple.mpegurl');
  res.send(text);
});

// GET /api/hls/:cameraId/stream.m3u8 (single-rendition layout B)
router.get('/:cameraId/stream.m3u8', authenticate, async (req, res) => {
  const dir = camDir(req.params.cameraId);
  if (!dir) return res.status(403).json({ error: 'Bad camera id' });
  const file = path.join(dir, 'stream.m3u8');
  if (!fs.existsSync(file)) return res.status(404).json({ error: 'Playlist missing' });
  let text = await fsp.readFile(file, 'utf8');
  const tokenQs = req.query.token ? `?token=${encodeURIComponent(String(req.query.token))}` : '';
  text = appendTokenToSegments(text, `/api/hls/${req.params.cameraId}`, tokenQs);
  setHlsHeaders(res, 'application/vnd.apple.mpegurl');
  res.send(text);
});

// GET /api/hls/:cameraId/:rendition/:segment.ts (or .m4s)
router.get('/:cameraId/:rendition/:segment', authenticate, async (req, res) => {
  const dir = camDir(req.params.cameraId);
  if (!dir) return res.status(403).json({ error: 'Bad camera id' });
  const seg = req.params.segment;
  if (!/^[a-zA-Z0-9._-]+\.(ts|m4s|aac|vtt|key)$/.test(seg)) {
    return res.status(400).json({ error: 'Bad segment name' });
  }
  const file = path.join(dir, req.params.rendition, seg);
  if (!file.startsWith(dir)) return res.status(403).json({ error: 'Forbidden' });
  if (!fs.existsSync(file)) return res.status(404).json({ error: 'Segment missing' });
  const ctype = seg.endsWith('.m4s') ? 'video/iso.segment'
              : seg.endsWith('.ts')  ? 'video/mp2t'
              : seg.endsWith('.vtt') ? 'text/vtt'
              : 'application/octet-stream';
  setHlsHeaders(res, ctype);
  res.setHeader('Cache-Control', 'public, max-age=10');
  fs.createReadStream(file).pipe(res);
});

// Single-rendition .ts at root (layout B)
router.get('/:cameraId/:segment', authenticate, async (req, res, next) => {
  if (!/\.(ts|m4s|aac|vtt|key)$/i.test(req.params.segment)) return next();
  const dir = camDir(req.params.cameraId);
  if (!dir) return res.status(403).json({ error: 'Bad camera id' });
  const file = path.join(dir, req.params.segment);
  if (!file.startsWith(dir) || !fs.existsSync(file)) return res.status(404).json({ error: 'Segment missing' });
  const seg = req.params.segment.toLowerCase();
  const ctype = seg.endsWith('.m4s') ? 'video/iso.segment'
              : seg.endsWith('.ts')  ? 'video/mp2t'
              : 'application/octet-stream';
  setHlsHeaders(res, ctype);
  res.setHeader('Cache-Control', 'public, max-age=10');
  fs.createReadStream(file).pipe(res);
});

module.exports = router;
