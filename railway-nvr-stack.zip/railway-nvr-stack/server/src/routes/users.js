'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const { one, many, query } = require('../lib/db');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();
const ROUNDS = parseInt(process.env.BCRYPT_ROUNDS || '12', 10);

function pub(u) {
  if (!u) return null;
  const { password_hash, ...rest } = u;
  return rest;
}

router.get('/', authenticate, requireRole('ADMIN'), async (_req, res) => {
  const rows = await many(`SELECT * FROM users ORDER BY user_id`);
  res.json(rows.map(pub));
});

router.get('/:id', authenticate, async (req, res) => {
  if (req.user.role !== 'ADMIN' && String(req.user.id) !== String(req.params.id)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const u = await one('SELECT * FROM users WHERE user_id = $1', [req.params.id]);
  if (!u) return res.status(404).json({ error: 'Not found' });
  res.json(pub(u));
});

router.post('/', authenticate, requireRole('ADMIN'), async (req, res) => {
  try {
    const { username, password, full_name, email, phone, role } = req.body || {};
    if (!username || !password || !full_name) return res.status(400).json({ error: 'username, password, full_name required' });
    if (!['ADMIN','OPERATOR','MAINTENANCE','VIEWER','API_CLIENT'].includes(role || 'OPERATOR')) {
      return res.status(400).json({ error: 'Invalid role' });
    }
    const hash = await bcrypt.hash(password, ROUNDS);
    const u = await one(
      `INSERT INTO users (username, password_hash, full_name, email, phone, role, created_by)
       VALUES ($1,$2,$3,$4,$5,COALESCE($6,'OPERATOR'),$7) RETURNING *`,
      [username, hash, full_name, email || null, phone || null, role, req.user.username]);
    res.status(201).json(pub(u));
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'username/email taken' });
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', authenticate, requireRole('ADMIN'), async (req, res) => {
  const { full_name, email, phone, role, is_active, is_locked, must_change_password } = req.body || {};
  const sets = []; const vals = [];
  const set = (col, val) => { if (val !== undefined) { vals.push(val); sets.push(`${col}=$${vals.length}`); } };
  set('full_name', full_name); set('email', email); set('phone', phone); set('role', role);
  if (is_active !== undefined) { vals.push(is_active ? 1 : 0); sets.push(`is_active=$${vals.length}`); }
  if (is_locked !== undefined) { vals.push(is_locked ? 1 : 0); sets.push(`is_locked=$${vals.length}`); }
  if (must_change_password !== undefined) { vals.push(must_change_password ? 1 : 0); sets.push(`must_change_password=$${vals.length}`); }
  if (!sets.length) return res.status(400).json({ error: 'No fields to update' });
  sets.push('updated_at = NOW()');
  vals.push(req.params.id);
  const u = await one(`UPDATE users SET ${sets.join(', ')} WHERE user_id=$${vals.length} RETURNING *`, vals);
  if (!u) return res.status(404).json({ error: 'Not found' });
  res.json(pub(u));
});

router.post('/:id/reset-password', authenticate, requireRole('ADMIN'), async (req, res) => {
  const { new_password } = req.body || {};
  if (!new_password || new_password.length < 8) return res.status(400).json({ error: 'new_password (8+ chars) required' });
  const hash = await bcrypt.hash(new_password, ROUNDS);
  const u = await one(
    `UPDATE users SET password_hash=$1, must_change_password=1, failed_login_attempts=0, is_locked=0, updated_at=NOW()
     WHERE user_id=$2 RETURNING user_id, username`, [hash, req.params.id]);
  if (!u) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true, user_id: u.user_id });
});

router.delete('/:id', authenticate, requireRole('ADMIN'), async (req, res) => {
  if (Number(req.user.id) === Number(req.params.id)) return res.status(400).json({ error: 'Cannot delete self' });
  await query('DELETE FROM users WHERE user_id=$1', [req.params.id]);
  res.json({ ok: true });
});

module.exports = router;
