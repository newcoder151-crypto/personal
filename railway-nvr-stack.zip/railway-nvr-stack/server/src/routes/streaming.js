'use strict';
/**
 * MP4 file streaming for recordings (HTTP range / partial content).
 * Reads recordings.file_path from the DB; safety-checks against STORAGE_RECORDINGS root.
 */
const express = require('express');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const mime = require('mime-types');
const { one } = require('../lib/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

const RECORDINGS_ROOT = path.resolve(process.env.STORAGE_RECORDINGS || '/storage/recordings');
const THUMBS_ROOT     = path.resolve(process.env.STORAGE_THUMBNAILS || '/storage/thumbnails');

/** Resolve & jail the requested absolute path under root. Returns null if escape detected. */
function safeResolve(absPath, root) {
  const resolved = path.resolve(absPath);
  return resolved.startsWith(root + path.sep) || resolved === root ? resolved : null;
}

async function streamFile(req, res, absPath) {
  let stat;
  try { stat = await fsp.stat(absPath); }
  catch { return res.status(404).json({ error: 'File not found on disk', path: absPath }); }
  if (!stat.isFile()) return res.status(404).json({ error: 'Not a regular file' });

  const fileSize = stat.size;
  const ctype = mime.lookup(absPath) || 'application/octet-stream';
  const range = req.headers.range;

  // Common headers that make <video> + ABR clients happy
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cache-Control', 'private, max-age=60');
  res.setHeader('Content-Type', ctype);

  if (range) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!m) { res.status(416).setHeader('Content-Range', `bytes */${fileSize}`).end(); return; }
    let start = m[1] ? parseInt(m[1], 10) : 0;
    let end   = m[2] ? parseInt(m[2], 10) : fileSize - 1;
    if (isNaN(start) || isNaN(end) || start > end || end >= fileSize) {
      res.status(416).setHeader('Content-Range', `bytes */${fileSize}`).end(); return;
    }
    // Cap chunk to ~8 MB so the client can re-range and we don't pin the worker
    const MAX_CHUNK = 8 * 1024 * 1024;
    if (end - start + 1 > MAX_CHUNK) end = start + MAX_CHUNK - 1;

    res.status(206);
    res.setHeader('Content-Range', `bytes ${start}-${end}/${fileSize}`);
    res.setHeader('Content-Length', end - start + 1);
    fs.createReadStream(absPath, { start, end }).on('error', () => res.end()).pipe(res);
  } else {
    res.status(200);
    res.setHeader('Content-Length', fileSize);
    fs.createReadStream(absPath).on('error', () => res.end()).pipe(res);
  }
}

// GET /api/streaming/recordings/:id/stream
router.get('/recordings/:id/stream', authenticate, async (req, res) => {
  const r = await one('SELECT recording_id, file_path FROM recordings WHERE recording_id=$1', [req.params.id]);
  if (!r) return res.status(404).json({ error: 'Recording not found' });
  const safe = safeResolve(r.file_path, RECORDINGS_ROOT);
  if (!safe) return res.status(403).json({ error: 'Path outside storage root' });
  return streamFile(req, res, safe);
});

// GET /api/streaming/recordings/:id/download
router.get('/recordings/:id/download', authenticate, async (req, res) => {
  const r = await one(
    `SELECT r.recording_id, r.file_path, r.file_name, c.camera_name
     FROM recordings r LEFT JOIN cameras c USING (camera_id)
     WHERE r.recording_id = $1`, [req.params.id]);
  if (!r) return res.status(404).json({ error: 'Recording not found' });
  const safe = safeResolve(r.file_path, RECORDINGS_ROOT);
  if (!safe) return res.status(403).json({ error: 'Path outside storage root' });
  if (!fs.existsSync(safe)) return res.status(404).json({ error: 'File missing' });
  const fname = (r.file_name || `${r.camera_name || 'recording'}_${r.recording_id}.mp4`)
    .replace(/[^a-zA-Z0-9._-]/g, '_');
  res.download(safe, fname);
});

// GET /api/streaming/recordings/:id/thumbnail
router.get('/recordings/:id/thumbnail', authenticate, async (req, res) => {
  const r = await one(
    `SELECT recording_id, snapshot_path FROM recordings WHERE recording_id=$1`,
    [req.params.id]);
  if (!r) return res.status(404).json({ error: 'Recording not found' });
  // Convention: thumbnails stored at <THUMBS_ROOT>/<recording_id>.jpg, otherwise use snapshot_path if set.
  let candidate = path.join(THUMBS_ROOT, `${r.recording_id}.jpg`);
  if (!fs.existsSync(candidate) && r.snapshot_path) {
    candidate = safeResolve(r.snapshot_path, THUMBS_ROOT) || safeResolve(r.snapshot_path, RECORDINGS_ROOT);
  }
  if (!candidate || !fs.existsSync(candidate)) return res.status(404).json({ error: 'Thumbnail not available' });
  res.setHeader('Cache-Control', 'public, max-age=300');
  res.sendFile(candidate);
});

module.exports = router;
