'use strict';
const express = require('express');
const { one, many, query } = require('../lib/db');
const { authenticate } = require('../middleware/auth');
const { broadcast } = require('../lib/websocket');

const router = express.Router();

router.get('/', authenticate, async (req, res) => {
  try {
    const { severity, is_acknowledged, camera_id, status, since, limit = 100, offset = 0 } = req.query;
    const where = []; const params = [];
    if (severity)        { params.push(severity);        where.push(`e.severity = $${params.length}`); }
    if (status)          { params.push(status);          where.push(`e.status = $${params.length}`); }
    if (camera_id)       { params.push(camera_id);       where.push(`e.camera_id = $${params.length}`); }
    if (is_acknowledged !== undefined) {
      params.push(parseInt(is_acknowledged, 10));
      where.push(`e.is_acknowledged = $${params.length}`);
    }
    if (since)           { params.push(since);           where.push(`e.occurred_at >= $${params.length}`); }

    const rows = await many(
      `SELECT e.*,
              json_build_object('camera_name', c.camera_name, 'location_description', c.location_description) AS cameras
       FROM events e LEFT JOIN cameras c USING (camera_id)
       ${where.length ? 'WHERE '+where.join(' AND ') : ''}
       ORDER BY e.occurred_at DESC
       LIMIT ${parseInt(limit,10)} OFFSET ${parseInt(offset,10)}`,
      params
    );
    const cnt = await one(
      `SELECT COUNT(*)::int AS n FROM events e ${where.length ? 'WHERE '+where.join(' AND ') : ''}`,
      params);
    res.json({ events: rows, total: cnt.n });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', authenticate, async (req, res) => {
  const e = await one('SELECT * FROM events WHERE event_id = $1', [req.params.id]);
  if (!e) return res.status(404).json({ error: 'Event not found' });
  res.json(e);
});

router.post('/:id/acknowledge', authenticate, async (req, res) => {
  const e = await one(
    `UPDATE events SET is_acknowledged = 1, acknowledged_by = $1, acknowledged_at = NOW(),
                       status = 'ACKNOWLEDGED', updated_at = NOW()
     WHERE event_id = $2 RETURNING *`,
    [req.user.username, req.params.id]);
  if (!e) return res.status(404).json({ error: 'Event not found' });
  broadcast({ type: 'event.acknowledged', data: e });
  res.json(e);
});

router.post('/acknowledge-all', authenticate, async (req, res) => {
  const r = await query(
    `UPDATE events SET is_acknowledged = 1, acknowledged_by = $1, acknowledged_at = NOW(),
                       status = 'ACKNOWLEDGED', updated_at = NOW()
     WHERE is_acknowledged = 0`,
    [req.user.username]);
  broadcast({ type: 'events.acknowledged_all', data: { count: r.rowCount } });
  res.json({ acknowledged: r.rowCount });
});

router.post('/:id/resolve', authenticate, async (req, res) => {
  const { resolution_notes } = req.body || {};
  const e = await one(
    `UPDATE events SET status = 'RESOLVED', resolved_at = NOW(),
                       resolution_notes = $1, updated_at = NOW()
     WHERE event_id = $2 RETURNING *`,
    [resolution_notes || null, req.params.id]);
  if (!e) return res.status(404).json({ error: 'Event not found' });
  broadcast({ type: 'event.resolved', data: e });
  res.json(e);
});

// Manual create (used by clients/AI sidecar to push events)
router.post('/', authenticate, async (req, res) => {
  const b = req.body || {};
  if (!b.event_type || !b.title) return res.status(400).json({ error: 'event_type and title required' });
  const e = await one(
    `INSERT INTO events (event_type, event_subtype, severity, source_device_type, source_device_id,
                         title, description, event_data, camera_id, occurred_at)
     VALUES ($1,$2,COALESCE($3,'INFO'),$4,$5,$6,$7,$8,$9, COALESCE($10::timestamp, NOW()))
     RETURNING *`,
    [b.event_type, b.event_subtype || null, b.severity || 'INFO',
     b.source_device_type || null, b.source_device_id || null,
     b.title, b.description || null, b.event_data || null,
     b.camera_id || null, b.occurred_at || null]);
  broadcast({ type: 'event.created', data: e });
  res.status(201).json(e);
});

module.exports = router;
