'use strict';
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { one } = require('../lib/db');

const JWT_SECRET = process.env.JWT_SECRET || 'change-me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';
const REFRESH_EXPIRES_IN = process.env.REFRESH_EXPIRES_IN || '30d';

function signAccessToken(user) {
  return jwt.sign(
    { sub: user.user_id, username: user.username, role: user.role, type: 'access' },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

function signRefreshToken(user) {
  return jwt.sign(
    { sub: user.user_id, type: 'refresh' },
    JWT_SECRET,
    { expiresIn: REFRESH_EXPIRES_IN }
  );
}

function verify(token) {
  return jwt.verify(token, JWT_SECRET);
}

// Accepts JWT in `Authorization: Bearer ...` OR `?token=` query param (needed for <video src>).
async function authenticate(req, res, next) {
  let token = null;
  const h = req.headers.authorization;
  if (h && h.startsWith('Bearer ')) token = h.slice(7);
  else if (req.query && req.query.token) token = String(req.query.token);

  if (!token) return res.status(401).json({ error: 'Missing token' });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.type && decoded.type !== 'access') {
      return res.status(401).json({ error: 'Wrong token type' });
    }
    // Optional: confirm user still exists & active
    const u = await one(
      'SELECT user_id, username, role, is_active, is_locked FROM users WHERE user_id = $1',
      [decoded.sub]
    );
    if (!u || !u.is_active || u.is_locked) {
      return res.status(401).json({ error: 'User disabled' });
    }
    req.user = { id: u.user_id, sub: u.user_id, username: u.username, role: u.role };
    req.token = token;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function requireRole(...allowed) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
    if (!allowed.includes(req.user.role)) {
      return res.status(403).json({ error: `Requires role: ${allowed.join(' or ')}` });
    }
    next();
  };
}

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many auth attempts, try again later' },
});

module.exports = {
  authenticate, requireRole, authLimiter,
  signAccessToken, signRefreshToken, verify, JWT_SECRET,
};
