"""
Tiny FastAPI sidecar that exposes YOLO object detection.
Run:
    pip install -r requirements.txt
    uvicorn sidecar:app --host 127.0.0.1 --port 9000
"""
import io, time
from typing import List
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import JSONResponse
from PIL import Image

app = FastAPI(title="mNVR AI sidecar")

_models = {}
def get_model(name: str = "yolov8n.pt"):
    if name not in _models:
        from ultralytics import YOLO  # lazy import
        _models[name] = YOLO(name)
    return _models[name]

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/detect")
async def detect(image: UploadFile = File(...), conf: float = Form(0.4), model: str = Form("yolov8n.pt")):
    raw = await image.read()
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    t0 = time.time()
    results = get_model(model).predict(img, conf=conf, verbose=False)
    detections: List[dict] = []
    if results:
        r = results[0]
        names = r.names
        for box in r.boxes:
            x1, y1, x2, y2 = [float(v) for v in box.xyxy[0].tolist()]
            detections.append({
                "label": names[int(box.cls[0])],
                "confidence": float(box.conf[0]),
                "bbox": [x1, y1, x2, y2],
            })
    return JSONResponse({"detections": detections, "inference_ms": int((time.time() - t0) * 1000)})
